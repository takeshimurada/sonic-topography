--
-- PostgreSQL database dump
--

\restrict 4EivWQGPNejwu34r7nrTjW1Ot6uayqqffdgoklC46tY2UJNvaojvCCmajg0OIsO

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_research; Type: TABLE; Schema: public; Owner: sonic
--

CREATE TABLE public.ai_research (
    id integer NOT NULL,
    album_id character varying,
    lang character varying,
    summary_md text,
    sources json,
    confidence double precision,
    cache_key character varying,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ai_research OWNER TO sonic;

--
-- Name: ai_research_id_seq; Type: SEQUENCE; Schema: public; Owner: sonic
--

CREATE SEQUENCE public.ai_research_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ai_research_id_seq OWNER TO sonic;

--
-- Name: ai_research_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sonic
--

ALTER SEQUENCE public.ai_research_id_seq OWNED BY public.ai_research.id;


--
-- Name: album_details; Type: TABLE; Schema: public; Owner: sonic
--

CREATE TABLE public.album_details (
    album_id character varying NOT NULL,
    tracklist json,
    credits json,
    external_links json
);


ALTER TABLE public.album_details OWNER TO sonic;

--
-- Name: album_reviews; Type: TABLE; Schema: public; Owner: sonic
--

CREATE TABLE public.album_reviews (
    id integer NOT NULL,
    album_id character varying,
    source_name character varying,
    url character varying,
    snippet text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.album_reviews OWNER TO sonic;

--
-- Name: album_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: sonic
--

CREATE SEQUENCE public.album_reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.album_reviews_id_seq OWNER TO sonic;

--
-- Name: album_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sonic
--

ALTER SEQUENCE public.album_reviews_id_seq OWNED BY public.album_reviews.id;


--
-- Name: albums; Type: TABLE; Schema: public; Owner: sonic
--

CREATE TABLE public.albums (
    id character varying NOT NULL,
    title character varying,
    artist_name character varying,
    year integer,
    genre character varying,
    genre_vibe double precision,
    region_bucket character varying,
    country character varying,
    popularity double precision,
    cover_url character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.albums OWNER TO sonic;

--
-- Name: dev_users; Type: TABLE; Schema: public; Owner: sonic
--

CREATE TABLE public.dev_users (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.dev_users OWNER TO sonic;

--
-- Name: user_events; Type: TABLE; Schema: public; Owner: sonic
--

CREATE TABLE public.user_events (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    event_type character varying NOT NULL,
    entity_type character varying,
    entity_id uuid,
    payload jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_events OWNER TO sonic;

--
-- Name: user_events_id_seq; Type: SEQUENCE; Schema: public; Owner: sonic
--

CREATE SEQUENCE public.user_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_events_id_seq OWNER TO sonic;

--
-- Name: user_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sonic
--

ALTER SEQUENCE public.user_events_id_seq OWNED BY public.user_events.id;


--
-- Name: user_likes; Type: TABLE; Schema: public; Owner: sonic
--

CREATE TABLE public.user_likes (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    entity_type character varying NOT NULL,
    entity_id uuid NOT NULL,
    liked_at timestamp with time zone DEFAULT now(),
    CONSTRAINT check_entity_type CHECK (((entity_type)::text = ANY ((ARRAY['album'::character varying, 'artist'::character varying])::text[])))
);


ALTER TABLE public.user_likes OWNER TO sonic;

--
-- Name: user_likes_id_seq; Type: SEQUENCE; Schema: public; Owner: sonic
--

CREATE SEQUENCE public.user_likes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_likes_id_seq OWNER TO sonic;

--
-- Name: user_likes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sonic
--

ALTER SEQUENCE public.user_likes_id_seq OWNED BY public.user_likes.id;


--
-- Name: user_ratings; Type: TABLE; Schema: public; Owner: sonic
--

CREATE TABLE public.user_ratings (
    id integer NOT NULL,
    user_id integer,
    album_id character varying,
    rating integer,
    note text,
    listened_at date,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_ratings OWNER TO sonic;

--
-- Name: user_ratings_id_seq; Type: SEQUENCE; Schema: public; Owner: sonic
--

CREATE SEQUENCE public.user_ratings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_ratings_id_seq OWNER TO sonic;

--
-- Name: user_ratings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sonic
--

ALTER SEQUENCE public.user_ratings_id_seq OWNED BY public.user_ratings.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: sonic
--

CREATE TABLE public.users (
    id integer NOT NULL,
    google_sub character varying,
    email character varying,
    name character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO sonic;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: sonic
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO sonic;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sonic
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: ai_research id; Type: DEFAULT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.ai_research ALTER COLUMN id SET DEFAULT nextval('public.ai_research_id_seq'::regclass);


--
-- Name: album_reviews id; Type: DEFAULT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.album_reviews ALTER COLUMN id SET DEFAULT nextval('public.album_reviews_id_seq'::regclass);


--
-- Name: user_events id; Type: DEFAULT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.user_events ALTER COLUMN id SET DEFAULT nextval('public.user_events_id_seq'::regclass);


--
-- Name: user_likes id; Type: DEFAULT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.user_likes ALTER COLUMN id SET DEFAULT nextval('public.user_likes_id_seq'::regclass);


--
-- Name: user_ratings id; Type: DEFAULT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.user_ratings ALTER COLUMN id SET DEFAULT nextval('public.user_ratings_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: ai_research; Type: TABLE DATA; Schema: public; Owner: sonic
--

COPY public.ai_research (id, album_id, lang, summary_md, sources, confidence, cache_key, updated_at) FROM stdin;
\.


--
-- Data for Name: album_details; Type: TABLE DATA; Schema: public; Owner: sonic
--

COPY public.album_details (album_id, tracklist, credits, external_links) FROM stdin;
\.


--
-- Data for Name: album_reviews; Type: TABLE DATA; Schema: public; Owner: sonic
--

COPY public.album_reviews (id, album_id, source_name, url, snippet, created_at) FROM stdin;
\.


--
-- Data for Name: albums; Type: TABLE DATA; Schema: public; Owner: sonic
--

COPY public.albums (id, title, artist_name, year, genre, genre_vibe, region_bucket, country, popularity, cover_url, created_at) FROM stdin;
album_0001	Abbey Road	The Beatles	1969	Rock	0.5	Europe	UK	0.95	https://picsum.photos/300/300?random=1	2026-01-18 14:16:53.906332+00
album_0002	Sgt. Pepper's Lonely Hearts Club Band	The Beatles	1967	Rock	0.6	Europe	UK	0.98	https://picsum.photos/300/300?random=2	2026-01-18 14:16:53.906332+00
album_0003	Revolver	The Beatles	1966	Rock	0.55	Europe	UK	0.92	https://picsum.photos/300/300?random=3	2026-01-18 14:16:53.906332+00
album_0004	Rubber Soul	The Beatles	1965	Rock	0.5	Europe	UK	0.88	https://picsum.photos/300/300?random=4	2026-01-18 14:16:53.906332+00
album_0005	Help!	The Beatles	1965	Rock	0.5	Europe	UK	0.82	https://picsum.photos/300/300?random=5	2026-01-18 14:16:53.906332+00
album_0006	Let It Bleed	The Rolling Stones	1969	Rock	0.65	Europe	UK	0.89	https://picsum.photos/300/300?random=6	2026-01-18 14:16:53.906332+00
album_0007	Beggars Banquet	The Rolling Stones	1968	Rock	0.63	Europe	UK	0.87	https://picsum.photos/300/300?random=7	2026-01-18 14:16:53.906332+00
album_0008	Led Zeppelin	Led Zeppelin	1969	Rock	0.75	Europe	UK	0.91	https://picsum.photos/300/300?random=8	2026-01-18 14:16:53.906332+00
album_0009	The Doors	The Doors	1967	Rock	0.62	North America	USA	0.88	https://picsum.photos/300/300?random=9	2026-01-18 14:16:53.906332+00
album_0010	Strange Days	The Doors	1967	Rock	0.64	North America	USA	0.83	https://picsum.photos/300/300?random=10	2026-01-18 14:16:53.906332+00
album_0011	Are You Experienced	Jimi Hendrix	1967	Rock	0.78	North America	USA	0.94	https://picsum.photos/300/300?random=11	2026-01-18 14:16:53.906332+00
album_0012	Electric Ladyland	Jimi Hendrix	1968	Rock	0.8	North America	USA	0.91	https://picsum.photos/300/300?random=12	2026-01-18 14:16:53.906332+00
album_0013	The Piper at the Gates of Dawn	Pink Floyd	1967	Psychedelic	0.58	Europe	UK	0.85	https://picsum.photos/300/300?random=13	2026-01-18 14:16:53.906332+00
album_0014	Disraeli Gears	Cream	1967	Rock	0.72	Europe	UK	0.84	https://picsum.photos/300/300?random=14	2026-01-18 14:16:53.906332+00
album_0015	The Velvet Underground & Nico	The Velvet Underground	1967	Rock	0.55	North America	USA	0.89	https://picsum.photos/300/300?random=15	2026-01-18 14:16:53.906332+00
album_0016	Highway 61 Revisited	Bob Dylan	1965	Folk Rock	0.48	North America	USA	0.93	https://picsum.photos/300/300?random=16	2026-01-18 14:16:53.906332+00
album_0017	Blonde on Blonde	Bob Dylan	1966	Folk Rock	0.5	North America	USA	0.91	https://picsum.photos/300/300?random=17	2026-01-18 14:16:53.906332+00
album_0018	Pet Sounds	The Beach Boys	1966	Pop	0.45	North America	USA	0.95	https://picsum.photos/300/300?random=18	2026-01-18 14:16:53.906332+00
album_0019	Bridge over Troubled Water	Simon & Garfunkel	1970	Folk	0.35	North America	USA	0.88	https://picsum.photos/300/300?random=19	2026-01-18 14:16:53.906332+00
album_0020	Led Zeppelin IV	Led Zeppelin	1971	Rock	0.77	Europe	UK	0.97	https://picsum.photos/300/300?random=20	2026-01-18 14:16:53.906332+00
album_0021	The Dark Side of the Moon	Pink Floyd	1973	Progressive Rock	0.62	Europe	UK	0.99	https://picsum.photos/300/300?random=21	2026-01-18 14:16:53.906332+00
album_0022	Wish You Were Here	Pink Floyd	1975	Progressive Rock	0.6	Europe	UK	0.94	https://picsum.photos/300/300?random=22	2026-01-18 14:16:53.906332+00
album_0023	The Wall	Pink Floyd	1979	Progressive Rock	0.65	Europe	UK	0.96	https://picsum.photos/300/300?random=23	2026-01-18 14:16:53.906332+00
album_0024	A Night at the Opera	Queen	1975	Rock	0.68	Europe	UK	0.92	https://picsum.photos/300/300?random=24	2026-01-18 14:16:53.906332+00
album_0025	The Rise and Fall of Ziggy Stardust	David Bowie	1972	Glam Rock	0.7	Europe	UK	0.95	https://picsum.photos/300/300?random=25	2026-01-18 14:16:53.906332+00
album_0026	Heroes	David Bowie	1977	Art Rock	0.68	Europe	UK	0.91	https://picsum.photos/300/300?random=26	2026-01-18 14:16:53.906332+00
album_0027	Rumours	Fleetwood Mac	1977	Rock	0.58	North America	USA	0.96	https://picsum.photos/300/300?random=27	2026-01-18 14:16:53.906332+00
album_0028	Hotel California	The Eagles	1976	Rock	0.55	North America	USA	0.93	https://picsum.photos/300/300?random=28	2026-01-18 14:16:53.906332+00
album_0029	Songs in the Key of Life	Stevie Wonder	1976	Soul	0.52	North America	USA	0.94	https://picsum.photos/300/300?random=29	2026-01-18 14:16:53.906332+00
album_0030	What's Going On	Marvin Gaye	1971	Soul	0.48	North America	USA	0.96	https://picsum.photos/300/300?random=30	2026-01-18 14:16:53.906332+00
album_0031	Super Fly	Curtis Mayfield	1972	Funk	0.65	North America	USA	0.85	https://picsum.photos/300/300?random=31	2026-01-18 14:16:53.906332+00
album_0032	Mothership Connection	Parliament	1975	Funk	0.75	North America	USA	0.87	https://picsum.photos/300/300?random=32	2026-01-18 14:16:53.906332+00
album_0033	Bitches Brew	Miles Davis	1970	Jazz Fusion	0.72	North America	USA	0.93	https://picsum.photos/300/300?random=33	2026-01-18 14:16:53.906332+00
album_0034	Head Hunters	Herbie Hancock	1973	Jazz Fusion	0.73	North America	USA	0.89	https://picsum.photos/300/300?random=34	2026-01-18 14:16:53.906332+00
album_0035	Close to the Edge	Yes	1972	Progressive Rock	0.64	Europe	UK	0.88	https://picsum.photos/300/300?random=35	2026-01-18 14:16:53.906332+00
album_0036	In the Court of the Crimson King	King Crimson	1969	Progressive Rock	0.66	Europe	UK	0.91	https://picsum.photos/300/300?random=36	2026-01-18 14:16:53.906332+00
album_0037	Selling England by the Pound	Genesis	1973	Progressive Rock	0.62	Europe	UK	0.84	https://picsum.photos/300/300?random=37	2026-01-18 14:16:53.906332+00
album_0038	Paranoid	Black Sabbath	1970	Metal	0.82	Europe	UK	0.92	https://picsum.photos/300/300?random=38	2026-01-18 14:16:53.906332+00
album_0039	Machine Head	Deep Purple	1972	Rock	0.78	Europe	UK	0.87	https://picsum.photos/300/300?random=39	2026-01-18 14:16:53.906332+00
album_0040	Thriller	Michael Jackson	1982	Pop	0.72	North America	USA	0.99	https://picsum.photos/300/300?random=40	2026-01-18 14:16:53.906332+00
album_0041	Bad	Michael Jackson	1987	Pop	0.74	North America	USA	0.94	https://picsum.photos/300/300?random=41	2026-01-18 14:16:53.906332+00
album_0042	Purple Rain	Prince	1984	Pop	0.7	North America	USA	0.96	https://picsum.photos/300/300?random=42	2026-01-18 14:16:53.906332+00
album_0043	Like a Virgin	Madonna	1984	Pop	0.68	North America	USA	0.89	https://picsum.photos/300/300?random=43	2026-01-18 14:16:53.906332+00
album_0044	The Joshua Tree	U2	1987	Rock	0.65	Europe	Ireland	0.97	https://picsum.photos/300/300?random=44	2026-01-18 14:16:53.906332+00
album_0045	The Queen Is Dead	The Smiths	1986	Alternative Rock	0.58	Europe	UK	0.91	https://picsum.photos/300/300?random=45	2026-01-18 14:16:53.906332+00
album_0046	Disintegration	The Cure	1989	Alternative Rock	0.55	Europe	UK	0.89	https://picsum.photos/300/300?random=46	2026-01-18 14:16:53.906332+00
album_0047	Murmur	R.E.M.	1983	Alternative Rock	0.52	North America	USA	0.84	https://picsum.photos/300/300?random=47	2026-01-18 14:16:53.906332+00
album_0048	Remain in Light	Talking Heads	1980	New Wave	0.68	North America	USA	0.92	https://picsum.photos/300/300?random=48	2026-01-18 14:16:53.906332+00
album_0049	Synchronicity	The Police	1983	Rock	0.66	Europe	UK	0.91	https://picsum.photos/300/300?random=49	2026-01-18 14:16:53.906332+00
album_0050	Brothers in Arms	Dire Straits	1985	Rock	0.58	Europe	UK	0.88	https://picsum.photos/300/300?random=50	2026-01-18 14:16:53.906332+00
album_0051	Born in the U.S.A.	Bruce Springsteen	1984	Rock	0.64	North America	USA	0.93	https://picsum.photos/300/300?random=51	2026-01-18 14:16:53.906332+00
album_0052	Appetite for Destruction	Guns N' Roses	1987	Rock	0.8	North America	USA	0.95	https://picsum.photos/300/300?random=52	2026-01-18 14:16:53.906332+00
album_0053	Master of Puppets	Metallica	1986	Metal	0.88	North America	USA	0.94	https://picsum.photos/300/300?random=53	2026-01-18 14:16:53.906332+00
album_0054	The Number of the Beast	Iron Maiden	1982	Metal	0.85	Europe	UK	0.9	https://picsum.photos/300/300?random=54	2026-01-18 14:16:53.906332+00
album_0055	Raising Hell	Run-DMC	1986	Hip Hop	0.78	North America	USA	0.87	https://picsum.photos/300/300?random=55	2026-01-18 14:16:53.906332+00
album_0056	It Takes a Nation of Millions	Public Enemy	1988	Hip Hop	0.82	North America	USA	0.93	https://picsum.photos/300/300?random=56	2026-01-18 14:16:53.906332+00
album_0057	Straight Outta Compton	N.W.A	1988	Hip Hop	0.85	North America	USA	0.91	https://picsum.photos/300/300?random=57	2026-01-18 14:16:53.906332+00
album_0058	Licensed to Ill	Beastie Boys	1986	Hip Hop	0.76	North America	USA	0.86	https://picsum.photos/300/300?random=58	2026-01-18 14:16:53.906332+00
album_0059	Violator	Depeche Mode	1990	Electronic	0.72	Europe	UK	0.9	https://picsum.photos/300/300?random=59	2026-01-18 14:16:53.906332+00
album_0060	Nevermind	Nirvana	1991	Grunge	0.78	North America	USA	0.98	https://picsum.photos/300/300?random=60	2026-01-18 14:16:53.906332+00
album_0061	Ten	Pearl Jam	1991	Grunge	0.76	North America	USA	0.92	https://picsum.photos/300/300?random=61	2026-01-18 14:16:53.906332+00
album_0062	Superunknown	Soundgarden	1994	Grunge	0.8	North America	USA	0.88	https://picsum.photos/300/300?random=62	2026-01-18 14:16:53.906332+00
album_0063	Dirt	Alice in Chains	1992	Grunge	0.82	North America	USA	0.89	https://picsum.photos/300/300?random=63	2026-01-18 14:16:53.906332+00
album_0064	OK Computer	Radiohead	1997	Alternative Rock	0.65	Europe	UK	0.98	https://picsum.photos/300/300?random=64	2026-01-18 14:16:53.906332+00
album_0065	The Bends	Radiohead	1995	Alternative Rock	0.68	Europe	UK	0.91	https://picsum.photos/300/300?random=65	2026-01-18 14:16:53.906332+00
album_0066	Definitely Maybe	Oasis	1994	Britpop	0.7	Europe	UK	0.9	https://picsum.photos/300/300?random=66	2026-01-18 14:16:53.906332+00
album_0067	(What's the Story) Morning Glory?	Oasis	1995	Britpop	0.68	Europe	UK	0.95	https://picsum.photos/300/300?random=67	2026-01-18 14:16:53.906332+00
album_0068	Parklife	Blur	1994	Britpop	0.66	Europe	UK	0.88	https://picsum.photos/300/300?random=68	2026-01-18 14:16:53.906332+00
album_0069	Different Class	Pulp	1995	Britpop	0.64	Europe	UK	0.86	https://picsum.photos/300/300?random=69	2026-01-18 14:16:53.906332+00
album_0070	Urban Hymns	The Verve	1997	Britpop	0.62	Europe	UK	0.89	https://picsum.photos/300/300?random=70	2026-01-18 14:16:53.906332+00
album_0071	Automatic for the People	R.E.M.	1992	Alternative Rock	0.5	North America	USA	0.91	https://picsum.photos/300/300?random=71	2026-01-18 14:16:53.906332+00
album_0072	Siamese Dream	The Smashing Pumpkins	1993	Alternative Rock	0.74	North America	USA	0.89	https://picsum.photos/300/300?random=72	2026-01-18 14:16:53.906332+00
album_0073	Odelay	Beck	1996	Alternative Rock	0.68	North America	USA	0.86	https://picsum.photos/300/300?random=73	2026-01-18 14:16:53.906332+00
album_0074	The Chronic	Dr. Dre	1992	Hip Hop	0.76	North America	USA	0.94	https://picsum.photos/300/300?random=74	2026-01-18 14:16:53.906332+00
album_0075	Illmatic	Nas	1994	Hip Hop	0.72	North America	USA	0.96	https://picsum.photos/300/300?random=75	2026-01-18 14:16:53.906332+00
album_0076	Ready to Die	The Notorious B.I.G.	1994	Hip Hop	0.74	North America	USA	0.95	https://picsum.photos/300/300?random=76	2026-01-18 14:16:53.906332+00
album_0077	Enter the Wu-Tang	Wu-Tang Clan	1993	Hip Hop	0.78	North America	USA	0.93	https://picsum.photos/300/300?random=77	2026-01-18 14:16:53.906332+00
album_0078	The Low End Theory	A Tribe Called Quest	1991	Hip Hop	0.7	North America	USA	0.92	https://picsum.photos/300/300?random=78	2026-01-18 14:16:53.906332+00
album_0079	The Miseducation of Lauryn Hill	Lauryn Hill	1998	Hip Hop	0.65	North America	USA	0.94	https://picsum.photos/300/300?random=79	2026-01-18 14:16:53.906332+00
album_0080	Aquemini	OutKast	1998	Hip Hop	0.73	North America	USA	0.9	https://picsum.photos/300/300?random=80	2026-01-18 14:16:53.906332+00
album_0081	Homework	Daft Punk	1997	Electronic	0.82	Europe	France	0.91	https://picsum.photos/300/300?random=81	2026-01-18 14:16:53.906332+00
album_0082	The Fat of the Land	The Prodigy	1997	Electronic	0.88	Europe	UK	0.89	https://picsum.photos/300/300?random=82	2026-01-18 14:16:53.906332+00
album_0083	Dummy	Portishead	1994	Trip Hop	0.58	Europe	UK	0.92	https://picsum.photos/300/300?random=83	2026-01-18 14:16:53.906332+00
album_0084	Blue Lines	Massive Attack	1991	Trip Hop	0.6	Europe	UK	0.91	https://picsum.photos/300/300?random=84	2026-01-18 14:16:53.906332+00
album_0085	Kid A	Radiohead	2000	Electronic	0.68	Europe	UK	0.96	https://picsum.photos/300/300?random=85	2026-01-18 14:16:53.906332+00
album_0086	Is This It	The Strokes	2001	Indie Rock	0.72	North America	USA	0.93	https://picsum.photos/300/300?random=86	2026-01-18 14:16:53.906332+00
album_0087	White Blood Cells	The White Stripes	2001	Garage Rock	0.76	North America	USA	0.89	https://picsum.photos/300/300?random=87	2026-01-18 14:16:53.906332+00
album_0088	Whatever People Say I Am	Arctic Monkeys	2006	Indie Rock	0.74	Europe	UK	0.92	https://picsum.photos/300/300?random=88	2026-01-18 14:16:53.906332+00
album_0089	Funeral	Arcade Fire	2004	Indie Rock	0.65	North America	Canada	0.91	https://picsum.photos/300/300?random=89	2026-01-18 14:16:53.906332+00
album_0090	Turn On the Bright Lights	Interpol	2002	Post-Punk Revival	0.64	North America	USA	0.88	https://picsum.photos/300/300?random=90	2026-01-18 14:16:53.906332+00
album_0091	Fever to Tell	Yeah Yeah Yeahs	2003	Indie Rock	0.75	North America	USA	0.85	https://picsum.photos/300/300?random=91	2026-01-18 14:16:53.906332+00
album_0092	Hot Fuss	The Killers	2004	Indie Rock	0.7	North America	USA	0.87	https://picsum.photos/300/300?random=92	2026-01-18 14:16:53.906332+00
album_0093	Only by the Night	Kings of Leon	2008	Rock	0.68	North America	USA	0.84	https://picsum.photos/300/300?random=93	2026-01-18 14:16:53.906332+00
album_0094	Absolution	Muse	2003	Alternative Rock	0.78	Europe	UK	0.89	https://picsum.photos/300/300?random=94	2026-01-18 14:16:53.906332+00
album_0095	A Rush of Blood to the Head	Coldplay	2002	Alternative Rock	0.55	Europe	UK	0.92	https://picsum.photos/300/300?random=95	2026-01-18 14:16:53.906332+00
album_0096	The Marshall Mathers LP	Eminem	2000	Hip Hop	0.76	North America	USA	0.97	https://picsum.photos/300/300?random=96	2026-01-18 14:16:53.906332+00
album_0097	The Blueprint	Jay-Z	2001	Hip Hop	0.72	North America	USA	0.94	https://picsum.photos/300/300?random=97	2026-01-18 14:16:53.906332+00
album_0098	The College Dropout	Kanye West	2004	Hip Hop	0.7	North America	USA	0.95	https://picsum.photos/300/300?random=98	2026-01-18 14:16:53.906332+00
album_0099	Late Registration	Kanye West	2005	Hip Hop	0.72	North America	USA	0.93	https://picsum.photos/300/300?random=99	2026-01-18 14:16:53.906332+00
album_0100	Speakerboxxx/The Love Below	OutKast	2003	Hip Hop	0.74	North America	USA	0.96	https://picsum.photos/300/300?random=100	2026-01-18 14:16:53.906332+00
album_0101	Get Rich or Die Tryin'	50 Cent	2003	Hip Hop	0.78	North America	USA	0.91	https://picsum.photos/300/300?random=101	2026-01-18 14:16:53.906332+00
album_0102	Tha Carter III	Lil Wayne	2008	Hip Hop	0.75	North America	USA	0.89	https://picsum.photos/300/300?random=102	2026-01-18 14:16:53.906332+00
album_0103	Discovery	Daft Punk	2001	Electronic	0.8	Europe	France	0.95	https://picsum.photos/300/300?random=103	2026-01-18 14:16:53.906332+00
album_0104	Cross	Justice	2007	Electronic	0.85	Europe	France	0.87	https://picsum.photos/300/300?random=104	2026-01-18 14:16:53.906332+00
album_0105	Sound of Silver	LCD Soundsystem	2007	Electronic	0.73	North America	USA	0.9	https://picsum.photos/300/300?random=105	2026-01-18 14:16:53.906332+00
album_0106	Surrender	The Chemical Brothers	1999	Electronic	0.82	Europe	UK	0.88	https://picsum.photos/300/300?random=106	2026-01-18 14:16:53.906332+00
album_0107	Demon Days	Gorillaz	2005	Alternative	0.68	Europe	UK	0.91	https://picsum.photos/300/300?random=107	2026-01-18 14:16:53.906332+00
album_0108	Back to Black	Amy Winehouse	2006	Soul	0.52	Europe	UK	0.93	https://picsum.photos/300/300?random=108	2026-01-18 14:16:53.906332+00
album_0109	My Beautiful Dark Twisted Fantasy	Kanye West	2010	Hip Hop	0.75	North America	USA	0.98	https://picsum.photos/300/300?random=109	2026-01-18 14:16:53.906332+00
album_0110	good kid, m.A.A.d city	Kendrick Lamar	2012	Hip Hop	0.73	North America	USA	0.96	https://picsum.photos/300/300?random=110	2026-01-18 14:16:53.906332+00
album_0111	To Pimp a Butterfly	Kendrick Lamar	2015	Hip Hop	0.7	North America	USA	0.98	https://picsum.photos/300/300?random=111	2026-01-18 14:16:53.906332+00
album_0112	Take Care	Drake	2011	Hip Hop	0.68	North America	Canada	0.94	https://picsum.photos/300/300?random=112	2026-01-18 14:16:53.906332+00
album_0113	Channel Orange	Frank Ocean	2012	R&B	0.58	North America	USA	0.93	https://picsum.photos/300/300?random=113	2026-01-18 14:16:53.906332+00
album_0114	Blonde	Frank Ocean	2016	R&B	0.55	North America	USA	0.95	https://picsum.photos/300/300?random=114	2026-01-18 14:16:53.906332+00
album_0115	House of Balloons	The Weeknd	2011	R&B	0.62	North America	Canada	0.89	https://picsum.photos/300/300?random=115	2026-01-18 14:16:53.906332+00
album_0116	Because the Internet	Childish Gambino	2013	Hip Hop	0.71	North America	USA	0.86	https://picsum.photos/300/300?random=116	2026-01-18 14:16:53.906332+00
album_0117	Flower Boy	Tyler, The Creator	2017	Hip Hop	0.68	North America	USA	0.88	https://picsum.photos/300/300?random=117	2026-01-18 14:16:53.906332+00
album_0118	Bon Iver	Bon Iver	2011	Indie Folk	0.42	North America	USA	0.9	https://picsum.photos/300/300?random=118	2026-01-18 14:16:53.906332+00
album_0119	Helplessness Blues	Fleet Foxes	2011	Indie Folk	0.45	North America	USA	0.87	https://picsum.photos/300/300?random=119	2026-01-18 14:16:53.906332+00
album_0120	Modern Vampires of the City	Vampire Weekend	2013	Indie Rock	0.64	North America	USA	0.89	https://picsum.photos/300/300?random=120	2026-01-18 14:16:53.906332+00
album_0121	Lonerism	Tame Impala	2012	Psychedelic Rock	0.67	Oceania	Australia	0.88	https://picsum.photos/300/300?random=121	2026-01-18 14:16:53.906332+00
album_0122	Currents	Tame Impala	2015	Psychedelic Rock	0.7	Oceania	Australia	0.91	https://picsum.photos/300/300?random=122	2026-01-18 14:16:53.906332+00
album_0123	AM	Arctic Monkeys	2013	Indie Rock	0.72	Europe	UK	0.92	https://picsum.photos/300/300?random=123	2026-01-18 14:16:53.906332+00
album_0124	xx	The xx	2009	Indie Pop	0.52	Europe	UK	0.88	https://picsum.photos/300/300?random=124	2026-01-18 14:16:53.906332+00
album_0125	Pure Heroine	Lorde	2013	Pop	0.65	Oceania	New Zealand	0.89	https://picsum.photos/300/300?random=125	2026-01-18 14:16:53.906332+00
album_0126	Born to Die	Lana Del Rey	2012	Pop	0.55	North America	USA	0.87	https://picsum.photos/300/300?random=126	2026-01-18 14:16:53.906332+00
album_0127	Random Access Memories	Daft Punk	2013	Electronic	0.72	Europe	France	0.94	https://picsum.photos/300/300?random=127	2026-01-18 14:16:53.906332+00
album_0128	James Blake	James Blake	2011	Electronic	0.58	Europe	UK	0.86	https://picsum.photos/300/300?random=128	2026-01-18 14:16:53.906332+00
album_0129	LP1	FKA twigs	2014	Electronic	0.68	Europe	UK	0.84	https://picsum.photos/300/300?random=129	2026-01-18 14:16:53.906332+00
album_0130	The Bones of What You Believe	CHVRCHES	2013	Electronic	0.75	Europe	UK	0.85	https://picsum.photos/300/300?random=130	2026-01-18 14:16:53.906332+00
album_0131	I Love You, Honeybear	Father John Misty	2015	Indie Rock	0.54	North America	USA	0.83	https://picsum.photos/300/300?random=131	2026-01-18 14:16:53.906332+00
album_0132	St. Vincent	St. Vincent	2014	Art Rock	0.68	North America	USA	0.86	https://picsum.photos/300/300?random=132	2026-01-18 14:16:53.906332+00
album_0133	Salad Days	Mac DeMarco	2014	Indie Rock	0.56	North America	Canada	0.82	https://picsum.photos/300/300?random=133	2026-01-18 14:16:53.906332+00
album_0134	folklore	Taylor Swift	2020	Indie Folk	0.48	North America	USA	0.95	https://picsum.photos/300/300?random=134	2026-01-18 14:16:53.906332+00
album_0135	After Hours	The Weeknd	2020	R&B	0.68	North America	Canada	0.93	https://picsum.photos/300/300?random=135	2026-01-18 14:16:53.906332+00
album_0136	Future Nostalgia	Dua Lipa	2020	Pop	0.75	Europe	UK	0.91	https://picsum.photos/300/300?random=136	2026-01-18 14:16:53.906332+00
album_0137	Happier Than Ever	Billie Eilish	2021	Pop	0.58	North America	USA	0.89	https://picsum.photos/300/300?random=137	2026-01-18 14:16:53.906332+00
album_0138	SOUR	Olivia Rodrigo	2021	Pop Rock	0.68	North America	USA	0.92	https://picsum.photos/300/300?random=138	2026-01-18 14:16:53.906332+00
album_0139	MONTERO	Lil Nas X	2021	Hip Hop	0.76	North America	USA	0.87	https://picsum.photos/300/300?random=139	2026-01-18 14:16:53.906332+00
album_0140	Call Me If You Get Lost	Tyler, The Creator	2021	Hip Hop	0.72	North America	USA	0.9	https://picsum.photos/300/300?random=140	2026-01-18 14:16:53.906332+00
album_0141	30	Adele	2021	Pop	0.52	Europe	UK	0.94	https://picsum.photos/300/300?random=141	2026-01-18 14:16:53.906332+00
album_0142	The Suburbs	Arcade Fire	1999	Indie Rock	0.676597489755968	North America	Canada	0.8910279968468389	https://picsum.photos/300/300?random=142	2026-01-18 14:16:53.906332+00
album_0143	Reflektor	Arcade Fire	2005	Indie Rock	0.6664172877615893	North America	Canada	0.6792474599803904	https://picsum.photos/300/300?random=143	2026-01-18 14:16:53.906332+00
album_0144	Everything Now	Arcade Fire	2013	Indie Rock	0.6992736014120844	North America	Canada	0.7596557882091586	https://picsum.photos/300/300?random=144	2026-01-18 14:16:53.906332+00
album_0145	In Rainbows	Radiohead	2001	Alternative Rock	0.6138373597258769	Europe	UK	0.9440346089462033	https://picsum.photos/300/300?random=145	2026-01-18 14:16:53.906332+00
album_0146	Hail to the Thief	Radiohead	2020	Alternative Rock	0.594002090711534	Europe	UK	0.6736302568754573	https://picsum.photos/300/300?random=146	2026-01-18 14:16:53.906332+00
album_0147	Amnesiac	Radiohead	2012	Alternative Rock	0.6895407700297183	Europe	UK	0.7446784619145548	https://picsum.photos/300/300?random=147	2026-01-18 14:16:53.906332+00
album_0148	The Colour and the Shape	Foo Fighters	2022	Rock	0.6843791608979708	North America	USA	0.7676704589255081	https://picsum.photos/300/300?random=148	2026-01-18 14:16:53.906332+00
album_0149	There Is Nothing Left to Lose	Foo Fighters	2015	Rock	0.7673349264269672	North America	USA	0.7490089392235943	https://picsum.photos/300/300?random=149	2026-01-18 14:16:53.906332+00
album_0150	Wasting Light	Foo Fighters	2017	Rock	0.7128702204942687	North America	USA	0.8738813684969904	https://picsum.photos/300/300?random=150	2026-01-18 14:16:53.906332+00
album_0151	Blood Sugar Sex Magik	Red Hot Chili Peppers	2001	Rock	0.7491526654687184	North America	USA	0.6978941223167988	https://picsum.photos/300/300?random=151	2026-01-18 14:16:53.906332+00
album_0152	Californication	Red Hot Chili Peppers	2015	Rock	0.7123131413162048	North America	USA	0.7951446507452832	https://picsum.photos/300/300?random=152	2026-01-18 14:16:53.906332+00
album_0153	By the Way	Red Hot Chili Peppers	1997	Rock	0.7066071990246912	North America	USA	0.9210982418378617	https://picsum.photos/300/300?random=153	2026-01-18 14:16:53.906332+00
album_0154	Dookie	Green Day	1994	Punk Rock	0.7985263795074596	North America	USA	0.8328797593505457	https://picsum.photos/300/300?random=154	2026-01-18 14:16:53.906332+00
album_0155	American Idiot	Green Day	2000	Punk Rock	0.8216129852624601	North America	USA	0.9482212505618313	https://picsum.photos/300/300?random=155	2026-01-18 14:16:53.906332+00
album_0156	21st Century Breakdown	Green Day	2011	Punk Rock	0.7456930354049196	North America	USA	0.8308200266069271	https://picsum.photos/300/300?random=156	2026-01-18 14:16:53.906332+00
album_0157	Enema of the State	Blink-182	1995	Punk Rock	0.7388068701430336	North America	USA	0.6781614184413004	https://picsum.photos/300/300?random=157	2026-01-18 14:16:53.906332+00
album_0158	Take Off Your Pants and Jacket	Blink-182	1995	Punk Rock	0.7361336025961897	North America	USA	0.7852171219333943	https://picsum.photos/300/300?random=158	2026-01-18 14:16:53.906332+00
album_0159	Blink-182	Blink-182	2010	Punk Rock	0.7557138457627817	North America	USA	0.7818726375001718	https://picsum.photos/300/300?random=159	2026-01-18 14:16:53.906332+00
album_0160	Hybrid Theory	Linkin Park	2011	Nu Metal	0.8573980131356644	North America	USA	0.7703420941371899	https://picsum.photos/300/300?random=160	2026-01-18 14:16:53.906332+00
album_0161	Meteora	Linkin Park	1992	Nu Metal	0.8541437075428233	North America	USA	0.9370203232373653	https://picsum.photos/300/300?random=161	2026-01-18 14:16:53.906332+00
album_0162	Minutes to Midnight	Linkin Park	2023	Nu Metal	0.7808828551731691	North America	USA	0.7451347332829189	https://picsum.photos/300/300?random=162	2026-01-18 14:16:53.906332+00
album_0163	Korn	Korn	2022	Nu Metal	0.8720541513744395	North America	USA	0.8675287918485233	https://picsum.photos/300/300?random=163	2026-01-18 14:16:53.906332+00
album_0164	Follow the Leader	Korn	2017	Nu Metal	0.8964868745096509	North America	USA	0.666801054768651	https://picsum.photos/300/300?random=164	2026-01-18 14:16:53.906332+00
album_0165	Issues	Korn	2011	Nu Metal	0.8430407550237641	North America	USA	0.7399157741403593	https://picsum.photos/300/300?random=165	2026-01-18 14:16:53.906332+00
album_0166	Toxicity	System of a Down	2019	Metal	0.8866778681033275	North America	USA	0.8490740261035095	https://picsum.photos/300/300?random=166	2026-01-18 14:16:53.906332+00
album_0167	Mezmerize	System of a Down	2019	Metal	0.8611154809576204	North America	USA	0.8429134091435482	https://picsum.photos/300/300?random=167	2026-01-18 14:16:53.906332+00
album_0168	Hypnotize	System of a Down	2002	Metal	0.8331542574279607	North America	USA	0.7718208090624417	https://picsum.photos/300/300?random=168	2026-01-18 14:16:53.906332+00
album_0169	Iowa	Slipknot	1997	Metal	0.9445879911928148	North America	USA	0.9088733347409487	https://picsum.photos/300/300?random=169	2026-01-18 14:16:53.906332+00
album_0170	Vol. 3: The Subliminal Verses	Slipknot	1994	Metal	0.9172236033803511	North America	USA	0.8186709294904426	https://picsum.photos/300/300?random=170	2026-01-18 14:16:53.906332+00
album_0171	All Hope Is Gone	Slipknot	2021	Metal	0.8957747494638963	North America	USA	0.9292530479024144	https://picsum.photos/300/300?random=171	2026-01-18 14:16:53.906332+00
album_0172	Mutter	Rammstein	2020	Industrial Metal	0.8718170271521811	Europe	Germany	0.6104695986397968	https://picsum.photos/300/300?random=172	2026-01-18 14:16:53.906332+00
album_0173	Reise, Reise	Rammstein	2013	Industrial Metal	0.9041823022254987	Europe	Germany	0.849548632467732	https://picsum.photos/300/300?random=173	2026-01-18 14:16:53.906332+00
album_0174	Liebe ist für alle da	Rammstein	1991	Industrial Metal	0.8425833545887814	Europe	Germany	0.864602266071045	https://picsum.photos/300/300?random=174	2026-01-18 14:16:53.906332+00
album_0175	The Downward Spiral	Nine Inch Nails	2008	Industrial Rock	0.8585249873078776	North America	USA	0.8483491954662805	https://picsum.photos/300/300?random=175	2026-01-18 14:16:53.906332+00
album_0176	The Fragile	Nine Inch Nails	1997	Industrial Rock	0.8075470724561914	North America	USA	0.9090745017327594	https://picsum.photos/300/300?random=176	2026-01-18 14:16:53.906332+00
album_0177	With Teeth	Nine Inch Nails	1996	Industrial Rock	0.8521379460610035	North America	USA	0.8770139743850005	https://picsum.photos/300/300?random=177	2026-01-18 14:16:53.906332+00
album_0178	Homogenic	Björk	1997	Art Pop	0.6335576022349253	Europe	Iceland	0.6339874669147673	https://picsum.photos/300/300?random=178	2026-01-18 14:16:53.906332+00
album_0179	Vespertine	Björk	1991	Art Pop	0.6218832971257005	Europe	Iceland	0.7059067253341937	https://picsum.photos/300/300?random=179	2026-01-18 14:16:53.906332+00
album_0180	Medúlla	Björk	2021	Art Pop	0.5740781019207983	Europe	Iceland	0.9388523890139207	https://picsum.photos/300/300?random=180	2026-01-18 14:16:53.906332+00
album_0181	Mezzanine	Massive Attack	2009	Trip Hop	0.6368323358898047	Europe	UK	0.8155642213149479	https://picsum.photos/300/300?random=181	2026-01-18 14:16:53.906332+00
album_0182	100th Window	Massive Attack	2024	Trip Hop	0.5748154129545279	Europe	UK	0.6033011736915851	https://picsum.photos/300/300?random=182	2026-01-18 14:16:53.906332+00
album_0183	Heligoland	Massive Attack	2018	Trip Hop	0.6286500738072193	Europe	UK	0.7553103620255484	https://picsum.photos/300/300?random=183	2026-01-18 14:16:53.906332+00
album_0184	Play	Moby	1999	Electronic	0.7136043671528165	North America	USA	0.7204861826066877	https://picsum.photos/300/300?random=184	2026-01-18 14:16:53.906332+00
album_0185	18	Moby	2006	Electronic	0.6599740066252007	North America	USA	0.7055207222890496	https://picsum.photos/300/300?random=185	2026-01-18 14:16:53.906332+00
album_0186	Hotel	Moby	2013	Electronic	0.6888042195602179	North America	USA	0.8973487444926292	https://picsum.photos/300/300?random=186	2026-01-18 14:16:53.906332+00
album_0187	Selected Ambient Works 85-92	Aphex Twin	1991	Electronic	0.7242588280474157	Europe	UK	0.6177267031462964	https://picsum.photos/300/300?random=187	2026-01-18 14:16:53.906332+00
album_0188	Richard D. James Album	Aphex Twin	2017	Electronic	0.7947989892925672	Europe	UK	0.8690705364165279	https://picsum.photos/300/300?random=188	2026-01-18 14:16:53.906332+00
album_0189	Drukqs	Aphex Twin	2004	Electronic	0.7498459106942441	Europe	UK	0.7754604674544178	https://picsum.photos/300/300?random=189	2026-01-18 14:16:53.906332+00
album_0190	Music Has the Right to Children	Boards of Canada	2003	Electronic	0.5702379081318841	Europe	UK	0.6972070400215256	https://picsum.photos/300/300?random=190	2026-01-18 14:16:53.906332+00
album_0191	Geogaddi	Boards of Canada	2023	Electronic	0.5828407594026447	Europe	UK	0.8959684254836964	https://picsum.photos/300/300?random=191	2026-01-18 14:16:53.906332+00
album_0192	The Campfire Headphase	Boards of Canada	2009	Electronic	0.5853365142498463	Europe	UK	0.7224511033131011	https://picsum.photos/300/300?random=192	2026-01-18 14:16:53.906332+00
album_0193	Cosmogramma	Flying Lotus	2001	Electronic	0.697269772780718	North America	USA	0.8794694070654085	https://picsum.photos/300/300?random=193	2026-01-18 14:16:53.906332+00
album_0194	Until the Quiet Comes	Flying Lotus	2015	Electronic	0.6816335586447202	North America	USA	0.6650667915486292	https://picsum.photos/300/300?random=194	2026-01-18 14:16:53.906332+00
album_0195	You're Dead!	Flying Lotus	2015	Electronic	0.7419241993095604	North America	USA	0.7463722223217861	https://picsum.photos/300/300?random=195	2026-01-18 14:16:53.906332+00
album_0196	Donuts	J Dilla	2010	Hip Hop	0.7101953929979687	North America	USA	0.6922694530439077	https://picsum.photos/300/300?random=196	2026-01-18 14:16:53.906332+00
album_0197	The Shining	J Dilla	1998	Hip Hop	0.670588054313692	North America	USA	0.7959766654158028	https://picsum.photos/300/300?random=197	2026-01-18 14:16:53.906332+00
album_0198	Ruff Draft	J Dilla	2014	Hip Hop	0.6303167201029705	North America	USA	0.6221374396763406	https://picsum.photos/300/300?random=198	2026-01-18 14:16:53.906332+00
album_0199	Madvillainy	MF DOOM	2023	Hip Hop	0.760169062447887	North America	USA	0.7101031452093778	https://picsum.photos/300/300?random=199	2026-01-18 14:16:53.906332+00
album_0200	MM..FOOD	MF DOOM	2023	Hip Hop	0.747578225462352	North America	USA	0.6471268896431801	https://picsum.photos/300/300?random=200	2026-01-18 14:16:53.906332+00
album_0201	Born Like This	MF DOOM	2005	Hip Hop	0.6749815801616714	North America	USA	0.7468240872514698	https://picsum.photos/300/300?random=201	2026-01-18 14:16:53.906332+00
album_0202	Instrumentals	Clams Casino	1991	Hip Hop	0.6418694220930482	North America	USA	0.7500991798195028	https://picsum.photos/300/300?random=202	2026-01-18 14:16:53.906332+00
album_0203	Instrumentals 2	Clams Casino	2011	Hip Hop	0.6418400315582342	North America	USA	0.7967163873218134	https://picsum.photos/300/300?random=203	2026-01-18 14:16:53.906332+00
album_0204	32 Levels	Clams Casino	1996	Hip Hop	0.6321679592816091	North America	USA	0.6810648597161464	https://picsum.photos/300/300?random=204	2026-01-18 14:16:53.906332+00
album_0205	Malibu	Anderson .Paak	2003	R&B	0.6664872911322491	North America	USA	0.7567173673707872	https://picsum.photos/300/300?random=205	2026-01-18 14:16:53.906332+00
album_0206	Oxnard	Anderson .Paak	2022	R&B	0.6259173207492503	North America	USA	0.7769799295244022	https://picsum.photos/300/300?random=206	2026-01-18 14:16:53.906332+00
album_0207	Ventura	Anderson .Paak	1994	R&B	0.6779021583126915	North America	USA	0.7490493925545301	https://picsum.photos/300/300?random=207	2026-01-18 14:16:53.906332+00
album_0208	Ctrl	SZA	1993	R&B	0.5893361197448357	North America	USA	0.9314147291915076	https://picsum.photos/300/300?random=208	2026-01-18 14:16:53.906332+00
album_0209	SOS	SZA	1994	R&B	0.6395730817794469	North America	USA	0.612492124202744	https://picsum.photos/300/300?random=209	2026-01-18 14:16:53.906332+00
album_0210	H.E.R.	H.E.R.	2013	R&B	0.5445689374339587	North America	USA	0.6683306816118728	https://picsum.photos/300/300?random=210	2026-01-18 14:16:53.906332+00
album_0211	I Used to Know Her	H.E.R.	2008	R&B	0.5930758520853869	North America	USA	0.6517706214463143	https://picsum.photos/300/300?random=211	2026-01-18 14:16:53.906332+00
album_0212	The ArchAndroid	Janelle Monáe	2016	R&B	0.7153832862499797	North America	USA	0.7584990481941095	https://picsum.photos/300/300?random=212	2026-01-18 14:16:53.906332+00
album_0213	The Electric Lady	Janelle Monáe	2023	R&B	0.6675173642035237	North America	USA	0.6993859509675298	https://picsum.photos/300/300?random=213	2026-01-18 14:16:53.906332+00
album_0214	Dirty Computer	Janelle Monáe	1992	R&B	0.6628701107292412	North America	USA	0.8638557097704566	https://picsum.photos/300/300?random=214	2026-01-18 14:16:53.906332+00
album_0215	A Seat at the Table	Solange	2007	R&B	0.6097671191166086	North America	USA	0.8921172368649055	https://picsum.photos/300/300?random=215	2026-01-18 14:16:53.906332+00
album_0216	When I Get Home	Solange	2007	R&B	0.5683359449492119	North America	USA	0.6347481820898763	https://picsum.photos/300/300?random=216	2026-01-18 14:16:53.906332+00
album_0217	Brown Sugar	D'Angelo	2015	Soul	0.5367588776624613	North America	USA	0.9414961328680791	https://picsum.photos/300/300?random=217	2026-01-18 14:16:53.906332+00
album_0218	Voodoo	D'Angelo	2005	Soul	0.5659588952746113	North America	USA	0.8593327688321774	https://picsum.photos/300/300?random=218	2026-01-18 14:16:53.906332+00
album_0219	Black Messiah	D'Angelo	2005	Soul	0.5085612041129788	North America	USA	0.6953708144726605	https://picsum.photos/300/300?random=219	2026-01-18 14:16:53.906332+00
album_0220	Baduizm	Erykah Badu	2013	Soul	0.5561377745663338	North America	USA	0.753203702185413	https://picsum.photos/300/300?random=220	2026-01-18 14:16:53.906332+00
album_0221	Mama's Gun	Erykah Badu	2002	Soul	0.50174301938693	North America	USA	0.9287000712366646	https://picsum.photos/300/300?random=221	2026-01-18 14:16:53.906332+00
album_0222	Worldwide Underground	Erykah Badu	2005	Soul	0.5504392784514771	North America	USA	0.7611825147015104	https://picsum.photos/300/300?random=222	2026-01-18 14:16:53.906332+00
album_0223	Maxwell's Urban Hang Suite	Maxwell	2002	Soul	0.47528485690634104	North America	USA	0.6906239204370797	https://picsum.photos/300/300?random=223	2026-01-18 14:16:53.906332+00
album_0224	Embrya	Maxwell	2005	Soul	0.5177882375833087	North America	USA	0.7739962480227629	https://picsum.photos/300/300?random=224	2026-01-18 14:16:53.906332+00
album_0225	BLACKsummers'night	Maxwell	2010	Soul	0.4599357738959884	North America	USA	0.760628827723554	https://picsum.photos/300/300?random=225	2026-01-18 14:16:53.906332+00
album_0226	Songs in A Minor	Alicia Keys	1991	R&B	0.5013362870588126	North America	USA	0.938369168822426	https://picsum.photos/300/300?random=226	2026-01-18 14:16:53.906332+00
album_0227	The Diary of Alicia Keys	Alicia Keys	2003	R&B	0.5371763216519563	North America	USA	0.7356552865394126	https://picsum.photos/300/300?random=227	2026-01-18 14:16:53.906332+00
album_0228	As I Am	Alicia Keys	2006	R&B	0.5257874364599376	North America	USA	0.6313038622151786	https://picsum.photos/300/300?random=228	2026-01-18 14:16:53.906332+00
album_0229	Room for Squares	John Mayer	2006	Pop Rock	0.519476929120205	North America	USA	0.6086595331019546	https://picsum.photos/300/300?random=229	2026-01-18 14:16:53.906332+00
album_0230	Continuum	John Mayer	1996	Pop Rock	0.5177032915452534	North America	USA	0.6110055867239762	https://picsum.photos/300/300?random=230	2026-01-18 14:16:53.906332+00
album_0231	Born and Raised	John Mayer	2005	Pop Rock	0.4805311690168466	North America	USA	0.8416238724946159	https://picsum.photos/300/300?random=231	2026-01-18 14:16:53.906332+00
album_0232	Blunderbuss	Jack White	2014	Rock	0.7309230879003851	North America	USA	0.7976277641370036	https://picsum.photos/300/300?random=232	2026-01-18 14:16:53.906332+00
album_0233	Lazaretto	Jack White	1998	Rock	0.6953465978170696	North America	USA	0.6617010081254481	https://picsum.photos/300/300?random=233	2026-01-18 14:16:53.906332+00
album_0234	Boarding House Reach	Jack White	2024	Rock	0.722481344884538	North America	USA	0.8797557845710783	https://picsum.photos/300/300?random=234	2026-01-18 14:16:53.906332+00
album_0235	Brothers	Black Keys	2018	Blues Rock	0.7442079124712461	North America	USA	0.8749467040760186	https://picsum.photos/300/300?random=235	2026-01-18 14:16:53.906332+00
album_0236	El Camino	Black Keys	2006	Blues Rock	0.680597353053476	North America	USA	0.8552401833899401	https://picsum.photos/300/300?random=236	2026-01-18 14:16:53.906332+00
album_0237	Turn Blue	Black Keys	2002	Blues Rock	0.734356345420361	North America	USA	0.695453319100794	https://picsum.photos/300/300?random=237	2026-01-18 14:16:53.906332+00
album_0238	Melophobia	Cage the Elephant	1998	Alternative Rock	0.6784721203475091	North America	USA	0.6902012890505297	https://picsum.photos/300/300?random=238	2026-01-18 14:16:53.906332+00
album_0239	Tell Me I'm Pretty	Cage the Elephant	1990	Alternative Rock	0.7652628768551791	North America	USA	0.7028004643526411	https://picsum.photos/300/300?random=239	2026-01-18 14:16:53.906332+00
album_0240	Social Cues	Cage the Elephant	2016	Alternative Rock	0.7140213614269133	North America	USA	0.7629637227367974	https://picsum.photos/300/300?random=240	2026-01-18 14:16:53.906332+00
album_0241	Woodstock	Portugal. The Man	2024	Indie Rock	0.6516137326785445	North America	USA	0.6877498346943098	https://picsum.photos/300/300?random=241	2026-01-18 14:16:53.906332+00
album_0242	In the Mountain in the Cloud	Portugal. The Man	2004	Indie Rock	0.6135199588288441	North America	USA	0.8757444435292623	https://picsum.photos/300/300?random=242	2026-01-18 14:16:53.906332+00
album_0243	Torches	Foster the People	2013	Indie Pop	0.6700948071380675	North America	USA	0.6673445398004352	https://picsum.photos/300/300?random=243	2026-01-18 14:16:53.906332+00
album_0244	Supermodel	Foster the People	2020	Indie Pop	0.6495279120678613	North America	USA	0.7215013253779707	https://picsum.photos/300/300?random=244	2026-01-18 14:16:53.906332+00
album_0245	Sacred Hearts Club	Foster the People	2005	Indie Pop	0.721239541751102	North America	USA	0.8846747616606043	https://picsum.photos/300/300?random=245	2026-01-18 14:16:53.906332+00
album_0246	Oracular Spectacular	MGMT	1996	Psychedelic Pop	0.7263729118219627	North America	USA	0.7107023335310901	https://picsum.photos/300/300?random=246	2026-01-18 14:16:53.906332+00
album_0247	Congratulations	MGMT	2002	Psychedelic Pop	0.7442422080435562	North America	USA	0.8594472958932077	https://picsum.photos/300/300?random=247	2026-01-18 14:16:53.906332+00
album_0248	MGMT	MGMT	2004	Psychedelic Pop	0.7158508447623091	North America	USA	0.8739207136798355	https://picsum.photos/300/300?random=248	2026-01-18 14:16:53.906332+00
album_0249	Wolfgang Amadeus Phoenix	Phoenix	2005	Indie Pop	0.6448577892772993	Europe	France	0.6912790381077957	https://picsum.photos/300/300?random=249	2026-01-18 14:16:53.906332+00
album_0250	Bankrupt!	Phoenix	2003	Indie Pop	0.6577825543349521	Europe	France	0.7628484929166164	https://picsum.photos/300/300?random=250	2026-01-18 14:16:53.906332+00
album_0251	Ti Amo	Phoenix	2010	Indie Pop	0.6817136406667265	Europe	France	0.8871057720475475	https://picsum.photos/300/300?random=251	2026-01-18 14:16:53.906332+00
album_0252	Tourist History	Two Door Cinema Club	1999	Indie Rock	0.7665194600537675	Europe	Ireland	0.6149640338174537	https://picsum.photos/300/300?random=252	2026-01-18 14:16:53.906332+00
album_0253	Beacon	Two Door Cinema Club	2024	Indie Rock	0.7219795043699859	Europe	Ireland	0.6395673694206572	https://picsum.photos/300/300?random=253	2026-01-18 14:16:53.906332+00
album_0254	Gameshow	Two Door Cinema Club	2015	Indie Rock	0.7211094973701999	Europe	Ireland	0.8168137551603764	https://picsum.photos/300/300?random=254	2026-01-18 14:16:53.906332+00
album_0255	An Awesome Wave	Alt-J	1994	Indie Rock	0.6529848361651555	Europe	UK	0.945151147728062	https://picsum.photos/300/300?random=255	2026-01-18 14:16:53.906332+00
album_0256	This Is All Yours	Alt-J	1997	Indie Rock	0.6615274918748684	Europe	UK	0.6872873617161417	https://picsum.photos/300/300?random=256	2026-01-18 14:16:53.906332+00
album_0257	Relaxer	Alt-J	1998	Indie Rock	0.6779329251711638	Europe	UK	0.8386217514841219	https://picsum.photos/300/300?random=257	2026-01-18 14:16:53.906332+00
album_0258	Works 10	The Melodies	1977	Hip Hop	0.6923757473901686	North America	USA	0.5408181203079816	https://picsum.photos/300/300?random=258	2026-01-18 14:16:53.906332+00
album_0259	Chapter 3	Pitch Perfect	1995	K-Pop	0.8488680314040662	Asia	China	0.8301150696303425	https://picsum.photos/300/300?random=259	2026-01-18 14:16:53.906332+00
album_0260	Chapter 16	The Arpeggios	1993	Hip Hop	0.7815428828847234	North America	Canada	0.7393458759750422	https://picsum.photos/300/300?random=260	2026-01-18 14:16:53.906332+00
album_0261	The 4 Album	Chord Progressions	1984	Metal	0.8163756706343612	Europe	Sweden	0.7971178105078025	https://picsum.photos/300/300?random=261	2026-01-18 14:16:53.906332+00
album_0262	Works 14	Velvet Underground Revival	1976	Country	0.4609504199676625	North America	USA	0.5251767867745352	https://picsum.photos/300/300?random=262	2026-01-18 14:16:53.906332+00
album_0263	Collection 3	Velvet Underground Revival	1989	Metal	0.765160834559417	Europe	Italy	0.3147397096113826	https://picsum.photos/300/300?random=263	2026-01-18 14:16:53.906332+00
album_0264	Chapter 12	The Dynamics	1994	Latin	0.5838920074214996	South America	Argentina	0.46615173113611286	https://picsum.photos/300/300?random=264	2026-01-18 14:16:53.906332+00
album_0265	Session 18	Timbre	2021	Indie Rock	0.6868565064586555	North America	Canada	0.3432721062983744	https://picsum.photos/300/300?random=265	2026-01-18 14:16:53.906332+00
album_0266	Collection 17	Crescendo	2009	Electronic	0.7468650895563628	Europe	Spain	0.3088091792180467	https://picsum.photos/300/300?random=266	2026-01-18 14:16:53.906332+00
album_0267	Recordings 13	Major Sevenths	2007	Pop	0.7007617922818106	Asia	India	0.7564603059542377	https://picsum.photos/300/300?random=267	2026-01-18 14:16:53.906332+00
album_0268	Works 10	Frequency Shift	1987	Blues	0.584916793074143	North America	Canada	0.7396436009146383	https://picsum.photos/300/300?random=268	2026-01-18 14:16:53.906332+00
album_0269	Collection 15	The Syncopators	2024	Metal	0.9298226360071461	North America	Canada	0.5013551363816643	https://picsum.photos/300/300?random=269	2026-01-18 14:16:53.906332+00
album_0270	Suite 2	The Frequencies	2012	Country	0.482129725712912	North America	Canada	0.5636759488188912	https://picsum.photos/300/300?random=270	2026-01-18 14:16:53.906332+00
album_0271	Works 19	Echo Chamber	2006	K-Pop	0.7985481575528834	Asia	India	0.5831299739708119	https://picsum.photos/300/300?random=271	2026-01-18 14:16:53.906332+00
album_0272	Recordings 18	The Amplifiers	1977	Reggae	0.6046805439181062	Caribbean	Cuba	0.6671343326140261	https://picsum.photos/300/300?random=272	2026-01-18 14:16:53.906332+00
album_0273	Collection 15	The Arpeggios	1962	Classical	0.28137458486972844	Europe	Spain	0.4552127779005984	https://picsum.photos/300/300?random=273	2026-01-18 14:16:53.906332+00
album_0274	Symphony 1	The Arpeggios	2023	Rock	0.6531178457571801	North America	Mexico	0.6160607111996672	https://picsum.photos/300/300?random=274	2026-01-18 14:16:53.906332+00
album_0275	Opus 11	The Cadences	1979	J-Pop	0.6784841873937799	Asia	India	0.5777039995468848	https://picsum.photos/300/300?random=275	2026-01-18 14:16:53.906332+00
album_0276	Volume 18	Sonic Youth Jr.	2000	Electronic	0.7888563637716645	North America	Canada	0.5423323722500022	https://picsum.photos/300/300?random=276	2026-01-18 14:16:53.906332+00
album_0277	Session 8	Scale Runners	1986	J-Pop	0.7198966992259379	Asia	India	0.5317121153147101	https://picsum.photos/300/300?random=277	2026-01-18 14:16:53.906332+00
album_0278	Opus 9	Wavelength	2020	J-Pop	0.7681920647268442	Asia	South Korea	0.40960943305756703	https://picsum.photos/300/300?random=278	2026-01-18 14:16:53.906332+00
album_0279	Opus 13	The Soundscapes	2019	J-Pop	0.6898702888542072	Asia	South Korea	0.8027032026053471	https://picsum.photos/300/300?random=279	2026-01-18 14:16:53.906332+00
album_0280	Works 14	The Soundscapes	1987	Electronic	0.739462688470073	Europe	Germany	0.6989812664133457	https://picsum.photos/300/300?random=280	2026-01-18 14:16:53.906332+00
album_0281	Recordings 17	Neon Dreams	2019	Reggae	0.6627092314771379	Caribbean	Cuba	0.8401429894023211	https://picsum.photos/300/300?random=281	2026-01-18 14:16:53.906332+00
album_0282	Overture 3	Sonic Boom	1982	Indie Rock	0.779760855041061	North America	Canada	0.7977046397399077	https://picsum.photos/300/300?random=282	2026-01-18 14:16:53.906332+00
album_0283	Volume 3	The Soundscapes	2023	Classical	0.3969284426720473	Europe	Sweden	0.3701892049882646	https://picsum.photos/300/300?random=283	2026-01-18 14:16:53.906332+00
album_0284	Works 1	The Vibrations	1965	Rock	0.784603867715795	Europe	Sweden	0.44074034047880795	https://picsum.photos/300/300?random=284	2026-01-18 14:16:53.906332+00
album_0285	Works 17	Frequency Shift	1992	Latin	0.711291376212125	South America	Brazil	0.6971896264564248	https://picsum.photos/300/300?random=285	2026-01-18 14:16:53.906332+00
album_0286	Suite 14	Digital Natives	2014	K-Pop	0.7712804984966921	Asia	Japan	0.6249416134030488	https://picsum.photos/300/300?random=286	2026-01-18 14:16:53.906332+00
album_0287	The 2 Album	Acoustic Waves	2004	Pop	0.7125916649152132	Asia	Japan	0.47731963339784383	https://picsum.photos/300/300?random=287	2026-01-18 14:16:53.906332+00
album_0288	Collection 6	The Amplifiers	1995	Electronic	0.7068157054580235	North America	Mexico	0.32240880700160524	https://picsum.photos/300/300?random=288	2026-01-18 14:16:53.906332+00
album_0289	Symphony 14	The Intervals	1998	K-Pop	0.7193442559578062	Asia	China	0.8115293485787407	https://picsum.photos/300/300?random=289	2026-01-18 14:16:53.906332+00
album_0290	Session 13	Chord Progressions	1962	Latin	0.7676509142060941	South America	Colombia	0.7058638529099245	https://picsum.photos/300/300?random=290	2026-01-18 14:16:53.906332+00
album_0291	Collection 10	Pitch Perfect	1971	Rock	0.7016871695414599	Europe	Germany	0.48211198857651283	https://picsum.photos/300/300?random=291	2026-01-18 14:16:53.906332+00
album_0292	Chapter 17	Wavelength	1991	Latin	0.7764840624148234	South America	Brazil	0.8309941653150485	https://picsum.photos/300/300?random=292	2026-01-18 14:16:53.906332+00
album_0293	Recordings 1	The Vibrations	1967	Classical	0.3854561232684707	Europe	Sweden	0.4341712543270053	https://picsum.photos/300/300?random=293	2026-01-18 14:16:53.906332+00
album_0294	Recordings 9	Sonic Youth Jr.	1994	Indie Rock	0.7535394222293836	Europe	Germany	0.7054781870372315	https://picsum.photos/300/300?random=294	2026-01-18 14:16:53.906332+00
album_0295	Volume 17	Chord Progressions	1993	Hip Hop	0.7261271627422027	North America	Canada	0.6158953066796813	https://picsum.photos/300/300?random=295	2026-01-18 14:16:53.906332+00
album_0296	Volume 19	Crescendo	2001	K-Pop	0.7541604677392425	Asia	China	0.3553698897461863	https://picsum.photos/300/300?random=296	2026-01-18 14:16:53.906332+00
album_0297	Session 12	Acoustic Waves	1991	K-Pop	0.6938093570364493	Asia	China	0.49706110067209874	https://picsum.photos/300/300?random=297	2026-01-18 14:16:53.906332+00
album_0298	Recordings 15	The Oscillators	1974	K-Pop	0.6839197518915071	Asia	China	0.7289790795011597	https://picsum.photos/300/300?random=298	2026-01-18 14:16:53.906332+00
album_0299	Suite 10	Reverb Nation	1999	Blues	0.45244664715539074	North America	Canada	0.6907881887872458	https://picsum.photos/300/300?random=299	2026-01-18 14:16:53.906332+00
album_0300	Symphony 4	Harmonic Series	2024	Reggae	0.6999013371810834	Caribbean	Trinidad	0.4328122490148445	https://picsum.photos/300/300?random=300	2026-01-18 14:16:53.906332+00
album_0301	Symphony 4	Sonic Youth Jr.	1992	Rock	0.6513633573257236	Europe	Spain	0.3568737731138406	https://picsum.photos/300/300?random=301	2026-01-18 14:16:53.906332+00
album_0302	Works 18	Sonic Boom	2019	Indie Rock	0.7436674907498857	Europe	Germany	0.49452497180109956	https://picsum.photos/300/300?random=302	2026-01-18 14:16:53.906332+00
album_0303	Study No. 8	The Cadences	1997	Jazz	0.613080524533459	North America	Canada	0.5891878316150632	https://picsum.photos/300/300?random=303	2026-01-18 14:16:53.906332+00
album_0304	Opus 4	The Arpeggios	2014	Jazz	0.5665644225580049	North America	USA	0.3195841446047998	https://picsum.photos/300/300?random=304	2026-01-18 14:16:53.906332+00
album_0305	Chapter 10	Harmonic Series	1999	Classical	0.3167242106784889	Europe	Italy	0.6608299410524925	https://picsum.photos/300/300?random=305	2026-01-18 14:16:53.906332+00
album_0306	The 1 Album	Acoustic Waves	1983	Hip Hop	0.6701404568265232	North America	USA	0.7965582959231413	https://picsum.photos/300/300?random=306	2026-01-18 14:16:53.906332+00
album_0307	Session 9	Digital Natives	1961	Rock	0.7128348252266404	Europe	UK	0.7499572987310866	https://picsum.photos/300/300?random=307	2026-01-18 14:16:53.906332+00
album_0308	The 8 Album	Timbre	2019	Country	0.35372404027987925	North America	USA	0.44080771659592066	https://picsum.photos/300/300?random=308	2026-01-18 14:16:53.906332+00
album_0309	Collection 20	Wavelength	1962	Electronic	0.8290395753571732	North America	Canada	0.7388465997779663	https://picsum.photos/300/300?random=309	2026-01-18 14:16:53.906332+00
album_0310	Session 12	The Amplifiers	2012	Rock	0.7782317319589553	North America	Canada	0.3687478112900682	https://picsum.photos/300/300?random=310	2026-01-18 14:16:53.906332+00
album_0311	Collection 7	Minor Keys	2013	Rock	0.6451153907578235	North America	Canada	0.8644656640146287	https://picsum.photos/300/300?random=311	2026-01-18 14:16:53.906332+00
album_0312	Recordings 19	Scale Runners	2022	Punk	0.8222976577799497	North America	Mexico	0.5818978247883653	https://picsum.photos/300/300?random=312	2026-01-18 14:16:53.906332+00
album_0313	Works 7	Echo Chamber	1995	Indie Rock	0.7313822158670822	Europe	Sweden	0.3280751910512397	https://picsum.photos/300/300?random=313	2026-01-18 14:16:53.906332+00
album_0314	Recordings 18	Pitch Perfect	2022	J-Pop	0.6979957992480968	Asia	South Korea	0.514656063905653	https://picsum.photos/300/300?random=314	2026-01-18 14:16:53.906332+00
album_0315	Study No. 9	Chord Progressions	1975	Pop	0.6936182223670034	Asia	Japan	0.7719364171373715	https://picsum.photos/300/300?random=315	2026-01-18 14:16:53.906332+00
album_0316	Study No. 11	The Cadences	2011	Punk	0.7074917569995239	Europe	UK	0.6860532091010156	https://picsum.photos/300/300?random=316	2026-01-18 14:16:53.906332+00
album_0317	Opus 7	The Rhythmics	2001	Latin	0.587082273497793	South America	Colombia	0.7735315389028061	https://picsum.photos/300/300?random=317	2026-01-18 14:16:53.906332+00
album_0318	Opus 12	Velvet Underground Revival	2005	Blues	0.49523720634210144	North America	Canada	0.734807553093012	https://picsum.photos/300/300?random=318	2026-01-18 14:16:53.906332+00
album_0319	The 16 Album	Timbre	1968	Electronic	0.750407206461712	Europe	UK	0.605833348410286	https://picsum.photos/300/300?random=319	2026-01-18 14:16:53.906332+00
album_0320	Collection 4	Resonance	2018	Pop	0.7441674295461254	Asia	South Korea	0.5174589555983323	https://picsum.photos/300/300?random=320	2026-01-18 14:16:53.906332+00
album_0321	Session 17	Wavelength	2017	Hip Hop	0.6792031328383727	North America	Canada	0.7686331866227731	https://picsum.photos/300/300?random=321	2026-01-18 14:16:53.906332+00
album_0322	Volume 7	The Melodies	2009	Classical	0.21228804452422317	Europe	Spain	0.7274460451846594	https://picsum.photos/300/300?random=322	2026-01-18 14:16:53.906332+00
album_0323	Session 14	Decibel Rising	2000	Electronic	0.7682280825728833	Europe	Germany	0.6756186228585297	https://picsum.photos/300/300?random=323	2026-01-18 14:16:53.906332+00
album_0324	Volume 17	The Fundamentals	1961	Rock	0.6386539066243023	Europe	UK	0.7723659595312515	https://picsum.photos/300/300?random=324	2026-01-18 14:16:53.906332+00
album_0325	Study No. 1	Decibel Rising	1989	Reggae	0.6880484575734324	Caribbean	Trinidad	0.874651695803442	https://picsum.photos/300/300?random=325	2026-01-18 14:16:53.906332+00
album_0326	Collection 18	Crystal Method	1997	Jazz	0.5754298806114972	North America	Canada	0.7952900765472057	https://picsum.photos/300/300?random=326	2026-01-18 14:16:53.906332+00
album_0327	Session 10	Acoustic Waves	1961	Classical	0.3468961184916851	Europe	Germany	0.5393153894195193	https://picsum.photos/300/300?random=327	2026-01-18 14:16:53.906332+00
album_0328	Chapter 16	The Oscillators	2007	Pop	0.6971121804000424	North America	USA	0.5754760379303685	https://picsum.photos/300/300?random=328	2026-01-18 14:16:53.906332+00
album_0329	Chapter 11	Neon Dreams	1991	Classical	0.34727151882326346	Europe	Sweden	0.40610402513264376	https://picsum.photos/300/300?random=329	2026-01-18 14:16:53.906332+00
album_0330	Chapter 9	Echo Chamber	1963	Rock	0.7844319553073086	Europe	Sweden	0.6389423409332295	https://picsum.photos/300/300?random=330	2026-01-18 14:16:53.906332+00
album_0331	Recordings 11	Crescendo	1978	Rock	0.72821630753451	North America	Canada	0.3261625168681573	https://picsum.photos/300/300?random=331	2026-01-18 14:16:53.906332+00
album_0332	Works 14	The Harmonics	2004	Hip Hop	0.8215990593122361	North America	Canada	0.6263728371030894	https://picsum.photos/300/300?random=332	2026-01-18 14:16:53.906332+00
album_0333	The 19 Album	The Oscillators	2004	Country	0.4276612911410157	North America	USA	0.8734752471996863	https://picsum.photos/300/300?random=333	2026-01-18 14:16:53.906332+00
album_0334	Opus 8	Pitch Perfect	1990	K-Pop	0.6869988985472647	Asia	China	0.6814861370557286	https://picsum.photos/300/300?random=334	2026-01-18 14:16:53.906332+00
album_0335	Chapter 7	The Overtones	1969	K-Pop	0.8639132165731561	Asia	China	0.699691606199541	https://picsum.photos/300/300?random=335	2026-01-18 14:16:53.906332+00
album_0336	Recordings 15	Sonic Boom	2011	Reggae	0.5676774156885387	Caribbean	Jamaica	0.87947432031517	https://picsum.photos/300/300?random=336	2026-01-18 14:16:53.906332+00
album_0337	Chapter 6	The Overtones	2014	Latin	0.7651652528594998	South America	Brazil	0.5452251501108955	https://picsum.photos/300/300?random=337	2026-01-18 14:16:53.906332+00
album_0338	Opus 3	The Overtones	1983	J-Pop	0.6231664353149327	Asia	China	0.8979608741951515	https://picsum.photos/300/300?random=338	2026-01-18 14:16:53.906332+00
album_0339	Chapter 17	Timbre	1977	Reggae	0.6034818220139201	Caribbean	Jamaica	0.4014871459456382	https://picsum.photos/300/300?random=339	2026-01-18 14:16:53.906332+00
album_0340	Overture 10	Resonance	1969	Reggae	0.6114530923935498	Caribbean	Trinidad	0.3447823253950944	https://picsum.photos/300/300?random=340	2026-01-18 14:16:53.906332+00
album_0341	Volume 20	Timbre	1984	J-Pop	0.7710593985519371	Asia	Japan	0.7873988857884197	https://picsum.photos/300/300?random=341	2026-01-18 14:16:53.906332+00
album_0342	Recordings 1	The Frequencies	1988	Blues	0.5559879404897381	North America	USA	0.8841683954381254	https://picsum.photos/300/300?random=342	2026-01-18 14:16:53.906332+00
album_0343	Opus 1	Sonic Youth Jr.	2000	Indie Rock	0.6308860758149061	North America	Mexico	0.4906858369574864	https://picsum.photos/300/300?random=343	2026-01-18 14:16:53.906332+00
album_0344	Volume 15	The Dynamics	2013	Hip Hop	0.7358991214822604	North America	Canada	0.547529531784407	https://picsum.photos/300/300?random=344	2026-01-18 14:16:53.906332+00
album_0345	Symphony 15	The Syncopators	2004	Punk	0.7257845656136737	North America	USA	0.7705110686992698	https://picsum.photos/300/300?random=345	2026-01-18 14:16:53.906332+00
album_0346	Collection 18	Beat Collective	2005	J-Pop	0.6470180926645623	Asia	India	0.6639763917219572	https://picsum.photos/300/300?random=346	2026-01-18 14:16:53.906332+00
album_0347	Chapter 14	The Harmonics	1963	Country	0.5100886604121926	North America	USA	0.32116374795629915	https://picsum.photos/300/300?random=347	2026-01-18 14:16:53.906332+00
album_0348	Study No. 9	Frequency Shift	1968	Classical	0.25120238771384795	Europe	Sweden	0.7897131788371444	https://picsum.photos/300/300?random=348	2026-01-18 14:16:53.906332+00
album_0349	Recordings 14	Resonance	2004	Blues	0.4847851970084977	North America	Mexico	0.6287947593695087	https://picsum.photos/300/300?random=349	2026-01-18 14:16:53.906332+00
album_0350	Works 10	Scale Runners	1964	Metal	0.8446615780077444	Europe	Spain	0.5508881823293087	https://picsum.photos/300/300?random=350	2026-01-18 14:16:53.906332+00
album_0351	Collection 19	Crystal Method	1967	Pop	0.7031589861411304	Asia	India	0.4442820864001249	https://picsum.photos/300/300?random=351	2026-01-18 14:16:53.906332+00
album_0352	Session 7	Frequency Shift	1979	K-Pop	0.7158439482814309	Asia	China	0.4924142394921973	https://picsum.photos/300/300?random=352	2026-01-18 14:16:53.906332+00
album_0353	Chapter 13	The Melodies	1987	Latin	0.5964612388130511	South America	Argentina	0.585813392860705	https://picsum.photos/300/300?random=353	2026-01-18 14:16:53.906332+00
album_0354	Works 3	Resonance	2014	Indie Rock	0.7149600564898919	Europe	Spain	0.7844104465741721	https://picsum.photos/300/300?random=354	2026-01-18 14:16:53.906332+00
album_0355	Study No. 17	Reverb Nation	2021	Metal	0.9315563244454773	Europe	Spain	0.6525030081114831	https://picsum.photos/300/300?random=355	2026-01-18 14:16:53.906332+00
album_0356	The 5 Album	The Arpeggios	2024	J-Pop	0.7056244876595255	Asia	South Korea	0.6744813620156678	https://picsum.photos/300/300?random=356	2026-01-18 14:16:53.906332+00
album_0357	Collection 1	Major Sevenths	2023	Latin	0.7282875891847386	South America	Brazil	0.7302982691605068	https://picsum.photos/300/300?random=357	2026-01-18 14:16:53.906332+00
album_0358	Volume 9	The Arpeggios	2010	Reggae	0.5424695942814114	Caribbean	Trinidad	0.463667342470307	https://picsum.photos/300/300?random=358	2026-01-18 14:16:53.906332+00
album_0359	The 3 Album	Decibel Rising	1966	Hip Hop	0.6916831238576636	North America	Mexico	0.34184331658670225	https://picsum.photos/300/300?random=359	2026-01-18 14:16:53.906332+00
album_0360	Chapter 5	The Soundscapes	1989	Indie Rock	0.6702364108267955	North America	USA	0.37929564123833887	https://picsum.photos/300/300?random=360	2026-01-18 14:16:53.906332+00
album_0361	Collection 7	The Harmonics	2021	Reggae	0.706266764854629	Caribbean	Trinidad	0.48075359872340795	https://picsum.photos/300/300?random=361	2026-01-18 14:16:53.906332+00
album_0362	Works 5	Sonic Youth Jr.	1997	K-Pop	0.7546107189498167	Asia	South Korea	0.7740549251565547	https://picsum.photos/300/300?random=362	2026-01-18 14:16:53.906332+00
album_0363	Works 7	Analog Future	1991	Classical	0.2168606114925446	Europe	Sweden	0.4468033336196755	https://picsum.photos/300/300?random=363	2026-01-18 14:16:53.906332+00
album_0364	Chapter 15	The Rhythmics	1994	Country	0.4845795421614604	North America	Mexico	0.8442194425426126	https://picsum.photos/300/300?random=364	2026-01-18 14:16:53.906332+00
album_0365	Suite 11	Echo Chamber	1967	Hip Hop	0.6636786351113766	North America	Mexico	0.41921591932740776	https://picsum.photos/300/300?random=365	2026-01-18 14:16:53.906332+00
album_0366	Session 2	Sonic Youth Jr.	1969	Indie Rock	0.7511918089899052	Europe	France	0.42643588766641904	https://picsum.photos/300/300?random=366	2026-01-18 14:16:53.906332+00
album_0367	Recordings 19	The Soundscapes	1971	Electronic	0.8319519061716167	North America	Canada	0.8219650306678787	https://picsum.photos/300/300?random=367	2026-01-18 14:16:53.906332+00
album_0368	The 3 Album	Acoustic Waves	2018	Rock	0.6572054453439143	Europe	France	0.7992425565460217	https://picsum.photos/300/300?random=368	2026-01-18 14:16:53.906332+00
album_0369	Overture 16	The Amplifiers	2004	Hip Hop	0.771972355043432	North America	Canada	0.7493182948154167	https://picsum.photos/300/300?random=369	2026-01-18 14:16:53.906332+00
album_0370	Recordings 15	The Overtones	1986	Latin	0.7574119694420104	South America	Colombia	0.6994874228232626	https://picsum.photos/300/300?random=370	2026-01-18 14:16:53.906332+00
album_0371	Works 2	Crystal Method	1988	Country	0.5120306859833959	North America	Mexico	0.42088204322902845	https://picsum.photos/300/300?random=371	2026-01-18 14:16:53.906332+00
album_0372	Collection 1	The Rhythmics	2019	Latin	0.7658533204495237	South America	Brazil	0.6309107317067864	https://picsum.photos/300/300?random=372	2026-01-18 14:16:53.906332+00
album_0373	Symphony 8	Wavelength	1971	J-Pop	0.6490955850184238	Asia	South Korea	0.30052831461069346	https://picsum.photos/300/300?random=373	2026-01-18 14:16:53.906332+00
album_0374	Session 9	Major Sevenths	1986	Indie Rock	0.7010937727575881	North America	Mexico	0.7871059807887486	https://picsum.photos/300/300?random=374	2026-01-18 14:16:53.906332+00
album_0375	Recordings 18	Minor Keys	1960	Rock	0.7184253378584883	North America	Mexico	0.37019007172434837	https://picsum.photos/300/300?random=375	2026-01-18 14:16:53.906332+00
album_0376	Session 17	The Cadences	1964	Reggae	0.629044055686686	Caribbean	Cuba	0.8201572593115907	https://picsum.photos/300/300?random=376	2026-01-18 14:16:53.906332+00
album_0377	Suite 8	The Intervals	2006	Reggae	0.6161056975298311	Caribbean	Trinidad	0.35933866822507254	https://picsum.photos/300/300?random=377	2026-01-18 14:16:53.906332+00
album_0378	Overture 14	Harmonic Series	2010	Country	0.5330112042492197	North America	USA	0.6448456511419748	https://picsum.photos/300/300?random=378	2026-01-18 14:16:53.906332+00
album_0379	Session 9	Minor Keys	1989	Punk	0.8896447291044067	Europe	Italy	0.4423270828180937	https://picsum.photos/300/300?random=379	2026-01-18 14:16:53.906332+00
album_0380	Collection 6	Scale Runners	2004	Classical	0.3512296798580425	Europe	Italy	0.3984036337603234	https://picsum.photos/300/300?random=380	2026-01-18 14:16:53.906332+00
album_0381	Symphony 12	Scale Runners	1973	Hip Hop	0.72712095574282	North America	Mexico	0.31382524120317634	https://picsum.photos/300/300?random=381	2026-01-18 14:16:53.906332+00
album_0382	Works 16	Wavelength	2007	Latin	0.6512421586791615	South America	Brazil	0.8853754961758447	https://picsum.photos/300/300?random=382	2026-01-18 14:16:53.906332+00
album_0383	The 2 Album	Neon Dreams	1974	K-Pop	0.7461300632306858	Asia	Japan	0.4592144291153074	https://picsum.photos/300/300?random=383	2026-01-18 14:16:53.906332+00
album_0384	Collection 5	Analog Future	1984	Blues	0.5119354270237249	North America	Mexico	0.7699635211464075	https://picsum.photos/300/300?random=384	2026-01-18 14:16:53.906332+00
album_0385	Overture 6	Velvet Underground Revival	1987	Classical	0.3347571007164921	Europe	France	0.7363483676274785	https://picsum.photos/300/300?random=385	2026-01-18 14:16:53.906332+00
album_0386	Session 18	Decibel Rising	2020	J-Pop	0.725477113187348	Asia	India	0.43606029208186015	https://picsum.photos/300/300?random=386	2026-01-18 14:16:53.906332+00
album_0387	Study No. 12	Acoustic Waves	2002	Electronic	0.7820932777531122	North America	Mexico	0.8349949023855552	https://picsum.photos/300/300?random=387	2026-01-18 14:16:53.906332+00
album_0388	Chapter 1	The Fundamentals	2015	Rock	0.7812888259614842	North America	Canada	0.8340833761291773	https://picsum.photos/300/300?random=388	2026-01-18 14:16:53.906332+00
album_0389	Recordings 15	Velvet Underground Revival	2021	Blues	0.4530875726075633	North America	USA	0.6622555190536207	https://picsum.photos/300/300?random=389	2026-01-18 14:16:53.906332+00
album_0390	Symphony 5	Sonic Boom	1978	Reggae	0.6371179778105189	Caribbean	Trinidad	0.47676579199625374	https://picsum.photos/300/300?random=390	2026-01-18 14:16:53.906332+00
album_0391	Recordings 12	Digital Natives	2010	Classical	0.23432828364591177	Europe	Sweden	0.32449086204993266	https://picsum.photos/300/300?random=391	2026-01-18 14:16:53.906332+00
album_0392	Collection 2	Digital Natives	2016	Country	0.4438814822164807	North America	USA	0.3884711341331719	https://picsum.photos/300/300?random=392	2026-01-18 14:16:53.906332+00
album_0393	Opus 19	The Syncopators	1972	Pop	0.5702629428124266	Asia	China	0.8807854402176551	https://picsum.photos/300/300?random=393	2026-01-18 14:16:53.906332+00
album_0394	Collection 18	The Syncopators	1975	Classical	0.3789124702708828	Europe	UK	0.38045792782061416	https://picsum.photos/300/300?random=394	2026-01-18 14:16:53.906332+00
album_0395	Study No. 4	The Fundamentals	1994	Rock	0.6984680771581143	North America	USA	0.7235778040224887	https://picsum.photos/300/300?random=395	2026-01-18 14:16:53.906332+00
album_0396	Overture 8	Crystal Method	2008	J-Pop	0.6545099626722238	Asia	China	0.5854333233417166	https://picsum.photos/300/300?random=396	2026-01-18 14:16:53.906332+00
album_0397	Study No. 2	Pitch Perfect	2023	Jazz	0.5970101109220128	North America	Canada	0.45736223099438345	https://picsum.photos/300/300?random=397	2026-01-18 14:16:53.906332+00
album_0398	Opus 14	Acoustic Waves	1974	Reggae	0.6308759657123364	Caribbean	Cuba	0.819504734437015	https://picsum.photos/300/300?random=398	2026-01-18 14:16:53.906332+00
album_0399	Symphony 5	The Syncopators	1986	Electronic	0.8728869366203651	North America	Canada	0.6482447499353561	https://picsum.photos/300/300?random=399	2026-01-18 14:16:53.906332+00
album_0400	The 13 Album	Harmonic Series	2015	Rock	0.7571665227151394	Europe	France	0.6090977356989483	https://picsum.photos/300/300?random=400	2026-01-18 14:16:53.906332+00
album_0401	Session 18	The Dynamics	1985	Blues	0.5423556888612762	North America	USA	0.32495163706357305	https://picsum.photos/300/300?random=401	2026-01-18 14:16:53.906332+00
album_0402	Overture 9	Crystal Method	2019	Country	0.5079479337134569	North America	Canada	0.551980841001487	https://picsum.photos/300/300?random=402	2026-01-18 14:16:53.906332+00
album_0403	Recordings 3	The Amplifiers	1977	Hip Hop	0.8408390776297558	North America	USA	0.563417937506594	https://picsum.photos/300/300?random=403	2026-01-18 14:16:53.906332+00
album_0404	Volume 6	The Rhythmics	2022	Jazz	0.5241872159887092	North America	Canada	0.4227994934310912	https://picsum.photos/300/300?random=404	2026-01-18 14:16:53.906332+00
album_0405	Collection 10	The Vibrations	2012	Metal	0.7708436844567021	North America	USA	0.34710192352148184	https://picsum.photos/300/300?random=405	2026-01-18 14:16:53.906332+00
album_0406	Study No. 6	Digital Natives	1972	Jazz	0.6035814921396727	North America	Canada	0.7168548199859934	https://picsum.photos/300/300?random=406	2026-01-18 14:16:53.906332+00
album_0407	Opus 19	Timbre	2011	Country	0.4680207935013528	North America	USA	0.8239891648375359	https://picsum.photos/300/300?random=407	2026-01-18 14:16:53.906332+00
album_0408	Collection 10	Frequency Shift	1979	Indie Rock	0.5921211761724026	Europe	UK	0.4659329376307044	https://picsum.photos/300/300?random=408	2026-01-18 14:16:53.906332+00
album_0409	Symphony 10	Chord Progressions	1972	Pop	0.6434253736132927	Europe	Germany	0.5671061831524231	https://picsum.photos/300/300?random=409	2026-01-18 14:16:53.906332+00
album_0410	Collection 9	The Fundamentals	1978	Rock	0.785243981745379	Europe	Italy	0.40170990319113714	https://picsum.photos/300/300?random=410	2026-01-18 14:16:53.906332+00
album_0411	Volume 5	Minor Keys	2002	J-Pop	0.6922802152071256	Asia	Japan	0.7015334265112283	https://picsum.photos/300/300?random=411	2026-01-18 14:16:53.906332+00
album_0412	Symphony 13	Reverb Nation	2020	Indie Rock	0.6192770040403202	Europe	Spain	0.379501859189839	https://picsum.photos/300/300?random=412	2026-01-18 14:16:53.906332+00
album_0413	Overture 16	Reverb Nation	1993	Hip Hop	0.6864559520705619	North America	Mexico	0.6166193306345222	https://picsum.photos/300/300?random=413	2026-01-18 14:16:53.906332+00
album_0414	Overture 3	The Amplifiers	1975	Reggae	0.6405778463780291	Caribbean	Trinidad	0.3805719266396041	https://picsum.photos/300/300?random=414	2026-01-18 14:16:53.906332+00
album_0415	Collection 17	Timbre	1977	Electronic	0.8349541904642386	North America	Mexico	0.3638862222143896	https://picsum.photos/300/300?random=415	2026-01-18 14:16:53.906332+00
album_0416	The 5 Album	Groove Theory	2000	Classical	0.2447048098739018	Europe	Germany	0.6889061843639505	https://picsum.photos/300/300?random=416	2026-01-18 14:16:53.906332+00
album_0417	Symphony 11	Wavelength	1982	Indie Rock	0.6596524551118684	Europe	Italy	0.7302317343351056	https://picsum.photos/300/300?random=417	2026-01-18 14:16:53.906332+00
album_0418	Study No. 19	Sonic Boom	2012	Rock	0.610034582189076	Europe	Germany	0.3651161258848654	https://picsum.photos/300/300?random=418	2026-01-18 14:16:53.906332+00
album_0419	Study No. 2	Crescendo	1960	Jazz	0.5355643541654197	North America	Mexico	0.37274044693611974	https://picsum.photos/300/300?random=419	2026-01-18 14:16:53.906332+00
album_0420	Suite 18	Velvet Underground Revival	2024	Reggae	0.5923155065467873	Caribbean	Jamaica	0.41892297336198	https://picsum.photos/300/300?random=420	2026-01-18 14:16:53.906332+00
album_0421	Symphony 15	The Soundscapes	2003	Blues	0.42355875778649144	North America	Canada	0.8218404527070884	https://picsum.photos/300/300?random=421	2026-01-18 14:16:53.906332+00
album_0422	Recordings 6	The Melodies	2008	Reggae	0.524868759990486	Caribbean	Jamaica	0.5689163791369436	https://picsum.photos/300/300?random=422	2026-01-18 14:16:53.906332+00
album_0423	Chapter 2	The Intervals	1977	Rock	0.6682732066798686	North America	Canada	0.3453383486332319	https://picsum.photos/300/300?random=423	2026-01-18 14:16:53.906332+00
album_0424	Volume 3	The Vibrations	1964	Metal	0.9036056643238068	Europe	France	0.38194976718590096	https://picsum.photos/300/300?random=424	2026-01-18 14:16:53.906332+00
album_0425	Opus 8	The Oscillators	1960	Pop	0.5629897073621992	Europe	Spain	0.6146695420680558	https://picsum.photos/300/300?random=425	2026-01-18 14:16:53.906332+00
album_0426	Study No. 6	Resonance	1976	Metal	0.7557824022796615	North America	Canada	0.7086164204653574	https://picsum.photos/300/300?random=426	2026-01-18 14:16:53.906332+00
album_0427	Works 20	Velvet Underground Revival	2014	Blues	0.4384565074393676	North America	Canada	0.5742248619503396	https://picsum.photos/300/300?random=427	2026-01-18 14:16:53.906332+00
album_0428	Overture 10	The Intervals	2008	Jazz	0.6385301788079905	North America	Mexico	0.756047513898511	https://picsum.photos/300/300?random=428	2026-01-18 14:16:53.906332+00
album_0429	Opus 5	The Melodies	1975	Metal	0.9399439140995227	Europe	UK	0.6306349079673453	https://picsum.photos/300/300?random=429	2026-01-18 14:16:53.906332+00
album_0430	Works 12	Groove Theory	2004	Jazz	0.6152479658500171	North America	Mexico	0.6896249101165411	https://picsum.photos/300/300?random=430	2026-01-18 14:16:53.906332+00
album_0431	The 10 Album	Minor Keys	2024	Blues	0.4473692417684837	North America	Canada	0.3589547115718781	https://picsum.photos/300/300?random=431	2026-01-18 14:16:53.906332+00
album_0432	Collection 17	Velvet Underground Revival	1986	Jazz	0.53414320954058	North America	Canada	0.37557142828028783	https://picsum.photos/300/300?random=432	2026-01-18 14:16:53.906332+00
album_0433	Volume 18	The Intervals	2022	Indie Rock	0.7169163460919118	Europe	Sweden	0.4482511186830228	https://picsum.photos/300/300?random=433	2026-01-18 14:16:53.906332+00
album_0434	Session 12	The Syncopators	1973	Classical	0.343122179163701	Europe	UK	0.81022403892935	https://picsum.photos/300/300?random=434	2026-01-18 14:16:53.906332+00
album_0435	Collection 15	Pitch Perfect	2010	Punk	0.8572109881119607	Europe	Germany	0.7663614929801498	https://picsum.photos/300/300?random=435	2026-01-18 14:16:53.906332+00
album_0436	Study No. 1	The Overtones	1985	Rock	0.6148993577791552	North America	USA	0.8302290122295302	https://picsum.photos/300/300?random=436	2026-01-18 14:16:53.906332+00
album_0437	Recordings 16	The Intervals	1991	Indie Rock	0.7353621168910576	North America	USA	0.6908566832164467	https://picsum.photos/300/300?random=437	2026-01-18 14:16:53.906332+00
album_0438	Collection 13	Tempo Changes	1960	Electronic	0.8653538296617808	North America	USA	0.8132963790156114	https://picsum.photos/300/300?random=438	2026-01-18 14:16:53.906332+00
album_0439	The 13 Album	Sonic Youth Jr.	1988	Reggae	0.6959761429340111	Caribbean	Trinidad	0.648169607674165	https://picsum.photos/300/300?random=439	2026-01-18 14:16:53.906332+00
album_0440	Symphony 4	The Vibrations	1975	Electronic	0.748053050466099	Europe	Sweden	0.694157515336883	https://picsum.photos/300/300?random=440	2026-01-18 14:16:53.906332+00
album_0441	Symphony 19	Velvet Underground Revival	1976	Country	0.3843355608317012	North America	Canada	0.3332220937334903	https://picsum.photos/300/300?random=441	2026-01-18 14:16:53.906332+00
album_0442	Overture 17	Echo Chamber	1976	Latin	0.7684004545656262	South America	Argentina	0.6616357675073528	https://picsum.photos/300/300?random=442	2026-01-18 14:16:53.906332+00
album_0443	The 17 Album	Pitch Perfect	1960	Metal	0.9481876526350839	Europe	France	0.4380666467626749	https://picsum.photos/300/300?random=443	2026-01-18 14:16:53.906332+00
album_0444	Volume 15	The Rhythmics	1974	Blues	0.4694798453011595	North America	Canada	0.43978316657264926	https://picsum.photos/300/300?random=444	2026-01-18 14:16:53.906332+00
album_0445	Suite 2	Pitch Perfect	1981	K-Pop	0.7692606452053689	Asia	India	0.3667116871461338	https://picsum.photos/300/300?random=445	2026-01-18 14:16:53.906332+00
album_0446	Collection 2	The Fundamentals	1966	Punk	0.7544471238897449	Europe	Sweden	0.7662512907940433	https://picsum.photos/300/300?random=446	2026-01-18 14:16:53.906332+00
album_0447	The 11 Album	Beat Collective	1990	K-Pop	0.8381122976451972	Asia	India	0.48558848524090736	https://picsum.photos/300/300?random=447	2026-01-18 14:16:53.906332+00
album_0448	Opus 14	Wavelength	1984	Metal	0.7868176965565873	Europe	Germany	0.8064402575089811	https://picsum.photos/300/300?random=448	2026-01-18 14:16:53.906332+00
album_0449	Volume 10	The Harmonics	1997	Jazz	0.45142986930033874	North America	Mexico	0.4155827921083235	https://picsum.photos/300/300?random=449	2026-01-18 14:16:53.906332+00
album_0450	Overture 10	The Frequencies	1982	Classical	0.2721708968142572	Europe	France	0.3174809345648469	https://picsum.photos/300/300?random=450	2026-01-18 14:16:53.906332+00
album_0451	Chapter 6	Echo Chamber	2021	Electronic	0.7537701221011348	North America	Mexico	0.8203768471944535	https://picsum.photos/300/300?random=451	2026-01-18 14:16:53.906332+00
album_0452	Opus 1	The Arpeggios	2011	Rock	0.7493185352940674	North America	Mexico	0.6619562470366834	https://picsum.photos/300/300?random=452	2026-01-18 14:16:53.906332+00
album_0453	Overture 3	Minor Keys	2020	Latin	0.7035132271068494	South America	Argentina	0.5876337406815312	https://picsum.photos/300/300?random=453	2026-01-18 14:16:53.906332+00
album_0454	Overture 8	Digital Natives	1960	Country	0.5158261367525843	North America	Mexico	0.8642801075996522	https://picsum.photos/300/300?random=454	2026-01-18 14:16:53.906332+00
album_0455	Chapter 7	Neon Dreams	1992	Pop	0.5944996668264566	North America	Canada	0.6299274040894733	https://picsum.photos/300/300?random=455	2026-01-18 14:16:53.906332+00
album_0456	Collection 9	Groove Theory	2005	Punk	0.7017778363156731	North America	Canada	0.5584477501698932	https://picsum.photos/300/300?random=456	2026-01-18 14:16:53.906332+00
album_0457	Session 7	Groove Theory	1989	Country	0.4790567049914408	North America	Mexico	0.5600752512532574	https://picsum.photos/300/300?random=457	2026-01-18 14:16:53.906332+00
album_0458	Opus 17	Sonic Youth Jr.	1981	Metal	0.9183889830731959	North America	USA	0.3413461843505774	https://picsum.photos/300/300?random=458	2026-01-18 14:16:53.906332+00
album_0459	Chapter 14	The Syncopators	1994	Rock	0.7232433514384926	North America	Mexico	0.6950166907331958	https://picsum.photos/300/300?random=459	2026-01-18 14:16:53.906332+00
album_0460	Opus 1	Scale Runners	1997	Blues	0.40857720594629127	North America	USA	0.648160800605668	https://picsum.photos/300/300?random=460	2026-01-18 14:16:53.906332+00
album_0461	Opus 11	Analog Future	1990	Jazz	0.5012832709790824	North America	USA	0.7122956824785324	https://picsum.photos/300/300?random=461	2026-01-18 14:16:53.906332+00
album_0462	Session 16	Resonance	1996	Country	0.48563916754368613	North America	Canada	0.7222877289348858	https://picsum.photos/300/300?random=462	2026-01-18 14:16:53.906332+00
album_0463	Volume 8	Groove Theory	2008	Metal	0.8233758844580878	Europe	Germany	0.7090664492670183	https://picsum.photos/300/300?random=463	2026-01-18 14:16:53.906332+00
album_0464	Session 19	Tempo Changes	2022	Classical	0.2920347578135182	Europe	Germany	0.393717859711535	https://picsum.photos/300/300?random=464	2026-01-18 14:16:53.906332+00
album_0465	Symphony 9	Frequency Shift	2022	Country	0.44994696234175036	North America	Canada	0.8683280130200113	https://picsum.photos/300/300?random=465	2026-01-18 14:16:53.906332+00
album_0466	Works 7	The Soundscapes	2010	Country	0.45027663920495864	North America	Mexico	0.5083558639398014	https://picsum.photos/300/300?random=466	2026-01-18 14:16:53.906332+00
album_0467	Collection 8	The Dynamics	1968	Pop	0.6987207517869787	Asia	Japan	0.44054567032007663	https://picsum.photos/300/300?random=467	2026-01-18 14:16:53.906332+00
album_0468	Study No. 8	Timbre	2024	Indie Rock	0.6322227111746992	North America	Mexico	0.6714008674449919	https://picsum.photos/300/300?random=468	2026-01-18 14:16:53.906332+00
album_0469	The 5 Album	Echo Chamber	2013	Classical	0.2542904374635439	Europe	UK	0.3960644825169142	https://picsum.photos/300/300?random=469	2026-01-18 14:16:53.906332+00
album_0470	The 4 Album	The Oscillators	2001	Pop	0.5881307238486957	Europe	Sweden	0.6806550552597579	https://picsum.photos/300/300?random=470	2026-01-18 14:16:53.906332+00
album_0471	The 5 Album	The Vibrations	1980	Classical	0.33789279048901216	Europe	Sweden	0.6935640423103481	https://picsum.photos/300/300?random=471	2026-01-18 14:16:53.906332+00
album_0472	Collection 11	The Vibrations	2004	Metal	0.7847590424827723	North America	Canada	0.31518546902708705	https://picsum.photos/300/300?random=472	2026-01-18 14:16:53.906332+00
album_0473	Works 8	The Soundscapes	2004	Punk	0.7168487077168075	North America	USA	0.7759940466516404	https://picsum.photos/300/300?random=473	2026-01-18 14:16:53.906332+00
album_0474	Recordings 20	The Cadences	1965	Indie Rock	0.7099482100495786	Europe	Italy	0.7186461031897957	https://picsum.photos/300/300?random=474	2026-01-18 14:16:53.906332+00
album_0475	Works 13	The Vibrations	1960	Electronic	0.8121747032009728	North America	Canada	0.5479948764638509	https://picsum.photos/300/300?random=475	2026-01-18 14:16:53.906332+00
album_0476	Works 4	Analog Future	1962	Metal	0.816972171518535	Europe	France	0.37876480163726955	https://picsum.photos/300/300?random=476	2026-01-18 14:16:53.906332+00
album_0477	Symphony 4	Reverb Nation	1994	Hip Hop	0.7706373861129168	North America	Mexico	0.49525457026514963	https://picsum.photos/300/300?random=477	2026-01-18 14:16:53.906332+00
album_0478	Recordings 19	The Overtones	1987	Metal	0.9084434809345328	North America	Canada	0.8508081935277971	https://picsum.photos/300/300?random=478	2026-01-18 14:16:53.906332+00
album_0479	Opus 6	The Melodies	1979	Indie Rock	0.6837282524420439	Europe	Spain	0.4041687300214019	https://picsum.photos/300/300?random=479	2026-01-18 14:16:53.906332+00
album_0480	Collection 5	Crescendo	2008	Metal	0.7756532544090751	North America	Canada	0.3045705622804241	https://picsum.photos/300/300?random=480	2026-01-18 14:16:53.906332+00
album_0481	Session 10	The Fundamentals	1978	Pop	0.7085897573068501	Europe	Italy	0.4477760111029811	https://picsum.photos/300/300?random=481	2026-01-18 14:16:53.906332+00
album_0482	Suite 3	The Melodies	1992	Pop	0.6056987380976945	North America	USA	0.7922765553204704	https://picsum.photos/300/300?random=482	2026-01-18 14:16:53.906332+00
album_0483	Opus 13	The Soundscapes	1986	Jazz	0.5789931599520091	North America	Canada	0.5491718746225122	https://picsum.photos/300/300?random=483	2026-01-18 14:16:53.906332+00
album_0484	Opus 10	The Frequencies	2020	Indie Rock	0.6202494902762262	Europe	Sweden	0.697902648810685	https://picsum.photos/300/300?random=484	2026-01-18 14:16:53.906332+00
album_0485	Works 18	Groove Theory	1983	Punk	0.890025669480699	North America	Mexico	0.5165376737727039	https://picsum.photos/300/300?random=485	2026-01-18 14:16:53.906332+00
album_0486	Session 11	Reverb Nation	2015	Jazz	0.47727157451934016	North America	Mexico	0.3479114029444917	https://picsum.photos/300/300?random=486	2026-01-18 14:16:53.906332+00
album_0487	Works 6	The Arpeggios	2020	Pop	0.637735663719512	Europe	UK	0.6079700911418354	https://picsum.photos/300/300?random=487	2026-01-18 14:16:53.906332+00
album_0488	Collection 18	Harmonic Series	2018	Hip Hop	0.7418087742007183	North America	USA	0.4555416249129578	https://picsum.photos/300/300?random=488	2026-01-18 14:16:53.906332+00
album_0489	Overture 2	Velvet Underground Revival	1997	Metal	0.7869961466713153	Europe	Germany	0.8121365921623309	https://picsum.photos/300/300?random=489	2026-01-18 14:16:53.906332+00
album_0490	Overture 2	The Amplifiers	1970	Jazz	0.5833160098957508	North America	Canada	0.47191340169770835	https://picsum.photos/300/300?random=490	2026-01-18 14:16:53.906332+00
album_0491	Collection 18	The Vibrations	2016	Latin	0.6067329092301187	South America	Brazil	0.6815841807687448	https://picsum.photos/300/300?random=491	2026-01-18 14:16:53.906332+00
album_0492	Symphony 11	The Frequencies	1968	Rock	0.6695360148851054	Europe	Sweden	0.6173550023667285	https://picsum.photos/300/300?random=492	2026-01-18 14:16:53.906332+00
album_0493	Recordings 14	Beat Collective	2022	Hip Hop	0.7230623377600199	North America	USA	0.6390681206281088	https://picsum.photos/300/300?random=493	2026-01-18 14:16:53.906332+00
album_0494	Works 20	Major Sevenths	1965	Hip Hop	0.7748573165952403	North America	USA	0.6026401232741934	https://picsum.photos/300/300?random=494	2026-01-18 14:16:53.906332+00
album_0495	Suite 19	Harmonic Series	1990	Hip Hop	0.7567329725108846	North America	Canada	0.42318878810590427	https://picsum.photos/300/300?random=495	2026-01-18 14:16:53.906332+00
album_0496	Symphony 3	The Frequencies	2010	Classical	0.31270356089329276	Europe	France	0.7389217629141844	https://picsum.photos/300/300?random=496	2026-01-18 14:16:53.906332+00
album_0497	Session 2	Frequency Shift	1968	Rock	0.7266183595368387	Europe	Italy	0.644694127831865	https://picsum.photos/300/300?random=497	2026-01-18 14:16:53.906332+00
album_0498	Suite 6	Tempo Changes	2021	Classical	0.3314233412944779	Europe	Italy	0.8866480597617168	https://picsum.photos/300/300?random=498	2026-01-18 14:16:53.906332+00
album_0499	Symphony 3	Velvet Underground Revival	1987	Jazz	0.5855454316546544	North America	Canada	0.3721483368086005	https://picsum.photos/300/300?random=499	2026-01-18 14:16:53.906332+00
album_0500	Study No. 10	The Intervals	2018	J-Pop	0.6873167185307733	Asia	Japan	0.8970100120857718	https://picsum.photos/300/300?random=500	2026-01-18 14:16:53.906332+00
album_0501	Session 17	Major Sevenths	1963	Rock	0.7652955131685469	Europe	UK	0.8559750433711826	https://picsum.photos/300/300?random=501	2026-01-18 14:16:53.906332+00
album_0502	Session 2	The Dynamics	2014	Blues	0.4331121983021712	North America	Canada	0.34922476969580196	https://picsum.photos/300/300?random=502	2026-01-18 14:16:53.906332+00
album_0503	Chapter 7	Scale Runners	1973	Latin	0.5993259491415734	South America	Argentina	0.33235716406207666	https://picsum.photos/300/300?random=503	2026-01-18 14:16:53.906332+00
album_0504	Collection 11	Chord Progressions	1971	Rock	0.6111069493761243	Europe	Italy	0.5502933884215808	https://picsum.photos/300/300?random=504	2026-01-18 14:16:53.906332+00
album_0505	Chapter 9	Velvet Underground Revival	2001	Country	0.45161235531599275	North America	Mexico	0.7818780135802417	https://picsum.photos/300/300?random=505	2026-01-18 14:16:53.906332+00
album_0506	Volume 18	Neon Dreams	1960	Latin	0.699447667571645	South America	Colombia	0.4366675253312387	https://picsum.photos/300/300?random=506	2026-01-18 14:16:53.906332+00
album_0507	Recordings 9	Wavelength	1978	Indie Rock	0.6883091261669051	North America	Canada	0.6891659547252224	https://picsum.photos/300/300?random=507	2026-01-18 14:16:53.906332+00
album_0508	Study No. 6	The Harmonics	1981	Country	0.3984325943780297	North America	Mexico	0.6045815831388408	https://picsum.photos/300/300?random=508	2026-01-18 14:16:53.906332+00
album_0509	Collection 9	Tempo Changes	1968	K-Pop	0.7628199523449432	Asia	India	0.546513707542283	https://picsum.photos/300/300?random=509	2026-01-18 14:16:53.906332+00
album_0510	Collection 20	The Intervals	1961	Indie Rock	0.7663556778426579	Europe	Spain	0.6306322825096815	https://picsum.photos/300/300?random=510	2026-01-18 14:16:53.906332+00
album_0511	Volume 18	Frequency Shift	2005	Classical	0.2570782716085934	Europe	UK	0.5745634208619166	https://picsum.photos/300/300?random=511	2026-01-18 14:16:53.906332+00
album_0512	Works 5	Echo Chamber	1995	Electronic	0.8026103584127924	North America	Mexico	0.7056465681015271	https://picsum.photos/300/300?random=512	2026-01-18 14:16:53.906332+00
album_0513	Recordings 16	Reverb Nation	2008	Latin	0.7124905848552121	South America	Brazil	0.4230558631492407	https://picsum.photos/300/300?random=513	2026-01-18 14:16:53.906332+00
album_0514	Chapter 15	Digital Natives	1962	K-Pop	0.8239199974203403	Asia	South Korea	0.7403421646549377	https://picsum.photos/300/300?random=514	2026-01-18 14:16:53.906332+00
album_0515	Volume 20	Digital Natives	2012	Pop	0.5828300082921198	North America	Mexico	0.8410292830003621	https://picsum.photos/300/300?random=515	2026-01-18 14:16:53.906332+00
album_0516	Works 10	Groove Theory	1962	Rock	0.7994406269743534	North America	USA	0.7055023782111505	https://picsum.photos/300/300?random=516	2026-01-18 14:16:53.906332+00
album_0517	Volume 10	Tempo Changes	1967	K-Pop	0.7244151123350102	Asia	Japan	0.37814003624610804	https://picsum.photos/300/300?random=517	2026-01-18 14:16:53.906332+00
album_0518	The 1 Album	Major Sevenths	1992	Latin	0.5860356130436742	South America	Brazil	0.7996460463169485	https://picsum.photos/300/300?random=518	2026-01-18 14:16:53.906332+00
album_0519	Volume 19	Reverb Nation	2002	K-Pop	0.7213190844321536	Asia	India	0.31913186996373916	https://picsum.photos/300/300?random=519	2026-01-18 14:16:53.906332+00
album_0520	Opus 3	Analog Future	2003	Hip Hop	0.656995350587743	North America	Mexico	0.3747929843438697	https://picsum.photos/300/300?random=520	2026-01-18 14:16:53.906332+00
album_0521	Volume 11	Frequency Shift	2015	Blues	0.5974176672874535	North America	USA	0.3290751401758742	https://picsum.photos/300/300?random=521	2026-01-18 14:16:53.906332+00
album_0522	Volume 9	The Arpeggios	1999	Pop	0.6764342280093526	North America	USA	0.8502963076499792	https://picsum.photos/300/300?random=522	2026-01-18 14:16:53.906332+00
album_0523	Opus 20	Groove Theory	1989	J-Pop	0.700703113576124	Asia	India	0.6634687332569652	https://picsum.photos/300/300?random=523	2026-01-18 14:16:53.906332+00
album_0524	Session 11	Pitch Perfect	1977	Electronic	0.709252713258367	North America	Canada	0.429586907920986	https://picsum.photos/300/300?random=524	2026-01-18 14:16:53.906332+00
album_0525	Study No. 12	The Dynamics	2014	Classical	0.3740591709090555	Europe	Germany	0.408022008838533	https://picsum.photos/300/300?random=525	2026-01-18 14:16:53.906332+00
album_0526	Works 7	Scale Runners	1998	Hip Hop	0.7014095933213839	North America	Mexico	0.3018815042158415	https://picsum.photos/300/300?random=526	2026-01-18 14:16:53.906332+00
album_0527	Session 13	Crescendo	1978	K-Pop	0.6870414902894337	Asia	Japan	0.38256048474379434	https://picsum.photos/300/300?random=527	2026-01-18 14:16:53.906332+00
album_0528	Works 4	Velvet Underground Revival	1987	Metal	0.904486970305578	North America	Canada	0.6773126341887032	https://picsum.photos/300/300?random=528	2026-01-18 14:16:53.906332+00
album_0529	Collection 1	Neon Dreams	1969	Blues	0.4867477504278508	North America	Mexico	0.8266267187220115	https://picsum.photos/300/300?random=529	2026-01-18 14:16:53.906332+00
album_0530	Works 4	Velvet Underground Revival	2003	Latin	0.7339645030161749	South America	Brazil	0.49062218835883353	https://picsum.photos/300/300?random=530	2026-01-18 14:16:53.906332+00
album_0531	Opus 20	Beat Collective	1966	Country	0.42388532547135027	North America	USA	0.6845703965330696	https://picsum.photos/300/300?random=531	2026-01-18 14:16:53.906332+00
album_0532	Opus 20	Resonance	1971	Indie Rock	0.7261550934011993	North America	Mexico	0.7322322375310719	https://picsum.photos/300/300?random=532	2026-01-18 14:16:53.906332+00
album_0533	Study No. 4	Crescendo	1965	Country	0.3701317497077077	North America	Canada	0.45687090261922436	https://picsum.photos/300/300?random=533	2026-01-18 14:16:53.906332+00
album_0534	The 9 Album	Wavelength	2000	Blues	0.5994224263414603	North America	Mexico	0.722455998969014	https://picsum.photos/300/300?random=534	2026-01-18 14:16:53.906332+00
album_0535	The 7 Album	The Oscillators	1999	Latin	0.7417730812238528	South America	Brazil	0.868633304416152	https://picsum.photos/300/300?random=535	2026-01-18 14:16:53.906332+00
album_0536	Study No. 15	Velvet Underground Revival	1992	K-Pop	0.6829514041215639	Asia	India	0.8890616222437753	https://picsum.photos/300/300?random=536	2026-01-18 14:16:53.906332+00
album_0537	Works 9	Groove Theory	1969	K-Pop	0.7914965000368652	Asia	South Korea	0.7066876559589921	https://picsum.photos/300/300?random=537	2026-01-18 14:16:53.906332+00
album_0538	Symphony 13	Harmonic Series	1999	Reggae	0.6708901005211946	Caribbean	Jamaica	0.778042134453826	https://picsum.photos/300/300?random=538	2026-01-18 14:16:53.906332+00
album_0539	Opus 4	The Fundamentals	1983	Metal	0.8892056238774189	Europe	Spain	0.81342178211096	https://picsum.photos/300/300?random=539	2026-01-18 14:16:53.906332+00
album_0540	Suite 18	The Soundscapes	1990	Latin	0.7499046734683849	South America	Colombia	0.643392226278882	https://picsum.photos/300/300?random=540	2026-01-18 14:16:53.906332+00
album_0541	Suite 15	Tempo Changes	1963	J-Pop	0.6484450452469293	Asia	India	0.3097606187373994	https://picsum.photos/300/300?random=541	2026-01-18 14:16:53.906332+00
album_0542	Collection 10	Groove Theory	1988	Punk	0.8105967881738758	North America	Canada	0.621307051313329	https://picsum.photos/300/300?random=542	2026-01-18 14:16:53.906332+00
album_0543	Chapter 1	The Overtones	1979	J-Pop	0.7308632696963632	Asia	India	0.44810842840318343	https://picsum.photos/300/300?random=543	2026-01-18 14:16:53.906332+00
album_0544	The 19 Album	Timbre	1966	Pop	0.7431850331502355	Asia	South Korea	0.7103541608601482	https://picsum.photos/300/300?random=544	2026-01-18 14:16:53.906332+00
album_0545	Recordings 4	The Amplifiers	1970	Metal	0.8092790091843394	Europe	Spain	0.6591877812607814	https://picsum.photos/300/300?random=545	2026-01-18 14:16:53.906332+00
album_0546	Recordings 2	Minor Keys	1993	K-Pop	0.8221056237229185	Asia	South Korea	0.5033007412500774	https://picsum.photos/300/300?random=546	2026-01-18 14:16:53.906332+00
album_0547	The 11 Album	Neon Dreams	1983	Blues	0.5910225106833928	North America	Mexico	0.7233356786666304	https://picsum.photos/300/300?random=547	2026-01-18 14:16:53.906332+00
album_0548	Symphony 20	Frequency Shift	2023	K-Pop	0.8612306432363769	Asia	India	0.42096318469272875	https://picsum.photos/300/300?random=548	2026-01-18 14:16:53.906332+00
album_0549	Works 20	Digital Natives	2006	Latin	0.677663034930938	South America	Argentina	0.4939740243267751	https://picsum.photos/300/300?random=549	2026-01-18 14:16:53.906332+00
album_0550	Recordings 3	The Cadences	2017	Indie Rock	0.6600837406344527	North America	Mexico	0.5483435341362262	https://picsum.photos/300/300?random=550	2026-01-18 14:16:53.906332+00
album_0551	The 13 Album	Timbre	1968	Punk	0.8489529913025402	North America	Mexico	0.8965186569964154	https://picsum.photos/300/300?random=551	2026-01-18 14:16:53.906332+00
album_0552	Study No. 9	The Fundamentals	2006	Latin	0.6115454504951954	South America	Colombia	0.42898036065583856	https://picsum.photos/300/300?random=552	2026-01-18 14:16:53.906332+00
album_0553	Volume 13	The Melodies	2003	Blues	0.4906906399037339	North America	Canada	0.545783525639774	https://picsum.photos/300/300?random=553	2026-01-18 14:16:53.906332+00
album_0554	Works 5	Wavelength	1973	K-Pop	0.8385735892919273	Asia	India	0.8224887294185763	https://picsum.photos/300/300?random=554	2026-01-18 14:16:53.906332+00
album_0555	Symphony 9	Tempo Changes	1978	Electronic	0.841289867745628	Europe	Italy	0.8945427616887092	https://picsum.photos/300/300?random=555	2026-01-18 14:16:53.906332+00
album_0556	Study No. 20	Crescendo	1987	Electronic	0.7337537414268711	Europe	Sweden	0.7606462533449629	https://picsum.photos/300/300?random=556	2026-01-18 14:16:53.906332+00
album_0557	Opus 9	Scale Runners	1993	Country	0.5047315172612674	North America	Canada	0.7482076719208388	https://picsum.photos/300/300?random=557	2026-01-18 14:16:53.906332+00
album_0558	Symphony 19	Beat Collective	2018	Punk	0.7223805341783917	Europe	Sweden	0.6589804258507567	https://picsum.photos/300/300?random=558	2026-01-18 14:16:53.906332+00
album_0559	Chapter 15	Crystal Method	1964	Blues	0.5695452669646304	North America	Mexico	0.6139901914396488	https://picsum.photos/300/300?random=559	2026-01-18 14:16:53.906332+00
album_0560	The 7 Album	Sonic Youth Jr.	1997	Country	0.4528267254115434	North America	Canada	0.869174815273694	https://picsum.photos/300/300?random=560	2026-01-18 14:16:53.906332+00
album_0561	Opus 9	Reverb Nation	1983	Latin	0.6747267320043729	South America	Argentina	0.8821434561552235	https://picsum.photos/300/300?random=561	2026-01-18 14:16:53.906332+00
album_0562	Study No. 12	Neon Dreams	2005	Electronic	0.7216886795308203	Europe	UK	0.8278081565780842	https://picsum.photos/300/300?random=562	2026-01-18 14:16:53.906332+00
album_0563	Overture 17	Minor Keys	1961	Blues	0.5733106833699633	North America	Canada	0.30653024886611646	https://picsum.photos/300/300?random=563	2026-01-18 14:16:53.906332+00
album_0564	Volume 10	Resonance	1988	Metal	0.8682159448842749	Europe	Sweden	0.42183898538013986	https://picsum.photos/300/300?random=564	2026-01-18 14:16:53.906332+00
album_0565	Symphony 15	Timbre	1982	Hip Hop	0.7769450089570051	North America	Canada	0.7257454252771666	https://picsum.photos/300/300?random=565	2026-01-18 14:16:53.906332+00
album_0566	The 4 Album	Crescendo	1987	Electronic	0.8106845716018061	North America	Mexico	0.6911228148311128	https://picsum.photos/300/300?random=566	2026-01-18 14:16:53.906332+00
album_0567	Overture 7	The Rhythmics	2004	J-Pop	0.7589457147290851	Asia	India	0.42372749431978607	https://picsum.photos/300/300?random=567	2026-01-18 14:16:53.906332+00
album_0568	Symphony 6	The Harmonics	1976	Jazz	0.6139334469068656	North America	USA	0.7025228746784912	https://picsum.photos/300/300?random=568	2026-01-18 14:16:53.906332+00
album_0569	Session 3	Chord Progressions	1972	Reggae	0.5563338936524539	Caribbean	Jamaica	0.5838847984376141	https://picsum.photos/300/300?random=569	2026-01-18 14:16:53.906332+00
album_0570	Overture 9	Analog Future	2003	Punk	0.773695148555885	Europe	UK	0.7341233450474378	https://picsum.photos/300/300?random=570	2026-01-18 14:16:53.906332+00
album_0571	Overture 9	The Fundamentals	2004	Punk	0.7758392871579525	Europe	UK	0.36675005456425824	https://picsum.photos/300/300?random=571	2026-01-18 14:16:53.906332+00
album_0572	The 7 Album	Acoustic Waves	1975	Pop	0.7323518142758205	Asia	India	0.7032361915980658	https://picsum.photos/300/300?random=572	2026-01-18 14:16:53.906332+00
album_0573	Chapter 9	Chord Progressions	1989	Metal	0.7675689453960821	North America	Mexico	0.6026983756565656	https://picsum.photos/300/300?random=573	2026-01-18 14:16:53.906332+00
album_0574	Opus 8	Harmonic Series	1961	Electronic	0.8599303887286522	Europe	Italy	0.823992129099572	https://picsum.photos/300/300?random=574	2026-01-18 14:16:53.906332+00
album_0575	Opus 13	Beat Collective	1968	Classical	0.39050050997085206	Europe	Italy	0.44621162007407966	https://picsum.photos/300/300?random=575	2026-01-18 14:16:53.906332+00
album_0576	The 11 Album	The Oscillators	2012	Electronic	0.767512239910479	North America	Mexico	0.8531657575399876	https://picsum.photos/300/300?random=576	2026-01-18 14:16:53.906332+00
album_0577	Study No. 2	The Overtones	1970	Latin	0.7330635424539549	South America	Colombia	0.5647951723810354	https://picsum.photos/300/300?random=577	2026-01-18 14:16:53.906332+00
album_0578	Overture 4	The Overtones	1991	Country	0.3539305989273353	North America	Mexico	0.5086109280103062	https://picsum.photos/300/300?random=578	2026-01-18 14:16:53.906332+00
album_0579	Chapter 10	Sonic Boom	1988	Country	0.37055139513037805	North America	Canada	0.6854040564564713	https://picsum.photos/300/300?random=579	2026-01-18 14:16:53.906332+00
album_0580	Recordings 13	Sonic Boom	2017	Metal	0.9395545031632826	North America	Canada	0.5184744637700005	https://picsum.photos/300/300?random=580	2026-01-18 14:16:53.906332+00
album_0581	Suite 13	Timbre	2005	Classical	0.25877801588006777	Europe	Italy	0.407281109475365	https://picsum.photos/300/300?random=581	2026-01-18 14:16:53.906332+00
album_0582	Opus 5	Sonic Boom	2014	Hip Hop	0.7951011808840389	North America	USA	0.33168533500971376	https://picsum.photos/300/300?random=582	2026-01-18 14:16:53.906332+00
album_0583	Overture 14	Neon Dreams	1966	K-Pop	0.6997489251938603	Asia	South Korea	0.33624230833492863	https://picsum.photos/300/300?random=583	2026-01-18 14:16:53.906332+00
album_0584	Symphony 13	The Melodies	1997	Punk	0.8943709774799711	Europe	Italy	0.6165750987059682	https://picsum.photos/300/300?random=584	2026-01-18 14:16:53.906332+00
album_0585	Recordings 18	The Oscillators	2010	Blues	0.4652916968402325	North America	Mexico	0.46256946595923076	https://picsum.photos/300/300?random=585	2026-01-18 14:16:53.906332+00
album_0586	Symphony 9	Analog Future	1989	Jazz	0.6100514145841175	North America	USA	0.6649310750929173	https://picsum.photos/300/300?random=586	2026-01-18 14:16:53.906332+00
album_0587	Chapter 18	Decibel Rising	1994	Classical	0.2580961624874243	Europe	Italy	0.3516454863749049	https://picsum.photos/300/300?random=587	2026-01-18 14:16:53.906332+00
album_0588	Collection 19	The Soundscapes	2022	Jazz	0.6364407851271954	North America	USA	0.8844083731584822	https://picsum.photos/300/300?random=588	2026-01-18 14:16:53.906332+00
album_0589	Overture 16	Neon Dreams	1960	Classical	0.31273244287096624	Europe	France	0.8053153651312182	https://picsum.photos/300/300?random=589	2026-01-18 14:16:53.906332+00
album_0590	Symphony 20	Velvet Underground Revival	1974	Blues	0.4286614893540545	North America	USA	0.6075391346140573	https://picsum.photos/300/300?random=590	2026-01-18 14:16:53.906332+00
album_0591	Collection 13	Frequency Shift	1966	Rock	0.6862005394792708	North America	USA	0.5705298569377892	https://picsum.photos/300/300?random=591	2026-01-18 14:16:53.906332+00
album_0592	Suite 6	Major Sevenths	1966	J-Pop	0.7837301645718854	Asia	South Korea	0.5938372778647487	https://picsum.photos/300/300?random=592	2026-01-18 14:16:53.906332+00
album_0593	The 12 Album	Acoustic Waves	2022	Metal	0.8732194399842126	North America	USA	0.44779901059432137	https://picsum.photos/300/300?random=593	2026-01-18 14:16:53.906332+00
album_0594	Opus 1	Frequency Shift	1968	Metal	0.8147394462735454	Europe	UK	0.8146043980277564	https://picsum.photos/300/300?random=594	2026-01-18 14:16:53.906332+00
album_0595	The 17 Album	The Harmonics	1974	Classical	0.3313463493275872	Europe	Germany	0.7441097957711631	https://picsum.photos/300/300?random=595	2026-01-18 14:16:53.906332+00
album_0596	Session 13	The Vibrations	1969	Hip Hop	0.7113862378842163	North America	Canada	0.8538730667623664	https://picsum.photos/300/300?random=596	2026-01-18 14:16:53.906332+00
album_0597	The 1 Album	Crescendo	2006	Classical	0.21653192462934062	Europe	Sweden	0.34379234006346965	https://picsum.photos/300/300?random=597	2026-01-18 14:16:53.906332+00
album_0598	Collection 13	Pitch Perfect	2013	Hip Hop	0.7108540555120461	North America	Canada	0.51652620586918	https://picsum.photos/300/300?random=598	2026-01-18 14:16:53.906332+00
album_0599	Recordings 11	The Rhythmics	2000	Country	0.4194777304349031	North America	USA	0.7065728426170481	https://picsum.photos/300/300?random=599	2026-01-18 14:16:53.906332+00
album_0600	Chapter 15	The Cadences	2014	Electronic	0.7748555792469847	Europe	Spain	0.8992679069121818	https://picsum.photos/300/300?random=600	2026-01-18 14:16:53.906332+00
album_0601	Opus 16	Acoustic Waves	1960	K-Pop	0.7458503349225464	Asia	Japan	0.6373965471665307	https://picsum.photos/300/300?random=601	2026-01-18 14:16:53.906332+00
album_0602	Opus 6	The Oscillators	2011	Country	0.4689800582429935	North America	USA	0.4232521962436909	https://picsum.photos/300/300?random=602	2026-01-18 14:16:53.906332+00
album_0603	Recordings 3	Acoustic Waves	1981	Hip Hop	0.816812208689498	North America	Mexico	0.7177555282910881	https://picsum.photos/300/300?random=603	2026-01-18 14:16:53.906332+00
album_0604	Opus 6	The Fundamentals	2016	Reggae	0.645690492802389	Caribbean	Cuba	0.6358222573597158	https://picsum.photos/300/300?random=604	2026-01-18 14:16:53.906332+00
album_0605	Opus 5	Chord Progressions	2021	Blues	0.5411050916871327	North America	USA	0.863636881792311	https://picsum.photos/300/300?random=605	2026-01-18 14:16:53.906332+00
album_0606	Recordings 10	The Frequencies	1994	Classical	0.20917157342534876	Europe	Spain	0.6693542398020249	https://picsum.photos/300/300?random=606	2026-01-18 14:16:53.906332+00
album_0607	Recordings 20	Wavelength	1979	Country	0.46345154514417075	North America	USA	0.8806154059390257	https://picsum.photos/300/300?random=607	2026-01-18 14:16:53.906332+00
album_0608	Session 6	The Frequencies	2010	Punk	0.8582884073771606	North America	Mexico	0.7091094297785198	https://picsum.photos/300/300?random=608	2026-01-18 14:16:53.906332+00
album_0609	Opus 20	Minor Keys	2013	Rock	0.6575172333860543	North America	Mexico	0.7332085221671838	https://picsum.photos/300/300?random=609	2026-01-18 14:16:53.906332+00
album_0610	Overture 7	Frequency Shift	1993	K-Pop	0.8731271881737234	Asia	Japan	0.8199315583584694	https://picsum.photos/300/300?random=610	2026-01-18 14:16:53.906332+00
album_0611	Works 6	Timbre	2007	Rock	0.7701688379579478	North America	Canada	0.30386846019551383	https://picsum.photos/300/300?random=611	2026-01-18 14:16:53.906332+00
album_0612	Recordings 19	The Intervals	1968	Jazz	0.5883915423623031	North America	Mexico	0.75226061521245	https://picsum.photos/300/300?random=612	2026-01-18 14:16:53.906332+00
album_0613	Study No. 11	Analog Future	2024	Indie Rock	0.5966928334182667	Europe	France	0.6863574278081652	https://picsum.photos/300/300?random=613	2026-01-18 14:16:53.906332+00
album_0614	The 14 Album	Minor Keys	1969	Rock	0.6662725291531593	North America	USA	0.40213858085528276	https://picsum.photos/300/300?random=614	2026-01-18 14:16:53.906332+00
album_0615	Volume 9	The Frequencies	1982	Blues	0.4254972205527821	North America	USA	0.6425983752204618	https://picsum.photos/300/300?random=615	2026-01-18 14:16:53.906332+00
album_0616	Recordings 13	Harmonic Series	1985	Metal	0.9176624419797037	Europe	France	0.7333462789472649	https://picsum.photos/300/300?random=616	2026-01-18 14:16:53.906332+00
album_0617	Opus 11	The Soundscapes	1960	Indie Rock	0.7764895888707574	North America	USA	0.4482293176712988	https://picsum.photos/300/300?random=617	2026-01-18 14:16:53.906332+00
album_0618	Study No. 15	The Cadences	1996	Reggae	0.6189043533196947	Caribbean	Jamaica	0.6423230165739506	https://picsum.photos/300/300?random=618	2026-01-18 14:16:53.906332+00
album_0619	Opus 2	Decibel Rising	2021	Classical	0.39815299160980233	Europe	Germany	0.44102604607392515	https://picsum.photos/300/300?random=619	2026-01-18 14:16:53.906332+00
album_0620	Chapter 13	Tempo Changes	2013	Classical	0.2144766167919756	Europe	UK	0.30284773604206994	https://picsum.photos/300/300?random=620	2026-01-18 14:16:53.906332+00
album_0621	Works 11	Crystal Method	1983	Indie Rock	0.6978052137342343	Europe	Spain	0.5063505230638676	https://picsum.photos/300/300?random=621	2026-01-18 14:16:53.906332+00
album_0622	Opus 3	The Overtones	1985	Pop	0.5717440064835676	North America	USA	0.6886002428820835	https://picsum.photos/300/300?random=622	2026-01-18 14:16:53.906332+00
album_0623	Study No. 12	The Vibrations	2017	Electronic	0.7512593096718401	Europe	France	0.6486842128434045	https://picsum.photos/300/300?random=623	2026-01-18 14:16:53.906332+00
album_0624	Recordings 20	The Cadences	1983	Blues	0.5697186336963822	North America	Mexico	0.36471109339993224	https://picsum.photos/300/300?random=624	2026-01-18 14:16:53.906332+00
album_0625	Study No. 4	Crystal Method	1970	J-Pop	0.6923947659573119	Asia	China	0.6073459317966814	https://picsum.photos/300/300?random=625	2026-01-18 14:16:53.906332+00
album_0626	Symphony 18	The Harmonics	2011	Hip Hop	0.7211257405869025	North America	Mexico	0.4893538211936136	https://picsum.photos/300/300?random=626	2026-01-18 14:16:53.906332+00
album_0627	Volume 15	Minor Keys	1960	Metal	0.9144510034763498	North America	Canada	0.47210090402151583	https://picsum.photos/300/300?random=627	2026-01-18 14:16:53.906332+00
album_0628	Study No. 14	Tempo Changes	1982	Jazz	0.5825605845803539	North America	USA	0.7895943666586289	https://picsum.photos/300/300?random=628	2026-01-18 14:16:53.906332+00
album_0629	Recordings 12	The Arpeggios	1975	Punk	0.8026350649054939	Europe	Sweden	0.7096547962556156	https://picsum.photos/300/300?random=629	2026-01-18 14:16:53.906332+00
album_0630	Opus 4	Tempo Changes	1966	Punk	0.7818139369458094	North America	USA	0.6704292710944392	https://picsum.photos/300/300?random=630	2026-01-18 14:16:53.906332+00
album_0631	Chapter 16	The Frequencies	2016	Blues	0.45220329565694406	North America	Mexico	0.8395707608169296	https://picsum.photos/300/300?random=631	2026-01-18 14:16:53.906332+00
album_0632	Works 12	Scale Runners	2020	Classical	0.39395197463739007	Europe	France	0.5822794981364912	https://picsum.photos/300/300?random=632	2026-01-18 14:16:53.906332+00
album_0633	Study No. 20	The Harmonics	1968	Country	0.5192069148629974	North America	Canada	0.5391211781108554	https://picsum.photos/300/300?random=633	2026-01-18 14:16:53.906332+00
album_0634	Study No. 17	The Syncopators	1973	Hip Hop	0.6717678697489371	North America	USA	0.3677363318547909	https://picsum.photos/300/300?random=634	2026-01-18 14:16:53.906332+00
album_0635	Chapter 7	Reverb Nation	1996	K-Pop	0.7773279178219041	Asia	India	0.7526243927615683	https://picsum.photos/300/300?random=635	2026-01-18 14:16:53.906332+00
album_0636	Suite 8	Minor Keys	1979	Reggae	0.6503045441262703	Caribbean	Trinidad	0.8863208868095913	https://picsum.photos/300/300?random=636	2026-01-18 14:16:53.906332+00
album_0637	Recordings 4	Frequency Shift	1991	K-Pop	0.8265730855077733	Asia	China	0.6854634350698418	https://picsum.photos/300/300?random=637	2026-01-18 14:16:53.906332+00
album_0638	The 4 Album	Chord Progressions	1966	Jazz	0.6422611791519193	North America	Canada	0.7355726772225755	https://picsum.photos/300/300?random=638	2026-01-18 14:16:53.906332+00
album_0639	The 12 Album	The Overtones	1990	Classical	0.3053792828813213	Europe	Spain	0.31538665562156737	https://picsum.photos/300/300?random=639	2026-01-18 14:16:53.906332+00
album_0640	Session 17	The Arpeggios	1978	K-Pop	0.8647250835166083	Asia	China	0.4008503803135802	https://picsum.photos/300/300?random=640	2026-01-18 14:16:53.906332+00
album_0641	Collection 3	The Rhythmics	2016	K-Pop	0.7540675611809141	Asia	South Korea	0.5637490472128615	https://picsum.photos/300/300?random=641	2026-01-18 14:16:53.906332+00
album_0642	Symphony 20	Wavelength	1960	Electronic	0.7347576062086618	North America	USA	0.8669865059796478	https://picsum.photos/300/300?random=642	2026-01-18 14:16:53.906332+00
album_0643	Recordings 18	Timbre	2016	K-Pop	0.738426049686599	Asia	India	0.36826146535522264	https://picsum.photos/300/300?random=643	2026-01-18 14:16:53.906332+00
album_0644	The 19 Album	The Syncopators	1993	Indie Rock	0.5965844914540578	Europe	Germany	0.6953645455698041	https://picsum.photos/300/300?random=644	2026-01-18 14:16:53.906332+00
album_0645	The 19 Album	The Oscillators	2010	Metal	0.9170764119835714	Europe	Germany	0.6771803825909879	https://picsum.photos/300/300?random=645	2026-01-18 14:16:53.906332+00
album_0646	Study No. 15	Tempo Changes	1968	Electronic	0.7560663347424426	Europe	Spain	0.7027216940096278	https://picsum.photos/300/300?random=646	2026-01-18 14:16:53.906332+00
album_0647	Suite 16	Frequency Shift	1961	Classical	0.36672242386148923	Europe	Sweden	0.8893988979940328	https://picsum.photos/300/300?random=647	2026-01-18 14:16:53.906332+00
album_0648	Overture 10	Sonic Boom	2015	Hip Hop	0.6673400058004008	North America	Canada	0.5553279279619762	https://picsum.photos/300/300?random=648	2026-01-18 14:16:53.906332+00
album_0649	Session 1	Resonance	1986	Pop	0.5620177788036609	North America	USA	0.5315780415082347	https://picsum.photos/300/300?random=649	2026-01-18 14:16:53.906332+00
album_0650	Works 15	Digital Natives	1982	K-Pop	0.8755374370892701	Asia	China	0.761064105230616	https://picsum.photos/300/300?random=650	2026-01-18 14:16:53.906332+00
album_0651	The 15 Album	The Vibrations	1991	Pop	0.6152886425872928	Asia	India	0.34630017307633076	https://picsum.photos/300/300?random=651	2026-01-18 14:16:53.906332+00
album_0652	Suite 17	The Frequencies	1987	Pop	0.7316210098543181	Europe	Spain	0.6664861558610802	https://picsum.photos/300/300?random=652	2026-01-18 14:16:53.906332+00
album_0653	Collection 5	Scale Runners	1994	Hip Hop	0.7775420723510538	North America	Canada	0.5414947573053068	https://picsum.photos/300/300?random=653	2026-01-18 14:16:53.906332+00
album_0654	Opus 3	Beat Collective	1967	Metal	0.7914954706969175	Europe	Italy	0.6001055496408909	https://picsum.photos/300/300?random=654	2026-01-18 14:16:53.906332+00
album_0655	Opus 12	Tempo Changes	1962	Classical	0.20579338369319689	Europe	Sweden	0.8375214889669869	https://picsum.photos/300/300?random=655	2026-01-18 14:16:53.906332+00
album_0656	Chapter 18	Chord Progressions	2020	Pop	0.6929868288545435	Europe	Germany	0.37163429739518666	https://picsum.photos/300/300?random=656	2026-01-18 14:16:53.906332+00
album_0657	Suite 13	The Frequencies	1976	Metal	0.7662251068710122	Europe	France	0.5020025440719204	https://picsum.photos/300/300?random=657	2026-01-18 14:16:53.906332+00
album_0658	Symphony 1	Crescendo	2007	Hip Hop	0.8496637843768999	North America	Canada	0.7114302338543046	https://picsum.photos/300/300?random=658	2026-01-18 14:16:53.906332+00
album_0659	Opus 2	The Soundscapes	1968	Metal	0.8725818826610524	North America	Mexico	0.5052360295492633	https://picsum.photos/300/300?random=659	2026-01-18 14:16:53.906332+00
album_0660	Overture 17	The Amplifiers	1990	Pop	0.6714709944376958	Asia	India	0.6283579727120555	https://picsum.photos/300/300?random=660	2026-01-18 14:16:53.906332+00
album_0661	Suite 5	Velvet Underground Revival	2016	Electronic	0.7671688119312909	Europe	France	0.8156701076465045	https://picsum.photos/300/300?random=661	2026-01-18 14:16:53.906332+00
album_0662	Opus 4	Acoustic Waves	1981	Latin	0.7293215523809378	South America	Brazil	0.7975144635399907	https://picsum.photos/300/300?random=662	2026-01-18 14:16:53.906332+00
album_0663	Opus 2	Decibel Rising	1985	Punk	0.8263758604266069	North America	USA	0.3529129211187338	https://picsum.photos/300/300?random=663	2026-01-18 14:16:53.906332+00
album_0664	Study No. 19	The Overtones	1961	Country	0.438690493061594	North America	USA	0.6781546802778387	https://picsum.photos/300/300?random=664	2026-01-18 14:16:53.906332+00
album_0665	Symphony 2	The Soundscapes	2001	Metal	0.8283769678991358	Europe	Italy	0.44589386915007656	https://picsum.photos/300/300?random=665	2026-01-18 14:16:53.906332+00
album_0666	Symphony 2	Major Sevenths	2018	Blues	0.5366804767416317	North America	Mexico	0.3678596185034824	https://picsum.photos/300/300?random=666	2026-01-18 14:16:53.906332+00
album_0667	Chapter 18	The Overtones	1977	Hip Hop	0.7157735781218512	North America	Canada	0.4355645054529064	https://picsum.photos/300/300?random=667	2026-01-18 14:16:53.906332+00
album_0668	Suite 4	Decibel Rising	2015	Rock	0.7004729735993188	Europe	Germany	0.7726586066214115	https://picsum.photos/300/300?random=668	2026-01-18 14:16:53.906332+00
album_0669	The 12 Album	Resonance	2015	Latin	0.7210015267132227	South America	Brazil	0.7129805238203425	https://picsum.photos/300/300?random=669	2026-01-18 14:16:53.906332+00
album_0670	Collection 10	Velvet Underground Revival	1965	Electronic	0.8052445298610319	North America	Mexico	0.5461712739006086	https://picsum.photos/300/300?random=670	2026-01-18 14:16:53.906332+00
album_0671	Collection 18	The Rhythmics	1992	Rock	0.6200112103180035	North America	USA	0.6461010689329373	https://picsum.photos/300/300?random=671	2026-01-18 14:16:53.906332+00
album_0672	Chapter 10	The Arpeggios	2009	Punk	0.7653059877401985	Europe	Germany	0.8967036546365803	https://picsum.photos/300/300?random=672	2026-01-18 14:16:53.906332+00
album_0673	Session 10	Sonic Youth Jr.	1986	Electronic	0.7312531910473465	Europe	UK	0.30926397658231314	https://picsum.photos/300/300?random=673	2026-01-18 14:16:53.906332+00
album_0674	Collection 14	Chord Progressions	1988	Blues	0.4916152159929646	North America	Canada	0.7128866879972604	https://picsum.photos/300/300?random=674	2026-01-18 14:16:53.906332+00
album_0675	Works 10	Digital Natives	2012	Latin	0.7127282716354573	South America	Colombia	0.7069412488569252	https://picsum.photos/300/300?random=675	2026-01-18 14:16:53.906332+00
album_0676	Suite 17	Groove Theory	2018	J-Pop	0.8098662607472694	Asia	India	0.8863250978010921	https://picsum.photos/300/300?random=676	2026-01-18 14:16:53.906332+00
album_0677	Suite 4	Sonic Boom	1992	Punk	0.8182223228112926	Europe	Spain	0.7186662087369968	https://picsum.photos/300/300?random=677	2026-01-18 14:16:53.906332+00
album_0678	Collection 4	The Melodies	2024	Rock	0.6762728529811518	Europe	UK	0.40229380928348313	https://picsum.photos/300/300?random=678	2026-01-18 14:16:53.906332+00
album_0679	Volume 19	Groove Theory	1992	Reggae	0.7140355883292369	Caribbean	Trinidad	0.8819603950426831	https://picsum.photos/300/300?random=679	2026-01-18 14:16:53.906332+00
album_0680	Recordings 13	The Frequencies	2006	Pop	0.5666455653362036	Asia	China	0.6941291092081192	https://picsum.photos/300/300?random=680	2026-01-18 14:16:53.906332+00
album_0681	Symphony 12	The Harmonics	1996	Jazz	0.5053268254737838	North America	Mexico	0.7862114506117561	https://picsum.photos/300/300?random=681	2026-01-18 14:16:53.906332+00
album_0682	Opus 4	Analog Future	1975	Jazz	0.5831702932612346	North America	Mexico	0.40951619953818474	https://picsum.photos/300/300?random=682	2026-01-18 14:16:53.906332+00
album_0683	Recordings 11	Wavelength	1983	Indie Rock	0.6963042477564755	Europe	France	0.41946962428413476	https://picsum.photos/300/300?random=683	2026-01-18 14:16:53.906332+00
album_0684	Symphony 14	The Rhythmics	2010	Classical	0.2935982378226113	Europe	Italy	0.4098920542848029	https://picsum.photos/300/300?random=684	2026-01-18 14:16:53.906332+00
album_0685	Study No. 6	Digital Natives	1983	Classical	0.26265850575628735	Europe	France	0.8713945076026066	https://picsum.photos/300/300?random=685	2026-01-18 14:16:53.906332+00
album_0686	Volume 5	The Cadences	1994	Pop	0.7320405939986687	Asia	Japan	0.3236508975442071	https://picsum.photos/300/300?random=686	2026-01-18 14:16:53.906332+00
album_0687	Volume 15	Timbre	2004	J-Pop	0.7735141740839402	Asia	China	0.735229217999837	https://picsum.photos/300/300?random=687	2026-01-18 14:16:53.906332+00
album_0688	Collection 1	Pitch Perfect	2005	Metal	0.8397266173838035	North America	Mexico	0.8173749747048202	https://picsum.photos/300/300?random=688	2026-01-18 14:16:53.906332+00
album_0689	Symphony 5	Wavelength	1998	Jazz	0.5988580050441585	North America	USA	0.5565866168284735	https://picsum.photos/300/300?random=689	2026-01-18 14:16:53.906332+00
album_0690	Session 9	The Intervals	2017	Jazz	0.5615508028796072	North America	USA	0.8657944949310297	https://picsum.photos/300/300?random=690	2026-01-18 14:16:53.906332+00
album_0691	Study No. 9	Digital Natives	2015	Metal	0.7815709614116766	Europe	Sweden	0.4380012509190024	https://picsum.photos/300/300?random=691	2026-01-18 14:16:53.906332+00
album_0692	Symphony 5	Harmonic Series	2020	Rock	0.7570808800579727	Europe	UK	0.7797363163022565	https://picsum.photos/300/300?random=692	2026-01-18 14:16:53.906332+00
album_0693	Overture 7	Timbre	2000	Classical	0.29221999267219534	Europe	Germany	0.3494743350533387	https://picsum.photos/300/300?random=693	2026-01-18 14:16:53.906332+00
album_0694	Overture 3	Harmonic Series	2008	Latin	0.6613867616963328	South America	Colombia	0.4115339387473943	https://picsum.photos/300/300?random=694	2026-01-18 14:16:53.906332+00
album_0695	Suite 3	The Cadences	1982	Pop	0.5971715945202221	North America	USA	0.6470027354220016	https://picsum.photos/300/300?random=695	2026-01-18 14:16:53.906332+00
album_0696	Collection 4	Velvet Underground Revival	1993	Latin	0.7780860878149335	South America	Argentina	0.6612442769816289	https://picsum.photos/300/300?random=696	2026-01-18 14:16:53.906332+00
album_0697	Symphony 10	Tempo Changes	1994	Indie Rock	0.7606049045375678	Europe	Germany	0.5216159630238342	https://picsum.photos/300/300?random=697	2026-01-18 14:16:53.906332+00
album_0698	Chapter 10	The Syncopators	1978	Electronic	0.843796391143099	North America	Canada	0.4643137662091382	https://picsum.photos/300/300?random=698	2026-01-18 14:16:53.906332+00
album_0699	Collection 11	The Vibrations	1966	Electronic	0.8773831038093165	North America	Canada	0.699829683006888	https://picsum.photos/300/300?random=699	2026-01-18 14:16:53.906332+00
album_0700	Suite 18	The Amplifiers	1961	Country	0.49146750525769445	North America	Mexico	0.43494904898376807	https://picsum.photos/300/300?random=700	2026-01-18 14:16:53.906332+00
album_0701	Study No. 16	Sonic Youth Jr.	1984	Reggae	0.6195313408014438	Caribbean	Jamaica	0.8948389188737413	https://picsum.photos/300/300?random=701	2026-01-18 14:16:53.906332+00
album_0702	Session 5	Harmonic Series	2022	Latin	0.6794519541686457	South America	Colombia	0.41748404328968813	https://picsum.photos/300/300?random=702	2026-01-18 14:16:53.906332+00
album_0703	Recordings 5	The Rhythmics	2024	Rock	0.7255455024874438	Europe	Sweden	0.40587372812559486	https://picsum.photos/300/300?random=703	2026-01-18 14:16:53.906332+00
album_0704	Chapter 6	The Overtones	1976	Metal	0.7557739394464925	Europe	UK	0.3643513035318326	https://picsum.photos/300/300?random=704	2026-01-18 14:16:53.906332+00
album_0705	Study No. 8	Sonic Boom	1996	Punk	0.7116154037377416	Europe	Italy	0.3720880982052267	https://picsum.photos/300/300?random=705	2026-01-18 14:16:53.906332+00
album_0706	Symphony 16	The Oscillators	2004	Metal	0.7842211990008041	North America	Mexico	0.5738437419585392	https://picsum.photos/300/300?random=706	2026-01-18 14:16:53.906332+00
album_0707	Symphony 17	Reverb Nation	2007	Classical	0.23315189350109913	Europe	Spain	0.30972901687456467	https://picsum.photos/300/300?random=707	2026-01-18 14:16:53.906332+00
album_0708	Opus 7	The Harmonics	2018	Blues	0.5335484947456747	North America	USA	0.3797150000231137	https://picsum.photos/300/300?random=708	2026-01-18 14:16:53.906332+00
album_0709	The 16 Album	Acoustic Waves	2005	Blues	0.5009754634841672	North America	Mexico	0.6217890328266888	https://picsum.photos/300/300?random=709	2026-01-18 14:16:53.906332+00
album_0710	Chapter 2	Major Sevenths	1967	Hip Hop	0.7223546285201333	North America	Canada	0.7254289704870263	https://picsum.photos/300/300?random=710	2026-01-18 14:16:53.906332+00
album_0711	Suite 14	Pitch Perfect	1961	Jazz	0.6400413374488286	North America	USA	0.7170624681769499	https://picsum.photos/300/300?random=711	2026-01-18 14:16:53.906332+00
album_0712	Study No. 20	The Frequencies	1988	Latin	0.7483565313349038	South America	Argentina	0.3324161398219714	https://picsum.photos/300/300?random=712	2026-01-18 14:16:53.906332+00
album_0713	Recordings 18	The Vibrations	1968	Indie Rock	0.7623956402431318	Europe	UK	0.6004098566861671	https://picsum.photos/300/300?random=713	2026-01-18 14:16:53.906332+00
album_0714	Recordings 12	Groove Theory	2013	Rock	0.7766998825824767	North America	USA	0.7260642031754132	https://picsum.photos/300/300?random=714	2026-01-18 14:16:53.906332+00
album_0715	Opus 18	Crescendo	1986	K-Pop	0.7000167986598209	Asia	China	0.39739870633095803	https://picsum.photos/300/300?random=715	2026-01-18 14:16:53.906332+00
album_0716	Recordings 12	The Intervals	1981	K-Pop	0.8574807859290297	Asia	South Korea	0.4051661627045595	https://picsum.photos/300/300?random=716	2026-01-18 14:16:53.906332+00
album_0717	Overture 5	The Intervals	2009	Electronic	0.7026271176424752	North America	USA	0.5255557421143638	https://picsum.photos/300/300?random=717	2026-01-18 14:16:53.906332+00
album_0718	Study No. 7	Crescendo	2001	K-Pop	0.8155798942381194	Asia	India	0.6874550517678444	https://picsum.photos/300/300?random=718	2026-01-18 14:16:53.906332+00
album_0719	Suite 9	Reverb Nation	1966	Latin	0.6200667052553982	South America	Brazil	0.3203165407533643	https://picsum.photos/300/300?random=719	2026-01-18 14:16:53.906332+00
album_0720	Recordings 9	The Frequencies	1975	Punk	0.8653417404729449	North America	Mexico	0.32286287944704256	https://picsum.photos/300/300?random=720	2026-01-18 14:16:53.906332+00
album_0721	Session 16	Velvet Underground Revival	2024	Blues	0.546448355205715	North America	Mexico	0.8060848278617476	https://picsum.photos/300/300?random=721	2026-01-18 14:16:53.906332+00
album_0722	Opus 9	Pitch Perfect	2002	Reggae	0.5414364146498714	Caribbean	Jamaica	0.6189211869657383	https://picsum.photos/300/300?random=722	2026-01-18 14:16:53.906332+00
album_0723	Symphony 11	The Fundamentals	1963	Rock	0.7937173508814503	North America	Mexico	0.8139745935747822	https://picsum.photos/300/300?random=723	2026-01-18 14:16:53.906332+00
album_0724	Recordings 3	The Soundscapes	2003	K-Pop	0.7043442105770221	Asia	India	0.5874867048798336	https://picsum.photos/300/300?random=724	2026-01-18 14:16:53.906332+00
album_0725	Suite 4	The Cadences	1983	Metal	0.9307926314460555	North America	Mexico	0.3735481989952949	https://picsum.photos/300/300?random=725	2026-01-18 14:16:53.906332+00
album_0726	Suite 18	Minor Keys	1994	Country	0.36035721308853536	North America	USA	0.5670462472190658	https://picsum.photos/300/300?random=726	2026-01-18 14:16:53.906332+00
album_0727	The 8 Album	The Arpeggios	2002	Pop	0.7030954323797505	Europe	Spain	0.5071754480751653	https://picsum.photos/300/300?random=727	2026-01-18 14:16:53.906332+00
album_0728	Session 7	The Amplifiers	1967	Reggae	0.6096506815360472	Caribbean	Cuba	0.574184602682311	https://picsum.photos/300/300?random=728	2026-01-18 14:16:53.906332+00
album_0729	The 8 Album	The Fundamentals	2008	Punk	0.7643251891855738	Europe	Italy	0.69834534478567	https://picsum.photos/300/300?random=729	2026-01-18 14:16:53.906332+00
album_0730	The 3 Album	The Syncopators	1985	Country	0.5490195978662681	North America	USA	0.3204175028605833	https://picsum.photos/300/300?random=730	2026-01-18 14:16:53.906332+00
album_0731	Collection 4	Resonance	2006	Rock	0.7957347162114752	Europe	Spain	0.6485638681120599	https://picsum.photos/300/300?random=731	2026-01-18 14:16:53.906332+00
album_0732	Overture 19	Analog Future	2010	Punk	0.7775090276516866	Europe	UK	0.8048986427818459	https://picsum.photos/300/300?random=732	2026-01-18 14:16:53.906332+00
album_0733	Symphony 13	Decibel Rising	1964	Metal	0.8278418811121161	North America	Mexico	0.6255407363219156	https://picsum.photos/300/300?random=733	2026-01-18 14:16:53.906332+00
album_0734	Opus 20	Neon Dreams	1981	Country	0.45706910467408846	North America	USA	0.5583598552323689	https://picsum.photos/300/300?random=734	2026-01-18 14:16:53.906332+00
album_0735	Symphony 16	The Arpeggios	1981	Pop	0.7480879066395588	Europe	Sweden	0.6709598441344085	https://picsum.photos/300/300?random=735	2026-01-18 14:16:53.906332+00
album_0736	Chapter 7	Crystal Method	2003	K-Pop	0.6867600540989399	Asia	South Korea	0.3972681739829785	https://picsum.photos/300/300?random=736	2026-01-18 14:16:53.906332+00
album_0737	Study No. 1	Resonance	1986	Latin	0.6161674831951223	South America	Colombia	0.32450117898104713	https://picsum.photos/300/300?random=737	2026-01-18 14:16:53.906332+00
album_0738	Opus 17	The Cadences	2000	Indie Rock	0.6697594203657071	North America	USA	0.5713221442841669	https://picsum.photos/300/300?random=738	2026-01-18 14:16:53.906332+00
album_0739	Session 11	The Dynamics	1998	Electronic	0.8748763850659634	North America	Mexico	0.8201088167660266	https://picsum.photos/300/300?random=739	2026-01-18 14:16:53.906332+00
album_0740	Chapter 18	The Melodies	2022	Pop	0.6331918281911021	Europe	UK	0.6637435510318735	https://picsum.photos/300/300?random=740	2026-01-18 14:16:53.906332+00
album_0741	Collection 9	Echo Chamber	1968	Blues	0.5889833883729513	North America	Mexico	0.37182833724032993	https://picsum.photos/300/300?random=741	2026-01-18 14:16:53.906332+00
album_0742	Session 2	The Dynamics	2014	Blues	0.5888727221250696	North America	Canada	0.4282090801936161	https://picsum.photos/300/300?random=742	2026-01-18 14:16:53.906332+00
album_0743	Study No. 12	Crescendo	1990	Metal	0.8647315577513826	Europe	Spain	0.810289799785533	https://picsum.photos/300/300?random=743	2026-01-18 14:16:53.906332+00
album_0744	Study No. 6	The Intervals	2010	Punk	0.7768024448285586	North America	Canada	0.37192861621819634	https://picsum.photos/300/300?random=744	2026-01-18 14:16:53.906332+00
album_0745	Works 3	The Melodies	1968	K-Pop	0.7080158541616467	Asia	Japan	0.855219063202951	https://picsum.photos/300/300?random=745	2026-01-18 14:16:53.906332+00
album_0746	The 12 Album	The Cadences	1978	Classical	0.33536647744034265	Europe	UK	0.5027050580211794	https://picsum.photos/300/300?random=746	2026-01-18 14:16:53.906332+00
album_0747	Opus 14	The Dynamics	1965	Reggae	0.6581844991292221	Caribbean	Jamaica	0.631657487859403	https://picsum.photos/300/300?random=747	2026-01-18 14:16:53.906332+00
album_0748	Recordings 18	Tempo Changes	1988	Jazz	0.4826653060284916	North America	Mexico	0.38439574382449654	https://picsum.photos/300/300?random=748	2026-01-18 14:16:53.906332+00
album_0749	Study No. 16	Minor Keys	1987	Classical	0.21760410487558512	Europe	Spain	0.8474159542862132	https://picsum.photos/300/300?random=749	2026-01-18 14:16:53.906332+00
album_0750	Volume 10	Analog Future	1967	Reggae	0.5947951960382477	Caribbean	Trinidad	0.8328383581560315	https://picsum.photos/300/300?random=750	2026-01-18 14:16:53.906332+00
album_0751	Study No. 3	Major Sevenths	1984	Rock	0.6121803052421079	Europe	France	0.34072632056759566	https://picsum.photos/300/300?random=751	2026-01-18 14:16:53.906332+00
album_0752	Opus 8	Timbre	2015	J-Pop	0.7390813226738078	Asia	Japan	0.790091819704767	https://picsum.photos/300/300?random=752	2026-01-18 14:16:53.906332+00
album_0753	Symphony 18	The Soundscapes	1996	Country	0.4131144065275056	North America	Canada	0.33451882055548016	https://picsum.photos/300/300?random=753	2026-01-18 14:16:53.906332+00
album_0754	Overture 20	Velvet Underground Revival	2007	Rock	0.7588431524491895	North America	USA	0.7706327560572277	https://picsum.photos/300/300?random=754	2026-01-18 14:16:53.906332+00
album_0755	Symphony 13	The Frequencies	1995	Hip Hop	0.7038367238648137	North America	USA	0.44507816000997436	https://picsum.photos/300/300?random=755	2026-01-18 14:16:53.906332+00
album_0756	Suite 18	Velvet Underground Revival	1972	J-Pop	0.6321188917334114	Asia	Japan	0.4926920824323811	https://picsum.photos/300/300?random=756	2026-01-18 14:16:53.906332+00
album_0757	Volume 4	Harmonic Series	1991	Rock	0.7512479186873513	North America	Mexico	0.69155561425739	https://picsum.photos/300/300?random=757	2026-01-18 14:16:53.906332+00
album_0758	Collection 15	Sonic Boom	1968	Reggae	0.6338704650956606	Caribbean	Jamaica	0.4760304788207089	https://picsum.photos/300/300?random=758	2026-01-18 14:16:53.906332+00
album_0759	Suite 11	Minor Keys	2019	Country	0.46184550077126046	North America	USA	0.5891472457203804	https://picsum.photos/300/300?random=759	2026-01-18 14:16:53.906332+00
album_0760	Opus 15	Neon Dreams	2011	Pop	0.5806462333826833	Asia	South Korea	0.8153648239312472	https://picsum.photos/300/300?random=760	2026-01-18 14:16:53.906332+00
album_0761	The 19 Album	Scale Runners	2022	Blues	0.587569427726996	North America	USA	0.3668716929964404	https://picsum.photos/300/300?random=761	2026-01-18 14:16:53.906332+00
album_0762	Overture 17	Digital Natives	2021	Pop	0.7190217483831658	Europe	Germany	0.5324737176380111	https://picsum.photos/300/300?random=762	2026-01-18 14:16:53.906332+00
album_0763	Suite 20	Beat Collective	1985	Country	0.41632779132515807	North America	USA	0.6069869058684076	https://picsum.photos/300/300?random=763	2026-01-18 14:16:53.906332+00
album_0764	Symphony 10	Acoustic Waves	1984	Blues	0.5239020718243224	North America	USA	0.7050699240557015	https://picsum.photos/300/300?random=764	2026-01-18 14:16:53.906332+00
album_0765	Overture 16	The Arpeggios	2003	Electronic	0.7286561595274531	Europe	Sweden	0.7572623035745604	https://picsum.photos/300/300?random=765	2026-01-18 14:16:53.906332+00
album_0766	Symphony 16	Scale Runners	1979	Pop	0.6826638250157321	Asia	India	0.558417659739034	https://picsum.photos/300/300?random=766	2026-01-18 14:16:53.906332+00
album_0767	Study No. 5	Sonic Boom	1969	Punk	0.803660082353137	North America	USA	0.37196155754801924	https://picsum.photos/300/300?random=767	2026-01-18 14:16:53.906332+00
album_0768	Works 9	The Rhythmics	1974	Classical	0.33919205655036944	Europe	Italy	0.8941708271776967	https://picsum.photos/300/300?random=768	2026-01-18 14:16:53.906332+00
album_0769	Volume 18	Timbre	1968	Indie Rock	0.7236214889194088	Europe	Germany	0.8278339377697512	https://picsum.photos/300/300?random=769	2026-01-18 14:16:53.906332+00
album_0770	Session 7	Analog Future	2011	Rock	0.7110402422837914	Europe	France	0.4873096398028059	https://picsum.photos/300/300?random=770	2026-01-18 14:16:53.906332+00
album_0771	The 14 Album	The Dynamics	1966	J-Pop	0.7941512079075627	Asia	India	0.5672546776370944	https://picsum.photos/300/300?random=771	2026-01-18 14:16:53.906332+00
album_0772	Recordings 10	Major Sevenths	2021	Pop	0.7494754310307846	Europe	Germany	0.5088407348717638	https://picsum.photos/300/300?random=772	2026-01-18 14:16:53.906332+00
album_0773	Collection 6	Minor Keys	1977	Latin	0.7556997125572344	South America	Colombia	0.7951246428450807	https://picsum.photos/300/300?random=773	2026-01-18 14:16:53.906332+00
album_0774	Collection 13	Beat Collective	1961	Latin	0.6943884107656115	South America	Brazil	0.46466814065919715	https://picsum.photos/300/300?random=774	2026-01-18 14:16:53.906332+00
album_0775	Opus 8	The Cadences	1962	J-Pop	0.6352223606808578	Asia	South Korea	0.49178716970723535	https://picsum.photos/300/300?random=775	2026-01-18 14:16:53.906332+00
album_0776	The 6 Album	Wavelength	1989	Latin	0.6705909264337875	South America	Colombia	0.7214756420127337	https://picsum.photos/300/300?random=776	2026-01-18 14:16:53.906332+00
album_0777	Recordings 11	The Soundscapes	1981	Metal	0.7549954691882134	Europe	Spain	0.503165877416386	https://picsum.photos/300/300?random=777	2026-01-18 14:16:53.906332+00
album_0778	Opus 10	The Syncopators	1978	Jazz	0.611184023621963	North America	Mexico	0.5276538833353887	https://picsum.photos/300/300?random=778	2026-01-18 14:16:53.906332+00
album_0779	Overture 6	Digital Natives	2001	Reggae	0.6015405244405172	Caribbean	Trinidad	0.5854980199281377	https://picsum.photos/300/300?random=779	2026-01-18 14:16:53.906332+00
album_0780	Volume 14	Wavelength	2012	Rock	0.7008768364374087	Europe	France	0.867466449347142	https://picsum.photos/300/300?random=780	2026-01-18 14:16:53.906332+00
album_0781	Collection 10	The Vibrations	2007	J-Pop	0.7337380649441365	Asia	India	0.42202459109349677	https://picsum.photos/300/300?random=781	2026-01-18 14:16:53.906332+00
album_0782	Works 13	Timbre	1966	Electronic	0.684250147909761	Europe	Germany	0.312169047411416	https://picsum.photos/300/300?random=782	2026-01-18 14:16:53.906332+00
album_0783	Overture 9	The Overtones	1973	Reggae	0.7189136970842376	Caribbean	Jamaica	0.31463705893051236	https://picsum.photos/300/300?random=783	2026-01-18 14:16:53.906332+00
album_0784	Opus 3	The Cadences	2005	Pop	0.5752436322755714	Asia	South Korea	0.6762223266645576	https://picsum.photos/300/300?random=784	2026-01-18 14:16:53.906332+00
album_0785	Volume 12	Major Sevenths	1994	K-Pop	0.8568454908615415	Asia	China	0.8837228208160866	https://picsum.photos/300/300?random=785	2026-01-18 14:16:53.906332+00
album_0786	Symphony 16	The Amplifiers	2008	Rock	0.7647240608850049	Europe	Spain	0.8081594141017514	https://picsum.photos/300/300?random=786	2026-01-18 14:16:53.906332+00
album_0787	Overture 16	Analog Future	1977	J-Pop	0.6367380471946218	Asia	India	0.6070322647746955	https://picsum.photos/300/300?random=787	2026-01-18 14:16:53.906332+00
album_0788	Chapter 7	The Intervals	1995	K-Pop	0.8612420611765247	Asia	India	0.323049544640341	https://picsum.photos/300/300?random=788	2026-01-18 14:16:53.906332+00
album_0789	Volume 2	The Cadences	1963	Classical	0.2578428556019688	Europe	Sweden	0.6983804739522849	https://picsum.photos/300/300?random=789	2026-01-18 14:16:53.906332+00
album_0790	Overture 4	The Vibrations	1987	Punk	0.8621110420813416	North America	Canada	0.7263834399535539	https://picsum.photos/300/300?random=790	2026-01-18 14:16:53.906332+00
album_0791	Overture 9	Beat Collective	1997	Pop	0.5553880500550052	Europe	Italy	0.5461416021227002	https://picsum.photos/300/300?random=791	2026-01-18 14:16:53.906332+00
album_0792	Volume 11	Sonic Boom	1976	Country	0.37255535551174784	North America	USA	0.8394694881706546	https://picsum.photos/300/300?random=792	2026-01-18 14:16:53.906332+00
album_0793	Session 13	The Soundscapes	1998	K-Pop	0.7533846622759539	Asia	Japan	0.6979776322099387	https://picsum.photos/300/300?random=793	2026-01-18 14:16:53.906332+00
album_0794	Opus 17	Wavelength	1971	Reggae	0.592923969249206	Caribbean	Trinidad	0.7717651165476465	https://picsum.photos/300/300?random=794	2026-01-18 14:16:53.906332+00
album_0795	Recordings 1	The Fundamentals	1988	Rock	0.7969199021637704	North America	USA	0.41480793445488384	https://picsum.photos/300/300?random=795	2026-01-18 14:16:53.906332+00
album_0796	Session 7	Chord Progressions	2018	Electronic	0.8343547594415532	North America	Canada	0.5052265805169713	https://picsum.photos/300/300?random=796	2026-01-18 14:16:53.906332+00
album_0797	Overture 4	The Arpeggios	2003	J-Pop	0.7334666933672237	Asia	China	0.4543839972161301	https://picsum.photos/300/300?random=797	2026-01-18 14:16:53.906332+00
album_0798	Chapter 20	Harmonic Series	1987	Jazz	0.456652052525946	North America	Mexico	0.8938390369226525	https://picsum.photos/300/300?random=798	2026-01-18 14:16:53.906332+00
album_0799	Suite 3	Digital Natives	1982	Rock	0.7614608244393517	Europe	Spain	0.5406063865414853	https://picsum.photos/300/300?random=799	2026-01-18 14:16:53.906332+00
album_0800	Chapter 13	The Frequencies	2018	J-Pop	0.7751553748154679	Asia	Japan	0.7791336714165169	https://picsum.photos/300/300?random=800	2026-01-18 14:16:53.906332+00
album_0801	Opus 10	The Intervals	1972	Indie Rock	0.7689657042104865	Europe	UK	0.34952756717886335	https://picsum.photos/300/300?random=801	2026-01-18 14:16:53.906332+00
album_0802	Suite 4	Echo Chamber	1979	Classical	0.2403735359256578	Europe	Germany	0.41418580929242604	https://picsum.photos/300/300?random=802	2026-01-18 14:16:53.906332+00
album_0803	Collection 18	Chord Progressions	2006	Pop	0.6811930140801117	North America	USA	0.5170627274755532	https://picsum.photos/300/300?random=803	2026-01-18 14:16:53.906332+00
album_0804	The 18 Album	The Fundamentals	1973	Jazz	0.6444919414278341	North America	Canada	0.5257716965709984	https://picsum.photos/300/300?random=804	2026-01-18 14:16:53.906332+00
album_0805	Opus 1	The Syncopators	1960	Metal	0.8182809564864261	Europe	Spain	0.8477029184880942	https://picsum.photos/300/300?random=805	2026-01-18 14:16:53.906332+00
album_0806	Overture 2	Tempo Changes	2018	Blues	0.5040106075802315	North America	Mexico	0.6607533313405405	https://picsum.photos/300/300?random=806	2026-01-18 14:16:53.906332+00
album_0807	The 15 Album	Scale Runners	1976	Country	0.4165068824701821	North America	Canada	0.3317718587204038	https://picsum.photos/300/300?random=807	2026-01-18 14:16:53.906332+00
album_0808	Study No. 13	The Intervals	1961	Classical	0.20300449934610715	Europe	Germany	0.33147281968293807	https://picsum.photos/300/300?random=808	2026-01-18 14:16:53.906332+00
album_0809	Symphony 12	Wavelength	2005	Metal	0.9372072756408596	Europe	France	0.4295179731908692	https://picsum.photos/300/300?random=809	2026-01-18 14:16:53.906332+00
album_0810	Collection 3	Sonic Boom	1989	J-Pop	0.796246670059084	Asia	India	0.35022858429066844	https://picsum.photos/300/300?random=810	2026-01-18 14:16:53.906332+00
album_0811	Overture 6	The Melodies	1961	J-Pop	0.6727866012006323	Asia	Japan	0.7903772037886445	https://picsum.photos/300/300?random=811	2026-01-18 14:16:53.906332+00
album_0812	Suite 16	Scale Runners	2020	Reggae	0.6655667705296511	Caribbean	Trinidad	0.4039029834542152	https://picsum.photos/300/300?random=812	2026-01-18 14:16:53.906332+00
album_0813	Recordings 16	The Rhythmics	1972	Rock	0.7177364749916102	Europe	Spain	0.3188133290168932	https://picsum.photos/300/300?random=813	2026-01-18 14:16:53.906332+00
album_0814	Recordings 12	Neon Dreams	2006	J-Pop	0.7203429390306916	Asia	China	0.4891775094271206	https://picsum.photos/300/300?random=814	2026-01-18 14:16:53.906332+00
album_0815	Recordings 6	Crystal Method	2022	Jazz	0.5811407800674282	North America	USA	0.3238235515530006	https://picsum.photos/300/300?random=815	2026-01-18 14:16:53.906332+00
album_0816	Opus 11	Timbre	2022	J-Pop	0.8158870288151274	Asia	China	0.3301032919679608	https://picsum.photos/300/300?random=816	2026-01-18 14:16:53.906332+00
album_0817	Chapter 18	The Oscillators	1999	Classical	0.25018117145983876	Europe	Italy	0.5741373748632879	https://picsum.photos/300/300?random=817	2026-01-18 14:16:53.906332+00
album_0818	Chapter 13	Frequency Shift	2012	Reggae	0.5301860289217432	Caribbean	Cuba	0.882292347468177	https://picsum.photos/300/300?random=818	2026-01-18 14:16:53.906332+00
album_0819	Session 5	Neon Dreams	1982	Classical	0.3237196565069429	Europe	Germany	0.6242483217387311	https://picsum.photos/300/300?random=819	2026-01-18 14:16:53.906332+00
album_0820	Suite 13	Decibel Rising	1994	Electronic	0.854997673085888	Europe	Sweden	0.60253430301129	https://picsum.photos/300/300?random=820	2026-01-18 14:16:53.906332+00
album_0821	Works 5	Tempo Changes	2021	Metal	0.8432242315682816	Europe	France	0.5724189242360795	https://picsum.photos/300/300?random=821	2026-01-18 14:16:53.906332+00
album_0822	Symphony 2	The Fundamentals	1979	Latin	0.7324443953248521	South America	Argentina	0.7976004221770142	https://picsum.photos/300/300?random=822	2026-01-18 14:16:53.906332+00
album_0823	Suite 12	Beat Collective	1999	Punk	0.8516328899957099	North America	USA	0.6452901294169737	https://picsum.photos/300/300?random=823	2026-01-18 14:16:53.906332+00
album_0824	Symphony 3	Decibel Rising	2002	Latin	0.7445454173995645	South America	Colombia	0.3245560836262859	https://picsum.photos/300/300?random=824	2026-01-18 14:16:53.906332+00
album_0825	Suite 16	Timbre	2000	Electronic	0.8373596268863871	Europe	France	0.7660428603189975	https://picsum.photos/300/300?random=825	2026-01-18 14:16:53.906332+00
album_0826	The 7 Album	The Harmonics	1968	Country	0.36824444366439885	North America	Mexico	0.7523712703725478	https://picsum.photos/300/300?random=826	2026-01-18 14:16:53.906332+00
album_0827	Collection 11	Resonance	1971	Jazz	0.5046272902746708	North America	USA	0.59535210445516	https://picsum.photos/300/300?random=827	2026-01-18 14:16:53.906332+00
album_0828	Session 17	Tempo Changes	1964	Rock	0.739381819681157	North America	USA	0.6829188470564527	https://picsum.photos/300/300?random=828	2026-01-18 14:16:53.906332+00
album_0829	Opus 8	Groove Theory	1965	Jazz	0.6014581733234988	North America	Mexico	0.6585098386375042	https://picsum.photos/300/300?random=829	2026-01-18 14:16:53.906332+00
album_0830	Chapter 2	Sonic Boom	1979	J-Pop	0.796685593763462	Asia	Japan	0.5501504616735258	https://picsum.photos/300/300?random=830	2026-01-18 14:16:53.906332+00
album_0831	Opus 5	The Syncopators	1967	Pop	0.6295234747883837	Asia	China	0.34759862453766854	https://picsum.photos/300/300?random=831	2026-01-18 14:16:53.906332+00
album_0832	Study No. 12	Beat Collective	1981	Blues	0.4275008069756205	North America	Mexico	0.651866278752766	https://picsum.photos/300/300?random=832	2026-01-18 14:16:53.906332+00
album_0833	Collection 18	Wavelength	1999	Pop	0.6388030409100952	North America	USA	0.6836201975639546	https://picsum.photos/300/300?random=833	2026-01-18 14:16:53.906332+00
album_0834	Works 10	Scale Runners	1985	Jazz	0.6404066256057874	North America	Mexico	0.785114176844019	https://picsum.photos/300/300?random=834	2026-01-18 14:16:53.906332+00
album_0835	Works 10	Tempo Changes	2017	Latin	0.6721864669809022	South America	Brazil	0.6640404572006102	https://picsum.photos/300/300?random=835	2026-01-18 14:16:53.906332+00
album_0836	Recordings 12	Major Sevenths	2023	K-Pop	0.6850205937223063	Asia	Japan	0.44709179573389984	https://picsum.photos/300/300?random=836	2026-01-18 14:16:53.906332+00
album_0837	Suite 2	The Dynamics	1966	Rock	0.782056241474766	North America	Canada	0.5232110285823997	https://picsum.photos/300/300?random=837	2026-01-18 14:16:53.906332+00
album_0838	Opus 6	The Oscillators	2005	Indie Rock	0.6854554424301852	North America	Canada	0.6091951475508994	https://picsum.photos/300/300?random=838	2026-01-18 14:16:53.906332+00
album_0839	Symphony 20	The Amplifiers	2005	Latin	0.6641200123723662	South America	Colombia	0.4268519398145103	https://picsum.photos/300/300?random=839	2026-01-18 14:16:53.906332+00
album_0840	Overture 2	Crystal Method	1984	Rock	0.6474403791135249	Europe	Spain	0.8777183733537524	https://picsum.photos/300/300?random=840	2026-01-18 14:16:53.906332+00
album_0841	Session 10	Pitch Perfect	1981	Rock	0.7654037288688125	Europe	Sweden	0.5747876746381766	https://picsum.photos/300/300?random=841	2026-01-18 14:16:53.906332+00
album_0842	Opus 15	Tempo Changes	1971	Electronic	0.7986159363214712	Europe	Italy	0.4861057460630309	https://picsum.photos/300/300?random=842	2026-01-18 14:16:53.906332+00
album_0843	The 14 Album	The Harmonics	2020	Country	0.4640251035846789	North America	USA	0.3067259965921684	https://picsum.photos/300/300?random=843	2026-01-18 14:16:53.906332+00
album_0844	Suite 13	Acoustic Waves	1976	Pop	0.7202810969219282	North America	Canada	0.5948523912595776	https://picsum.photos/300/300?random=844	2026-01-18 14:16:53.906332+00
album_0845	Study No. 16	Velvet Underground Revival	1990	Indie Rock	0.6580942910617497	North America	Mexico	0.4036719213466109	https://picsum.photos/300/300?random=845	2026-01-18 14:16:53.906332+00
album_0846	Overture 17	Echo Chamber	2018	K-Pop	0.811878702494741	Asia	India	0.6973496024384136	https://picsum.photos/300/300?random=846	2026-01-18 14:16:53.906332+00
album_0847	Symphony 13	Major Sevenths	1977	Hip Hop	0.7952785752687518	North America	USA	0.4362785793699826	https://picsum.photos/300/300?random=847	2026-01-18 14:16:53.906332+00
album_0848	The 19 Album	Reverb Nation	1993	Punk	0.8849512228055721	Europe	Italy	0.85691768384516	https://picsum.photos/300/300?random=848	2026-01-18 14:16:53.906332+00
album_0849	Volume 10	The Amplifiers	1999	Metal	0.8465111267456827	Europe	Sweden	0.8430198551401735	https://picsum.photos/300/300?random=849	2026-01-18 14:16:53.906332+00
album_0850	Symphony 15	Echo Chamber	2015	Classical	0.3896773626351692	Europe	France	0.729167141663623	https://picsum.photos/300/300?random=850	2026-01-18 14:16:53.906332+00
album_0851	Symphony 20	Chord Progressions	1976	Metal	0.8113427174402237	Europe	Italy	0.4127381181218611	https://picsum.photos/300/300?random=851	2026-01-18 14:16:53.906332+00
album_0852	Opus 13	The Oscillators	1977	Latin	0.7503108787404107	South America	Colombia	0.4981572801515962	https://picsum.photos/300/300?random=852	2026-01-18 14:16:53.906332+00
album_0853	The 13 Album	The Amplifiers	1992	Blues	0.47188659993559884	North America	USA	0.8963455839695629	https://picsum.photos/300/300?random=853	2026-01-18 14:16:53.906332+00
album_0854	Chapter 13	The Vibrations	2013	Classical	0.32567497387504435	Europe	Spain	0.4916486529039617	https://picsum.photos/300/300?random=854	2026-01-18 14:16:53.906332+00
album_0855	Works 3	Chord Progressions	1960	Jazz	0.5861261859184097	North America	Mexico	0.6346788523955429	https://picsum.photos/300/300?random=855	2026-01-18 14:16:53.906332+00
album_0856	Recordings 12	Harmonic Series	2000	Reggae	0.7117195144112587	Caribbean	Trinidad	0.8779062595941256	https://picsum.photos/300/300?random=856	2026-01-18 14:16:53.906332+00
album_0857	Suite 20	The Dynamics	1977	Classical	0.3851813620452879	Europe	UK	0.6859521927092711	https://picsum.photos/300/300?random=857	2026-01-18 14:16:53.906332+00
album_0858	Overture 6	Scale Runners	1960	Punk	0.8192383266444027	Europe	Italy	0.5021994645326905	https://picsum.photos/300/300?random=858	2026-01-18 14:16:53.906332+00
album_0859	Suite 9	The Dynamics	1965	Reggae	0.5305559130229378	Caribbean	Trinidad	0.3184883090110324	https://picsum.photos/300/300?random=859	2026-01-18 14:16:53.906332+00
album_0860	Symphony 12	Timbre	1985	Classical	0.3490472086808811	Europe	Spain	0.5529713430673606	https://picsum.photos/300/300?random=860	2026-01-18 14:16:53.906332+00
album_0861	Study No. 3	Neon Dreams	1986	Punk	0.731951353840042	North America	Mexico	0.7938346868584882	https://picsum.photos/300/300?random=861	2026-01-18 14:16:53.906332+00
album_0862	Chapter 16	Pitch Perfect	2009	J-Pop	0.6581833035166759	Asia	South Korea	0.326437961905638	https://picsum.photos/300/300?random=862	2026-01-18 14:16:53.906332+00
album_0863	Suite 6	The Rhythmics	1963	Country	0.49091215721562703	North America	USA	0.7282012810379416	https://picsum.photos/300/300?random=863	2026-01-18 14:16:53.906332+00
album_0864	Collection 14	Harmonic Series	2002	Jazz	0.496388070707671	North America	Canada	0.7811401130698012	https://picsum.photos/300/300?random=864	2026-01-18 14:16:53.906332+00
album_0865	The 15 Album	Wavelength	1975	Rock	0.6573133730448479	Europe	France	0.7461533312138904	https://picsum.photos/300/300?random=865	2026-01-18 14:16:53.906332+00
album_0866	Works 10	Resonance	1988	Hip Hop	0.7782609783140908	North America	USA	0.30877251604366396	https://picsum.photos/300/300?random=866	2026-01-18 14:16:53.906332+00
album_0867	Chapter 19	Wavelength	1994	Blues	0.5383294939099516	North America	USA	0.46712169899230377	https://picsum.photos/300/300?random=867	2026-01-18 14:16:53.906332+00
album_0868	Symphony 10	Echo Chamber	2006	Blues	0.5198435609785523	North America	Canada	0.5170746879385499	https://picsum.photos/300/300?random=868	2026-01-18 14:16:53.906332+00
album_0869	Chapter 16	The Cadences	1977	Pop	0.6051491177286326	North America	Canada	0.6226710950145167	https://picsum.photos/300/300?random=869	2026-01-18 14:16:53.906332+00
album_0870	Chapter 9	The Cadences	1988	Country	0.42924240340018255	North America	Canada	0.7267723793847345	https://picsum.photos/300/300?random=870	2026-01-18 14:16:53.906332+00
album_0871	Suite 5	Sonic Boom	2024	Indie Rock	0.6616828321317391	Europe	UK	0.6502604502839511	https://picsum.photos/300/300?random=871	2026-01-18 14:16:53.906332+00
album_0872	Recordings 20	Pitch Perfect	1968	K-Pop	0.6937805355269391	Asia	India	0.8905647385814874	https://picsum.photos/300/300?random=872	2026-01-18 14:16:53.906332+00
album_0873	Recordings 8	The Harmonics	1996	Jazz	0.5083294109324282	North America	USA	0.7522926067089608	https://picsum.photos/300/300?random=873	2026-01-18 14:16:53.906332+00
album_0874	Study No. 4	Beat Collective	1979	Classical	0.2574944571083968	Europe	France	0.8140216575926602	https://picsum.photos/300/300?random=874	2026-01-18 14:16:53.906332+00
album_0875	Collection 7	Sonic Boom	1985	Latin	0.665184950984406	South America	Argentina	0.6804303036394234	https://picsum.photos/300/300?random=875	2026-01-18 14:16:53.906332+00
album_0876	Opus 15	Harmonic Series	1970	Pop	0.658189873927898	Asia	South Korea	0.8631052205801937	https://picsum.photos/300/300?random=876	2026-01-18 14:16:53.906332+00
album_0877	Suite 13	Harmonic Series	1971	Hip Hop	0.829104600309096	North America	Mexico	0.6315005123433084	https://picsum.photos/300/300?random=877	2026-01-18 14:16:53.906332+00
album_0878	Session 7	Beat Collective	1972	K-Pop	0.8295404559809888	Asia	India	0.6996261362810794	https://picsum.photos/300/300?random=878	2026-01-18 14:16:53.906332+00
album_0879	Chapter 17	The Vibrations	1978	J-Pop	0.7143265706121927	Asia	Japan	0.36035570964681424	https://picsum.photos/300/300?random=879	2026-01-18 14:16:53.906332+00
album_0880	Recordings 16	Resonance	2004	Electronic	0.6806231521780097	North America	Canada	0.7292804662909242	https://picsum.photos/300/300?random=880	2026-01-18 14:16:53.906332+00
album_0881	Suite 13	Groove Theory	1997	Hip Hop	0.7469277540830476	North America	Canada	0.6790713918284408	https://picsum.photos/300/300?random=881	2026-01-18 14:16:53.906332+00
album_0882	Study No. 17	The Fundamentals	1984	Country	0.45353946732075573	North America	USA	0.6611321454531924	https://picsum.photos/300/300?random=882	2026-01-18 14:16:53.906332+00
album_0883	Recordings 3	Sonic Youth Jr.	2010	J-Pop	0.6869249013676794	Asia	China	0.8942574941932178	https://picsum.photos/300/300?random=883	2026-01-18 14:16:53.906332+00
album_0884	Chapter 3	The Frequencies	2008	K-Pop	0.8695818096552909	Asia	India	0.7278933182847461	https://picsum.photos/300/300?random=884	2026-01-18 14:16:53.906332+00
album_0885	The 2 Album	Major Sevenths	1989	Rock	0.7642722863886764	North America	Mexico	0.4748609095793084	https://picsum.photos/300/300?random=885	2026-01-18 14:16:53.906332+00
album_0886	Opus 8	Wavelength	2018	Pop	0.7256438504389235	Europe	France	0.45479350582971745	https://picsum.photos/300/300?random=886	2026-01-18 14:16:53.906332+00
album_0887	Opus 15	Neon Dreams	1970	Indie Rock	0.6276738690326165	Europe	UK	0.8902098914366101	https://picsum.photos/300/300?random=887	2026-01-18 14:16:53.906332+00
album_0888	Session 19	Sonic Boom	2017	Jazz	0.6128010245093303	North America	USA	0.49251763648168057	https://picsum.photos/300/300?random=888	2026-01-18 14:16:53.906332+00
album_0889	Symphony 18	Timbre	2000	Classical	0.3415342509546582	Europe	Spain	0.6586283455048718	https://picsum.photos/300/300?random=889	2026-01-18 14:16:53.906332+00
album_0890	Works 11	The Harmonics	1964	Latin	0.6418961691811597	South America	Brazil	0.6769598760216973	https://picsum.photos/300/300?random=890	2026-01-18 14:16:53.906332+00
album_0891	Opus 8	Resonance	2022	Indie Rock	0.7477517885697581	North America	Canada	0.7926730549645765	https://picsum.photos/300/300?random=891	2026-01-18 14:16:53.906332+00
album_0892	Chapter 4	Frequency Shift	1965	Electronic	0.7811610799451244	North America	USA	0.3381969456793371	https://picsum.photos/300/300?random=892	2026-01-18 14:16:53.906332+00
album_0893	Collection 6	Reverb Nation	2004	Hip Hop	0.7007007994541984	North America	Canada	0.8201760705283219	https://picsum.photos/300/300?random=893	2026-01-18 14:16:53.906332+00
album_0894	Recordings 5	Reverb Nation	1999	Classical	0.28326451761226834	Europe	Italy	0.3004940868054875	https://picsum.photos/300/300?random=894	2026-01-18 14:16:53.906332+00
album_0895	Recordings 9	Reverb Nation	2016	Electronic	0.756679131226147	North America	Mexico	0.5755976015893061	https://picsum.photos/300/300?random=895	2026-01-18 14:16:53.906332+00
album_0896	Works 7	The Rhythmics	1995	Indie Rock	0.6180797733340395	Europe	Italy	0.39383357478408565	https://picsum.photos/300/300?random=896	2026-01-18 14:16:53.906332+00
album_0897	Suite 4	The Melodies	1998	Punk	0.8175941418355228	Europe	Italy	0.8277641750315923	https://picsum.photos/300/300?random=897	2026-01-18 14:16:53.906332+00
album_0898	Collection 13	The Rhythmics	1973	Punk	0.7010944700064592	Europe	Spain	0.6227222669538315	https://picsum.photos/300/300?random=898	2026-01-18 14:16:53.906332+00
album_0899	The 20 Album	The Oscillators	1997	Jazz	0.5033738032677032	North America	Mexico	0.3485918369208125	https://picsum.photos/300/300?random=899	2026-01-18 14:16:53.906332+00
album_0900	Opus 6	The Melodies	2008	Jazz	0.5387763573782351	North America	Canada	0.6286005645472432	https://picsum.photos/300/300?random=900	2026-01-18 14:16:53.906332+00
album_0901	Volume 11	Frequency Shift	1972	Hip Hop	0.6959116701077342	North America	Canada	0.5445424977081346	https://picsum.photos/300/300?random=901	2026-01-18 14:16:53.906332+00
album_0902	Collection 7	The Frequencies	2020	Metal	0.8759737876479414	North America	Mexico	0.6038392924134248	https://picsum.photos/300/300?random=902	2026-01-18 14:16:53.906332+00
album_0903	Collection 12	Analog Future	2001	Classical	0.32507956617990097	Europe	France	0.6541412950783998	https://picsum.photos/300/300?random=903	2026-01-18 14:16:53.906332+00
album_0904	Overture 12	Chord Progressions	1982	Electronic	0.7890891396500876	Europe	Sweden	0.3084780699571634	https://picsum.photos/300/300?random=904	2026-01-18 14:16:53.906332+00
album_0905	Chapter 8	Crescendo	2006	Indie Rock	0.6935794920573352	North America	USA	0.3104569642380928	https://picsum.photos/300/300?random=905	2026-01-18 14:16:53.906332+00
album_0906	Overture 20	Beat Collective	1996	Metal	0.9062530201507245	Europe	France	0.32142451028532854	https://picsum.photos/300/300?random=906	2026-01-18 14:16:53.906332+00
album_0907	Session 5	Harmonic Series	1998	Reggae	0.5240329111082487	Caribbean	Jamaica	0.35834424173657364	https://picsum.photos/300/300?random=907	2026-01-18 14:16:53.906332+00
album_0908	Session 8	The Overtones	1995	Blues	0.40638841457655644	North America	Mexico	0.7463311191991575	https://picsum.photos/300/300?random=908	2026-01-18 14:16:53.906332+00
album_0909	Session 4	Resonance	2002	Indie Rock	0.7595482529159893	Europe	Italy	0.5503000570441384	https://picsum.photos/300/300?random=909	2026-01-18 14:16:53.906332+00
album_0910	Overture 19	Groove Theory	2004	Electronic	0.7862974434352868	North America	Mexico	0.5156444322670253	https://picsum.photos/300/300?random=910	2026-01-18 14:16:53.906332+00
album_0911	Symphony 13	The Intervals	1976	J-Pop	0.739384680745625	Asia	Japan	0.7836246365231042	https://picsum.photos/300/300?random=911	2026-01-18 14:16:53.906332+00
album_0912	The 7 Album	Timbre	2015	Electronic	0.7192134634289856	Europe	Sweden	0.7674296397505653	https://picsum.photos/300/300?random=912	2026-01-18 14:16:53.906332+00
album_0913	Works 11	Harmonic Series	2000	Jazz	0.5458686300252688	North America	USA	0.5085416980972465	https://picsum.photos/300/300?random=913	2026-01-18 14:16:53.906332+00
album_0914	The 14 Album	Major Sevenths	1991	J-Pop	0.7926174340816696	Asia	South Korea	0.49413094394968704	https://picsum.photos/300/300?random=914	2026-01-18 14:16:53.906332+00
album_0915	Overture 1	Tempo Changes	1969	Classical	0.3402111859115311	Europe	Spain	0.3711393685751913	https://picsum.photos/300/300?random=915	2026-01-18 14:16:53.906332+00
album_0916	Study No. 13	The Vibrations	1976	Reggae	0.6500851506492225	Caribbean	Jamaica	0.8983578101141536	https://picsum.photos/300/300?random=916	2026-01-18 14:16:53.906332+00
album_0917	Collection 19	The Vibrations	1991	Indie Rock	0.5859616448048413	Europe	France	0.5985561533419381	https://picsum.photos/300/300?random=917	2026-01-18 14:16:53.906332+00
album_0918	Study No. 10	Sonic Boom	1989	Rock	0.7861190797273676	Europe	Germany	0.8325657145673782	https://picsum.photos/300/300?random=918	2026-01-18 14:16:53.906332+00
album_0919	Overture 15	Harmonic Series	1971	Indie Rock	0.59339789844617	North America	Mexico	0.3349373701033273	https://picsum.photos/300/300?random=919	2026-01-18 14:16:53.906332+00
album_0920	Collection 7	The Intervals	1964	Rock	0.6002302568775393	Europe	Italy	0.6688021710459484	https://picsum.photos/300/300?random=920	2026-01-18 14:16:53.906332+00
album_0921	Opus 17	Wavelength	2002	Indie Rock	0.7238029540154036	Europe	Sweden	0.64009679835685	https://picsum.photos/300/300?random=921	2026-01-18 14:16:53.906332+00
album_0922	Symphony 15	Sonic Youth Jr.	1965	Blues	0.4648722389755503	North America	Canada	0.33261682395655834	https://picsum.photos/300/300?random=922	2026-01-18 14:16:53.906332+00
album_0923	Collection 9	Minor Keys	1963	Indie Rock	0.730799167556769	Europe	Sweden	0.7584076895150671	https://picsum.photos/300/300?random=923	2026-01-18 14:16:53.906332+00
album_0924	The 2 Album	Tempo Changes	1985	Jazz	0.5001953726294631	North America	Mexico	0.7835092294361627	https://picsum.photos/300/300?random=924	2026-01-18 14:16:53.906332+00
album_0925	Suite 2	Crescendo	2000	Jazz	0.6400720455833429	North America	USA	0.306776847775594	https://picsum.photos/300/300?random=925	2026-01-18 14:16:53.906332+00
album_0926	Volume 5	The Rhythmics	1984	Metal	0.7799013905765056	North America	USA	0.6621267268122883	https://picsum.photos/300/300?random=926	2026-01-18 14:16:53.906332+00
album_0927	The 9 Album	Pitch Perfect	1967	Hip Hop	0.768886051996036	North America	Canada	0.8323066632137139	https://picsum.photos/300/300?random=927	2026-01-18 14:16:53.906332+00
album_0928	Works 8	Tempo Changes	2021	Punk	0.7128475374931731	North America	Mexico	0.6450774168727018	https://picsum.photos/300/300?random=928	2026-01-18 14:16:53.906332+00
album_0929	Study No. 9	Analog Future	1969	K-Pop	0.8770024199336095	Asia	South Korea	0.7718037786048133	https://picsum.photos/300/300?random=929	2026-01-18 14:16:53.906332+00
album_0930	Chapter 5	Crescendo	1999	Punk	0.8245712031677132	North America	USA	0.8491155428258939	https://picsum.photos/300/300?random=930	2026-01-18 14:16:53.906332+00
album_0931	Chapter 10	The Soundscapes	1984	Electronic	0.6917629785868538	Europe	France	0.6489226841836004	https://picsum.photos/300/300?random=931	2026-01-18 14:16:53.906332+00
album_0932	Suite 13	Crescendo	1980	Pop	0.6898941397252694	Europe	UK	0.3474005824741424	https://picsum.photos/300/300?random=932	2026-01-18 14:16:53.906332+00
album_0933	Opus 16	The Overtones	2022	Indie Rock	0.7209243931420042	North America	USA	0.6270059743273781	https://picsum.photos/300/300?random=933	2026-01-18 14:16:53.906332+00
album_0934	Recordings 16	Resonance	1966	Hip Hop	0.6767912419073426	North America	Mexico	0.5348131908261045	https://picsum.photos/300/300?random=934	2026-01-18 14:16:53.906332+00
album_0935	Suite 19	The Amplifiers	1998	Electronic	0.6993500619659626	North America	USA	0.650130227651021	https://picsum.photos/300/300?random=935	2026-01-18 14:16:53.906332+00
album_0936	Session 5	The Arpeggios	2001	Punk	0.7496250272926158	North America	USA	0.4338144910153538	https://picsum.photos/300/300?random=936	2026-01-18 14:16:53.906332+00
album_0937	Chapter 3	The Rhythmics	1967	Electronic	0.7032384521622648	North America	Mexico	0.6999378960726184	https://picsum.photos/300/300?random=937	2026-01-18 14:16:53.906332+00
album_0938	Opus 11	The Oscillators	1992	Blues	0.48150898076268617	North America	Mexico	0.8614754768052579	https://picsum.photos/300/300?random=938	2026-01-18 14:16:53.906332+00
album_0939	Study No. 3	Echo Chamber	2001	Electronic	0.7760400966537313	Europe	Germany	0.477204180503579	https://picsum.photos/300/300?random=939	2026-01-18 14:16:53.906332+00
album_0940	Collection 17	The Amplifiers	2003	Electronic	0.7468100308833329	Europe	Spain	0.5430713141182845	https://picsum.photos/300/300?random=940	2026-01-18 14:16:53.906332+00
album_0941	Symphony 4	The Oscillators	1969	Indie Rock	0.6377559369929359	Europe	Spain	0.8721213470901246	https://picsum.photos/300/300?random=941	2026-01-18 14:16:53.906332+00
album_0942	Collection 12	The Rhythmics	1989	Rock	0.6268748789477737	Europe	Italy	0.8164148849498973	https://picsum.photos/300/300?random=942	2026-01-18 14:16:53.906332+00
album_0943	Session 5	Acoustic Waves	1988	Electronic	0.8559262258555708	Europe	Sweden	0.7236043996813004	https://picsum.photos/300/300?random=943	2026-01-18 14:16:53.906332+00
album_0944	Suite 11	Harmonic Series	1985	Electronic	0.7772501574970804	Europe	France	0.5524909436977993	https://picsum.photos/300/300?random=944	2026-01-18 14:16:53.906332+00
album_0945	Collection 14	Digital Natives	1966	J-Pop	0.6412472121815759	Asia	South Korea	0.59364970288071	https://picsum.photos/300/300?random=945	2026-01-18 14:16:53.906332+00
album_0946	Recordings 12	Crystal Method	1973	Electronic	0.6868704962099638	North America	Canada	0.5743397306259383	https://picsum.photos/300/300?random=946	2026-01-18 14:16:53.906332+00
album_0947	Opus 10	The Intervals	1982	Jazz	0.5548433403471029	North America	Canada	0.8372537542860459	https://picsum.photos/300/300?random=947	2026-01-18 14:16:53.906332+00
album_0948	The 9 Album	The Rhythmics	1967	Latin	0.6181974286099302	South America	Argentina	0.7538167876686204	https://picsum.photos/300/300?random=948	2026-01-18 14:16:53.906332+00
album_0949	Suite 11	The Rhythmics	2006	K-Pop	0.7654680087713717	Asia	Japan	0.7357030711715287	https://picsum.photos/300/300?random=949	2026-01-18 14:16:53.906332+00
album_0950	Overture 13	The Soundscapes	2009	Blues	0.45138932861604975	North America	Canada	0.8169537666369995	https://picsum.photos/300/300?random=950	2026-01-18 14:16:53.906332+00
album_0951	Chapter 20	Frequency Shift	2012	Blues	0.5129076156841571	North America	USA	0.8854300934747152	https://picsum.photos/300/300?random=951	2026-01-18 14:16:53.906332+00
album_0952	Symphony 6	Resonance	2007	Electronic	0.726947939409819	Europe	Spain	0.4371349740708479	https://picsum.photos/300/300?random=952	2026-01-18 14:16:53.906332+00
album_0953	Chapter 10	Reverb Nation	2006	Punk	0.774207889733755	Europe	UK	0.8974618611522844	https://picsum.photos/300/300?random=953	2026-01-18 14:16:53.906332+00
album_0954	Volume 11	The Melodies	2003	Hip Hop	0.8061355013119971	North America	Mexico	0.5686965495254988	https://picsum.photos/300/300?random=954	2026-01-18 14:16:53.906332+00
album_0955	Works 15	The Overtones	2011	Latin	0.6297221119549296	South America	Brazil	0.8415658959353061	https://picsum.photos/300/300?random=955	2026-01-18 14:16:53.906332+00
album_0956	Recordings 8	The Intervals	1995	Metal	0.7536775508712948	North America	Canada	0.4088477558540786	https://picsum.photos/300/300?random=956	2026-01-18 14:16:53.906332+00
album_0957	Chapter 20	The Frequencies	1981	Punk	0.8882336461329425	North America	Canada	0.7659527404581588	https://picsum.photos/300/300?random=957	2026-01-18 14:16:53.906332+00
album_0958	Overture 5	Crescendo	1976	Electronic	0.7425389073469021	North America	Mexico	0.32540478155827085	https://picsum.photos/300/300?random=958	2026-01-18 14:16:53.906332+00
album_0959	Suite 20	Groove Theory	1981	K-Pop	0.8589018041994397	Asia	India	0.32872597348956145	https://picsum.photos/300/300?random=959	2026-01-18 14:16:53.906332+00
album_0960	Recordings 17	Crescendo	1972	Classical	0.32069768537301113	Europe	Germany	0.579239829417171	https://picsum.photos/300/300?random=960	2026-01-18 14:16:53.906332+00
album_0961	Recordings 19	The Intervals	2016	Country	0.5051536333809125	North America	USA	0.6178069376982074	https://picsum.photos/300/300?random=961	2026-01-18 14:16:53.906332+00
album_0962	Recordings 18	The Harmonics	1995	Jazz	0.4899329170480162	North America	USA	0.3857495777128866	https://picsum.photos/300/300?random=962	2026-01-18 14:16:53.906332+00
album_0963	Chapter 10	Major Sevenths	1984	Country	0.5338773702902705	North America	Canada	0.46277145553763266	https://picsum.photos/300/300?random=963	2026-01-18 14:16:53.906332+00
album_0964	Symphony 12	Decibel Rising	2013	Rock	0.6941686779025368	North America	Mexico	0.8398194554342158	https://picsum.photos/300/300?random=964	2026-01-18 14:16:53.906332+00
album_0965	Overture 14	The Overtones	1986	Latin	0.698047065142835	South America	Colombia	0.6923598751810633	https://picsum.photos/300/300?random=965	2026-01-18 14:16:53.906332+00
album_0966	Symphony 15	The Vibrations	1976	Punk	0.864223125072473	North America	USA	0.5822072452676752	https://picsum.photos/300/300?random=966	2026-01-18 14:16:53.906332+00
album_0967	Suite 14	Velvet Underground Revival	2014	Reggae	0.6714247287591626	Caribbean	Jamaica	0.7051636996432102	https://picsum.photos/300/300?random=967	2026-01-18 14:16:53.906332+00
album_0968	Symphony 18	Minor Keys	1985	Indie Rock	0.7490249654187376	Europe	France	0.4328976217972409	https://picsum.photos/300/300?random=968	2026-01-18 14:16:53.906332+00
album_0969	Symphony 16	Reverb Nation	1966	Rock	0.770796182145427	Europe	Sweden	0.3133758670045638	https://picsum.photos/300/300?random=969	2026-01-18 14:16:53.906332+00
album_0970	Recordings 13	Velvet Underground Revival	1990	Punk	0.7273763808040967	Europe	Spain	0.4937693777730988	https://picsum.photos/300/300?random=970	2026-01-18 14:16:53.906332+00
album_0971	Works 4	The Syncopators	1995	Country	0.45762943551735913	North America	Mexico	0.6021846352102272	https://picsum.photos/300/300?random=971	2026-01-18 14:16:53.906332+00
album_0972	Session 2	The Amplifiers	2011	Electronic	0.6897505575274911	North America	USA	0.6599006757026908	https://picsum.photos/300/300?random=972	2026-01-18 14:16:53.906332+00
album_0973	Study No. 16	Tempo Changes	1977	Electronic	0.763100329600954	Europe	France	0.44281305638430923	https://picsum.photos/300/300?random=973	2026-01-18 14:16:53.906332+00
album_0974	Suite 17	The Arpeggios	1977	Classical	0.35827885481720345	Europe	UK	0.4027065687401554	https://picsum.photos/300/300?random=974	2026-01-18 14:16:53.906332+00
album_0975	Collection 6	The Arpeggios	2017	Jazz	0.4860510196080176	North America	USA	0.5763744720418412	https://picsum.photos/300/300?random=975	2026-01-18 14:16:53.906332+00
album_0976	Opus 16	Wavelength	2007	Blues	0.5674724705883907	North America	USA	0.7124829160901844	https://picsum.photos/300/300?random=976	2026-01-18 14:16:53.906332+00
album_0977	Recordings 9	Scale Runners	1974	Jazz	0.4980556578893045	North America	Canada	0.7851758881599726	https://picsum.photos/300/300?random=977	2026-01-18 14:16:53.906332+00
album_0978	Suite 8	Pitch Perfect	1974	Blues	0.5479939916288867	North America	Canada	0.44013390578165823	https://picsum.photos/300/300?random=978	2026-01-18 14:16:53.906332+00
album_0979	Study No. 10	The Intervals	1990	Country	0.48631140491502034	North America	Canada	0.44449741304002255	https://picsum.photos/300/300?random=979	2026-01-18 14:16:53.906332+00
album_0980	Volume 12	The Frequencies	1974	Rock	0.6838872292888316	North America	Mexico	0.5956789987556608	https://picsum.photos/300/300?random=980	2026-01-18 14:16:53.906332+00
album_0981	Chapter 11	Digital Natives	1991	Latin	0.7714221423705712	South America	Colombia	0.748834466374338	https://picsum.photos/300/300?random=981	2026-01-18 14:16:53.906332+00
album_0982	Volume 8	Major Sevenths	2013	Indie Rock	0.6365214709593402	Europe	Germany	0.48834427612355896	https://picsum.photos/300/300?random=982	2026-01-18 14:16:53.906332+00
album_0983	Recordings 10	Analog Future	2006	Indie Rock	0.6523657581069369	Europe	Germany	0.32795556907775136	https://picsum.photos/300/300?random=983	2026-01-18 14:16:53.906332+00
album_0984	Volume 19	Pitch Perfect	2017	Reggae	0.6766939145876802	Caribbean	Jamaica	0.4617065952570076	https://picsum.photos/300/300?random=984	2026-01-18 14:16:53.906332+00
album_0985	Study No. 9	Sonic Boom	1992	Electronic	0.7889112626085325	Europe	Germany	0.7629274829847248	https://picsum.photos/300/300?random=985	2026-01-18 14:16:53.906332+00
album_0986	Symphony 2	Scale Runners	1998	K-Pop	0.8036395322437352	Asia	South Korea	0.5124738394961055	https://picsum.photos/300/300?random=986	2026-01-18 14:16:53.906332+00
album_0987	Volume 7	Harmonic Series	1960	Rock	0.623675580635077	Europe	Sweden	0.8964637760706609	https://picsum.photos/300/300?random=987	2026-01-18 14:16:53.906332+00
album_0988	Chapter 6	Resonance	1961	Jazz	0.48037874169329886	North America	Canada	0.579869874745335	https://picsum.photos/300/300?random=988	2026-01-18 14:16:53.906332+00
album_0989	Suite 19	Major Sevenths	2002	K-Pop	0.7826958575002554	Asia	Japan	0.8813800398948137	https://picsum.photos/300/300?random=989	2026-01-18 14:16:53.906332+00
album_0990	Overture 14	The Melodies	1996	Reggae	0.5485234547845725	Caribbean	Trinidad	0.8652381009126586	https://picsum.photos/300/300?random=990	2026-01-18 14:16:53.906332+00
album_0991	Recordings 19	Reverb Nation	2017	Pop	0.6068609135110394	Asia	India	0.833918197557252	https://picsum.photos/300/300?random=991	2026-01-18 14:16:53.906332+00
album_0992	Opus 15	Chord Progressions	1977	J-Pop	0.699404383096571	Asia	Japan	0.786545103946633	https://picsum.photos/300/300?random=992	2026-01-18 14:16:53.906332+00
album_0993	Recordings 13	Crescendo	2011	Country	0.3540948352160759	North America	USA	0.5412057818907947	https://picsum.photos/300/300?random=993	2026-01-18 14:16:53.906332+00
album_0994	Overture 16	Reverb Nation	1983	J-Pop	0.6258427494765457	Asia	South Korea	0.7934543195642616	https://picsum.photos/300/300?random=994	2026-01-18 14:16:53.906332+00
album_0995	Suite 13	Timbre	2000	Reggae	0.5538306057128498	Caribbean	Jamaica	0.557287468474318	https://picsum.photos/300/300?random=995	2026-01-18 14:16:53.906332+00
album_0996	Works 9	Sonic Youth Jr.	1966	Jazz	0.5207147277076746	North America	USA	0.6234889766748308	https://picsum.photos/300/300?random=996	2026-01-18 14:16:53.906332+00
album_0997	The 9 Album	Neon Dreams	1988	Metal	0.939960850438654	Europe	Spain	0.41883704941369876	https://picsum.photos/300/300?random=997	2026-01-18 14:16:53.906332+00
album_0998	Overture 19	Tempo Changes	2016	Indie Rock	0.7256160990190661	Europe	Spain	0.7185266787568155	https://picsum.photos/300/300?random=998	2026-01-18 14:16:53.906332+00
album_0999	Session 16	The Fundamentals	1960	Blues	0.514734751945881	North America	Canada	0.4277193011972563	https://picsum.photos/300/300?random=999	2026-01-18 14:16:53.906332+00
album_1000	The 16 Album	Crescendo	2006	Metal	0.8396177402245218	North America	Canada	0.47823397273792373	https://picsum.photos/300/300?random=1000	2026-01-18 14:16:53.906332+00
musicbrainz:rg:008abf69-d49f-458c-b8c2-13eb12a827c7	Mitridate, re di Ponto	Mozart	2014	Classical	0.75	North America	Austria	0.75	https://coverartarchive.org/release-group/008abf69-d49f-458c-b8c2-13eb12a827c7/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:009a0cb4-eb7a-4138-b133-e769fa3397a9	Dateline Live!	Dateline	2020	Rock	0.3	Oceania	New Zealand	0.75	https://coverartarchive.org/release-group/009a0cb4-eb7a-4138-b133-e769fa3397a9/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:0134f923-3c78-4122-acf9-5eafb24e3199	we never dated	sombr	2025	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/0134f923-3c78-4122-acf9-5eafb24e3199/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:013933e0-d173-4c71-ad0e-eecb53c6b05d	U2 2 Date	U2	1989	Rock	0.3	Europe	Ireland	0.75	https://coverartarchive.org/release-group/013933e0-d173-4c71-ad0e-eecb53c6b05d/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:020ad14a-c369-4f08-b63b-f0b1e39189a7	Playdate	Noah Baerman	2009	Jazz	0.7	Unknown	\N	0.75	https://coverartarchive.org/release-group/020ad14a-c369-4f08-b63b-f0b1e39189a7/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:024c5098-ee71-3631-9a9b-dd794fd0364b	Update Files	Total Eclipse	2003	Electronic	0.8	Europe	France	0.75	https://coverartarchive.org/release-group/024c5098-ee71-3631-9a9b-dd794fd0364b/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:041f20f9-8219-4cbe-8b19-de15bb25dee9	Date Night	Lach	2020	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/041f20f9-8219-4cbe-8b19-de15bb25dee9/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:05d2921c-5d43-4ac4-aec4-0487e739eb16	First Date	flamingo zamperoni	2022	Hip Hop	0.5	Unknown	\N	0.75	https://coverartarchive.org/release-group/05d2921c-5d43-4ac4-aec4-0487e739eb16/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:06c08467-fdc4-4903-a28f-8a954d367f01	Quédate (remix)	Andy Rivera	2016	Latin	0.62	South America	Colombia	0.75	https://coverartarchive.org/release-group/06c08467-fdc4-4903-a28f-8a954d367f01/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:07813cf3-f9bc-3ace-8f19-bf70027e990c	The Grind Date	De La Soul	2004	Hip Hop	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/07813cf3-f9bc-3ace-8f19-bf70027e990c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:078812d0-7396-4076-a56f-95d237d835ec	The Carbon Date EP	Actor|Observer	2011	Rock	0.3	Unknown	Boston	0.75	https://coverartarchive.org/release-group/078812d0-7396-4076-a56f-95d237d835ec/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:078ee5a7-978b-41fc-bbd5-525b94ad3541	Ultra-Date!	ULTRA-PRISM	2011	Electronic	0.8	Asia	Japan	0.75	https://coverartarchive.org/release-group/078ee5a7-978b-41fc-bbd5-525b94ad3541/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:087bdb85-6ebd-4ebe-97f4-3d10da0daa1e	Update	Mind over MIDI	2014	Electronic	0.8	Europe	Norway	0.75	https://coverartarchive.org/release-group/087bdb85-6ebd-4ebe-97f4-3d10da0daa1e/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:09733883-0327-4d9f-8e3a-61bc711cb105	The Mandate	The Room Colored Charlatan	2020	Electronic	0.8	Asia	Indianapolis	0.75	https://coverartarchive.org/release-group/09733883-0327-4d9f-8e3a-61bc711cb105/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:0a743f50-f7d3-335b-a4bc-ac51332446d9	Date With Time	Michel Petrucciani	1991	Jazz	0.7	Europe	France	0.75	https://coverartarchive.org/release-group/0a743f50-f7d3-335b-a4bc-ac51332446d9/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:0a745e55-fce6-4334-8bf4-299a2810a7c7	50 First Dates: Love Songs From the Original Motion Picture	Various Artists	2004	Hip Hop	0.5	Unknown	\N	0.75	https://coverartarchive.org/release-group/0a745e55-fce6-4334-8bf4-299a2810a7c7/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:0c0cb6f8-99ae-46bb-8b3c-bac758ef8028	Cheap Date	Sauna	2013	Rock	0.3	Unknown	Colorado	0.75	https://coverartarchive.org/release-group/0c0cb6f8-99ae-46bb-8b3c-bac758ef8028/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:0c479116-8961-4367-b7ed-74c4ddd64fbb	Update, Vol. 2	Guanábanas	2016	Latin	0.62	Unknown	Puerto Rico	0.75	https://coverartarchive.org/release-group/0c479116-8961-4367-b7ed-74c4ddd64fbb/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:0cccc4d6-8ecf-4e58-9af4-70480a5f9af5	Sedated	CRYPT1K	2020	Hip Hop	0.5	Unknown	Dallas	0.75	https://coverartarchive.org/release-group/0cccc4d6-8ecf-4e58-9af4-70480a5f9af5/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:0df61762-91f0-4b02-8b23-67efa6f5f4b8	Your Prom Date	Fossil Cunt	1994	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/0df61762-91f0-4b02-8b23-67efa6f5f4b8/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:0e3466a5-9185-427a-abac-faeb700dc1f2	A Date With The Everly Brothers / Instant Party	The Everly Brothers	2000	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/0e3466a5-9185-427a-abac-faeb700dc1f2/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:0e46cb21-0ecc-337d-b74f-0185b4eee1fc	Sedated in the Eighties, No. 4	Various Artists	1995	Other	0.5	Unknown	\N	0.75	https://coverartarchive.org/release-group/0e46cb21-0ecc-337d-b74f-0185b4eee1fc/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:0e695e56-b917-4115-aaf1-85ad697469ab	Daten daten Daten	Systemabsturz	2021	Electronic	0.8	Europe	Germany	0.75	https://coverartarchive.org/release-group/0e695e56-b917-4115-aaf1-85ad697469ab/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:0ec42a88-a7c6-4198-a8b7-5022f9277e36	I Like You	Lucky Date	2015	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/0ec42a88-a7c6-4198-a8b7-5022f9277e36/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:102e0a3b-4493-386c-ac3e-13a4ee4a5cfa	Laudate Dominum / Vespers & Litanies	Mozart	1998	Classical	0.75	North America	Austria	0.75	https://coverartarchive.org/release-group/102e0a3b-4493-386c-ac3e-13a4ee4a5cfa/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:10b71c7e-9baa-46d8-801c-1afe1bf97cb6	The Best in Minimal: Update 10.0	Various Artists	2014	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/10b71c7e-9baa-46d8-801c-1afe1bf97cb6/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:10ba07a9-ddce-4ea1-8ad2-c96aad95bb97	A Date With Bombón	Bombón	2015	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/10ba07a9-ddce-4ea1-8ad2-c96aad95bb97/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:11f5961c-2a41-3f7d-8719-a5763b8842cc	Blues Consolidated	Little Junior Parker	1958	Soul	0.55	North America	United States	0.75	https://coverartarchive.org/release-group/11f5961c-2a41-3f7d-8719-a5763b8842cc/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:121a2321-a830-4031-84f6-ec6bc2b14019	Date	Kenneyon	2022	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/121a2321-a830-4031-84f6-ec6bc2b14019/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:13c5928e-b27b-4361-a786-0def3c566668	Update 1.1	Pleasure Model	2017	Electronic	0.8	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/13c5928e-b27b-4361-a786-0def3c566668/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:148ec7ad-85bb-46f3-81fc-65310c1998e7	Blind Date Party	Bill Callahan	2021	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/148ec7ad-85bb-46f3-81fc-65310c1998e7/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:14ddda5c-6f24-4656-b4bc-bcd8ca7a5d70	Late Date With Ruth Brown	Ruth Brown	1959	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/14ddda5c-6f24-4656-b4bc-bcd8ca7a5d70/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:1679d936-f5c6-4629-9751-c8a0e4545809	»Coronation« Mass / Missa Brevis »Spatzenmesse« / Exsultate, jubilate / Laudate Dominum / Ave verum	Wolfgang Amadeus Mozart	1991	Classical	0.75	North America	Austria	0.75	https://coverartarchive.org/release-group/1679d936-f5c6-4629-9751-c8a0e4545809/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:16a74594-bff8-45fc-b0c7-dbede519ce67	Ponytown Cave Update	Wandering Artist	2019	Classical	0.75	Europe	Italy	0.75	https://coverartarchive.org/release-group/16a74594-bff8-45fc-b0c7-dbede519ce67/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:1713d553-1a75-3b6d-b282-14cb6a69ed63	「はるこ☆UP DATE」SONGS BEST	桃井はるこ	2007	Pop	0.65	Asia	Japan	0.75	https://coverartarchive.org/release-group/1713d553-1a75-3b6d-b282-14cb6a69ed63/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:1789fd01-7e8e-4d6b-a85f-2a10f58bc066	Sedated in the Eighties, No. 6	Various Artists	2002	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/1789fd01-7e8e-4d6b-a85f-2a10f58bc066/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:1798fd0b-68f1-405c-b31d-8116c4965179	Speed-Date	Arab Strap	2006	Rock	0.3	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/1798fd0b-68f1-405c-b31d-8116c4965179/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:182493fc-bf75-4684-b4b6-79e2722754be	Hot Dates and Other Tales of Madness	Clyde Von Klaus	2011	Rock	0.3	Unknown	Hutto	0.75	https://coverartarchive.org/release-group/182493fc-bf75-4684-b4b6-79e2722754be/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:190fe1c9-6a16-414d-b8e6-73a618e1dc5e	Brokendate	Com Truise	2023	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/190fe1c9-6a16-414d-b8e6-73a618e1dc5e/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:196b0255-98d7-4096-b165-7a42530eefe7	Date Animals	Lesbian Wallet	2019	Rock	0.3	Unknown	Foligno	0.75	https://coverartarchive.org/release-group/196b0255-98d7-4096-b165-7a42530eefe7/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:1a727a23-ef77-49cd-ad62-749c30fed2f5	She's the One / I Wanna Be Sedated	Ramones	1978	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/1a727a23-ef77-49cd-ad62-749c30fed2f5/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:1aae789d-1256-4467-b8b8-0f096e0e7dbb	Elucidate	Olympus Lenticular	2015	Rock	0.3	Unknown	Wisconsin	0.75	https://coverartarchive.org/release-group/1aae789d-1256-4467-b8b8-0f096e0e7dbb/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:1d8fc68d-621b-38c5-bf9a-77c39c7963db	Update	Anouk	2004	Rock	0.3	Europe	Netherlands	0.75	https://coverartarchive.org/release-group/1d8fc68d-621b-38c5-bf9a-77c39c7963db/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:1dd2185c-4955-4489-a8f6-056ef83c08d8	Date With a Vampyre	The Screaming Tribesmen	1985	Rock	0.3	North America	Australia	0.75	https://coverartarchive.org/release-group/1dd2185c-4955-4489-a8f6-056ef83c08d8/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:1e0271e3-576e-43ee-b467-7a25b7d25fad	Classics Up to Date, Volume 9	James Last	1998	Classical	0.75	Europe	Germany	0.75	https://coverartarchive.org/release-group/1e0271e3-576e-43ee-b467-7a25b7d25fad/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:1e4cef55-743d-34fc-941e-ce33c3c603f7	Laudate omnes gentes	Taizé	2002	Classical	0.75	Europe	France	0.75	https://coverartarchive.org/release-group/1e4cef55-743d-34fc-941e-ce33c3c603f7/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:1f8eee68-86ec-4ee7-8606-0b0183d651da	Ponytown Beach Update	Wandering Artist	2020	Classical	0.75	Europe	Italy	0.75	https://coverartarchive.org/release-group/1f8eee68-86ec-4ee7-8606-0b0183d651da/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2071d6bd-5352-4d16-b7a3-cb821e2756a8	Exhuming Graves And Making Dates	Various Artists	2004	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/2071d6bd-5352-4d16-b7a3-cb821e2756a8/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2104e7d0-2617-4d65-9904-911ef7c15a28	Romance Date	ISOLATED INCIDENT	2020	Electronic	0.8	Unknown	Tbilisi	0.75	https://coverartarchive.org/release-group/2104e7d0-2617-4d65-9904-911ef7c15a28/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2164c1ed-d20c-4482-911d-af6622503087	Danger Date	O’Chi Brown	1983	Reggae	0.58	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/2164c1ed-d20c-4482-911d-af6622503087/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:217d6ee0-4570-32d7-9410-85b21aaf38cc	Play Date	Euge Groove	2002	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/217d6ee0-4570-32d7-9410-85b21aaf38cc/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:217fff32-cde8-40f7-859b-584462f78693	Tour (Date with a Dream)	Random	2012	Hip Hop	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/217fff32-cde8-40f7-859b-584462f78693/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:21ad75f4-6979-4d12-bc3b-4dd65b645ac0	U potrazi za novim zvukom: 1956-1984: Antologija elektroakustičke glazbe hrvatskih skladatelja	Various Artists	2016	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/21ad75f4-6979-4d12-bc3b-4dd65b645ac0/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:21afc58c-63d9-4c0e-b314-ff10e5d83031	Grand 12-Inches 18 - Updates	Ben Liebrand	2021	Electronic	0.8	Europe	Netherlands	0.75	https://coverartarchive.org/release-group/21afc58c-63d9-4c0e-b314-ff10e5d83031/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:224ba6a6-de02-317b-affc-8cfdf9d77b60	Date of Birth	Arsonists	2001	Hip Hop	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/224ba6a6-de02-317b-affc-8cfdf9d77b60/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:22d660b9-6672-4849-ac28-c6423dd9b2ea	The Manchurian Candidate: Complete Soundtrack Recording	David Amram	1997	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/22d660b9-6672-4849-ac28-c6423dd9b2ea/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:22f75c28-0cee-4a36-bc24-29c9016e9a77	2004 - 2021 Singles (updated until completion)	Waterflame	2022	Electronic	0.8	Unknown	Oslo	0.75	https://coverartarchive.org/release-group/22f75c28-0cee-4a36-bc24-29c9016e9a77/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:233fff74-42a3-4e83-b2f1-2feac5d1c07b	Blind Date	The New Barbarians	1991	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/233fff74-42a3-4e83-b2f1-2feac5d1c07b/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:23c2d38b-9c34-4fd9-9104-d8864effc4a1	Alle Soldaten woll'n nach Haus	Reinhard Mey	1990	Pop	0.65	Europe	Germany	0.75	https://coverartarchive.org/release-group/23c2d38b-9c34-4fd9-9104-d8864effc4a1/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:24175c15-7f1e-441f-87f7-ba3ac11757fd	Effigies	Conan’s First Date	2009	Rock	0.3	Unknown	Hungary	0.75	https://coverartarchive.org/release-group/24175c15-7f1e-441f-87f7-ba3ac11757fd/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:24fdeba8-4760-46bb-b366-11290e82b6b1	Krönungsmesse KV 317, Vesperae solennes de confessore KV339 (mit Laudate Dominum)	Wolfgang Amadeus Mozart	1974	Classical	0.75	North America	Austria	0.75	https://coverartarchive.org/release-group/24fdeba8-4760-46bb-b366-11290e82b6b1/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2888c48d-01f5-3a50-9372-2a9079b18853	Desire Update 2.0	Various Artists	2001	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/2888c48d-01f5-3a50-9372-2a9079b18853/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:294cd186-d11d-4fe5-b759-d4a0785fa47f	First Date	Youthology	2023	Hip Hop	0.5	Unknown	\N	0.75	https://coverartarchive.org/release-group/294cd186-d11d-4fe5-b759-d4a0785fa47f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2a1a3d6e-b431-4b29-8c4d-4237e0795fa2	Date With Music	ANIKA	1991	Electronic	0.8	Europe	Norway	0.75	https://coverartarchive.org/release-group/2a1a3d6e-b431-4b29-8c4d-4237e0795fa2/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2a998076-2e83-3420-9630-84aed9082d6f	Expiration Date EP	Blockhead	2005	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/2a998076-2e83-3420-9630-84aed9082d6f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2b156534-c270-4c5e-9d3d-025756e1cdb4	coffee date	Sugar Mittens	2021	Electronic	0.8	Unknown	Orange	0.75	https://coverartarchive.org/release-group/2b156534-c270-4c5e-9d3d-025756e1cdb4/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2b5c4393-c5dc-343c-a259-c1ffb382c9cb	Win a Date With Tad Hamilton	Various Artists	2004	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/2b5c4393-c5dc-343c-a259-c1ffb382c9cb/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2b6fb239-450a-4231-acf5-3c829bdf9de3	13 Years of Losing Money	Melvins	1994	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/2b6fb239-450a-4231-acf5-3c829bdf9de3/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2d2c6b62-0507-469e-9753-abf95ae9f6c2	Portraits	Prom Date	2014	Pop	0.65	Unknown	New Orleans	0.75	https://coverartarchive.org/release-group/2d2c6b62-0507-469e-9753-abf95ae9f6c2/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2d417748-182a-41ec-b8c1-1b21c5bc2fa6	Ponytown Fall Update	Wandering Artist	2017	Classical	0.75	Europe	Italy	0.75	https://coverartarchive.org/release-group/2d417748-182a-41ec-b8c1-1b21c5bc2fa6/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2d51ad97-a581-39eb-9e1c-f998987521c6	Updates	The American Analog Set	2002	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/2d51ad97-a581-39eb-9e1c-f998987521c6/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2db8a8e6-82c9-43a5-9514-94f5d9aad353	Consolidated City-County	SOUTH:!:AST CO ' J~sr.	2024	Electronic	0.8	Unknown	Florida	0.75	https://coverartarchive.org/release-group/2db8a8e6-82c9-43a5-9514-94f5d9aad353/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2ed263d4-05a9-3dc3-ae38-c69764290dd1	Down to Love Town / Date With the Rain	The Originals	2001	Soul	0.55	North America	United States	0.75	https://coverartarchive.org/release-group/2ed263d4-05a9-3dc3-ae38-c69764290dd1/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2eec945a-2e84-46e3-ba83-aab4ccfed6dd	Darkness Falls (2016 Update)	Eufeion	2016	Electronic	0.8	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/2eec945a-2e84-46e3-ba83-aab4ccfed6dd/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:2f478165-8aad-475f-9f6a-a7f9a202b180	Rondate	Billions of Comrades	2016	Rock	0.3	Europe	Belgium	0.75	https://coverartarchive.org/release-group/2f478165-8aad-475f-9f6a-a7f9a202b180/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:3025f5d2-eb6b-4286-ad29-3f86a09e0c16	Classics Up to Date 5	James Last	1978	Classical	0.75	Europe	Germany	0.75	https://coverartarchive.org/release-group/3025f5d2-eb6b-4286-ad29-3f86a09e0c16/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:307256f9-1e1c-4b6e-b0c4-5187051b8992	Anarchy Date	Queer Rocket	2013	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/307256f9-1e1c-4b6e-b0c4-5187051b8992/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:30840872-bd0d-442f-83aa-9b7ad4775b1c	Actresses Date Actors	Paloma	2002	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/30840872-bd0d-442f-83aa-9b7ad4775b1c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:3117e0ee-3159-3e27-9f84-d7277f8560f6	Up to Date	The Partridge Family	1971	Pop	0.65	North America	United States	0.75	https://coverartarchive.org/release-group/3117e0ee-3159-3e27-9f84-d7277f8560f6/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:32a13f79-3890-388f-94ba-1a6554b788db	Fidatevi	Ben Weasel	2002	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/32a13f79-3890-388f-94ba-1a6554b788db/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:32e02fee-eb19-4621-ba2f-fc3ac5e5b80f	A Beladen Date 4 Ever	Ion Ludwig	2023	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/32e02fee-eb19-4621-ba2f-fc3ac5e5b80f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:33ab7560-ea87-4af7-a480-5782e1c277ff	Driver (2020 Update)	Daniel Seven	2020	Electronic	0.8	Europe	Italy	0.75	https://coverartarchive.org/release-group/33ab7560-ea87-4af7-a480-5782e1c277ff/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:33fb83c1-679c-4ade-ae6e-f6592d0023ba	Inundate	Sectu	2011	Rock	0.3	Europe	Sweden	0.75	https://coverartarchive.org/release-group/33fb83c1-679c-4ade-ae6e-f6592d0023ba/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:34be1ecd-da6b-41c7-980c-bcc587a8edb8	You Have A Date With...Kill The Hippies (Demo 2)	Kill The Hippies	1994	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/34be1ecd-da6b-41c7-980c-bcc587a8edb8/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:34d357cb-1147-4a6d-a93d-dd03df58592e	Date Night	Filthy Traitors	2024	Rock	0.3	Unknown	Seattle	0.75	https://coverartarchive.org/release-group/34d357cb-1147-4a6d-a93d-dd03df58592e/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:35bbb68b-5a4b-3b1a-9cdf-b4b67d14556b	Outdated EP	Gaetano Parisio	2000	Electronic	0.8	Europe	Italy	0.75	https://coverartarchive.org/release-group/35bbb68b-5a4b-3b1a-9cdf-b4b67d14556b/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:35cba23c-6923-40c5-84ab-2f258635d9d9	DATE SIM	Dooby Douglas	2019	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/35cba23c-6923-40c5-84ab-2f258635d9d9/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:3716b1af-600a-4699-8b9d-1265d76fa766	Up to Date	Esther & Abi Ofarim	1968	Pop	0.65	Unknown	Israel	0.75	https://coverartarchive.org/release-group/3716b1af-600a-4699-8b9d-1265d76fa766/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:37a5decc-da4c-4ce9-968a-50eae5526afc	Date With Destiny	Nightmares on Wax	2003	Electronic	0.8	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/37a5decc-da4c-4ce9-968a-50eae5526afc/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:56236f0e-54ae-4a61-b62b-f57edfc807eb	Kvällens sista dans	Date	2000	Pop	0.65	Unknown	\N	0.75	https://coverartarchive.org/release-group/56236f0e-54ae-4a61-b62b-f57edfc807eb/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:382e0245-20e0-3eeb-bc6a-2e14b3e1e763	No Said Date	Masta Killa	2004	Hip Hop	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/382e0245-20e0-3eeb-bc6a-2e14b3e1e763/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:38570188-69ea-3b31-89ca-a9f9da16024c	Date With the Night	Yeah Yeah Yeahs	2003	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/38570188-69ea-3b31-89ca-a9f9da16024c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:3876a4ff-69ad-4841-881d-c22c7ab4a08a	(What a) Wonderful World / Rock It Baby (Baby We've Got a Date)	Johnny Nash	1976	Reggae	0.58	North America	United States	0.75	https://coverartarchive.org/release-group/3876a4ff-69ad-4841-881d-c22c7ab4a08a/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:38a127a9-5548-4a4f-85d7-22affeec30d9	A Monday Date: 1928	Earl Hines	1970	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/38a127a9-5548-4a4f-85d7-22affeec30d9/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:38fc3f7b-925d-45d6-a6b8-98baee2a59b0	Grand 12-Inches 12 - Updates & Upgrades	Ben Liebrand	2015	Other	0.5	Europe	Netherlands	0.75	https://coverartarchive.org/release-group/38fc3f7b-925d-45d6-a6b8-98baee2a59b0/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:390c6ba8-40c8-4975-aee3-e4d712106a26	Date at Midnight	Date at Midnight	2008	Rock	0.3	Unknown	Roma	0.75	https://coverartarchive.org/release-group/390c6ba8-40c8-4975-aee3-e4d712106a26/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:390ce0e2-fba7-422f-b0a8-16fed687c4f3	The Seventh Date of Blashyrkh	Immortal	2010	Rock	0.3	Europe	Norway	0.75	https://coverartarchive.org/release-group/390ce0e2-fba7-422f-b0a8-16fed687c4f3/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:39263473-7fc2-4ae2-b127-1f4f98a0c287	Laudate Dominum (Venetian Music by the Gabrielis and Bassano)	Choir of Magdalen College, Oxford	1978	Classical	0.75	Unknown	Oxford	0.75	https://coverartarchive.org/release-group/39263473-7fc2-4ae2-b127-1f4f98a0c287/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:3994b529-4066-46d2-b9f2-54135e1a2239	Pete's Last Date	Pete Brown	1974	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/3994b529-4066-46d2-b9f2-54135e1a2239/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:39d3ab96-d45d-3317-85a2-ff241e8ddd15	Date With Death	Badtown Boys	1991	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/39d3ab96-d45d-3317-85a2-ff241e8ddd15/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:3ad3651f-d307-4ace-8d1c-8194fb739965	Update	Model 600	2002	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/3ad3651f-d307-4ace-8d1c-8194fb739965/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:3bada09d-879b-46eb-9de2-931470eae6a8	Double Date / No Figs	Metronome All Stars	1950	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/3bada09d-879b-46eb-9de2-931470eae6a8/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:3bd48132-c4a4-3826-bae9-d1090bc65080	Requiem in D minor / Laudate Dominum	Wolfgang Amadeus Mozart	1992	Classical	0.75	North America	Austria	0.75	https://coverartarchive.org/release-group/3bd48132-c4a4-3826-bae9-d1090bc65080/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:3c3f207f-9a7d-4c84-9639-f14f7dd78a65	Deux motets: «Laudate Dominum» / «Misere mei Deus»	Nicolas Bernier	1998	Classical	0.75	Europe	France	0.75	https://coverartarchive.org/release-group/3c3f207f-9a7d-4c84-9639-f14f7dd78a65/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:3c54b756-839f-4a06-aaba-bbbc45aa03a6	Rosenmüller: Laudate Pueri, Missa Brevis	Johann Rosenmüller	1992	Classical	0.75	Europe	Germany	0.75	https://coverartarchive.org/release-group/3c54b756-839f-4a06-aaba-bbbc45aa03a6/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:3cbc6748-94b9-4601-b48b-91360e2f3830	it's a date	tenby	2021	Electronic	0.8	Unknown	London	0.75	https://coverartarchive.org/release-group/3cbc6748-94b9-4601-b48b-91360e2f3830/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:3d81636f-9b39-4ff2-bc22-112fc8d5bad4	G’d Up‐date, Vol. 1	J. Locc	2014	Hip Hop	0.5	Europe	Italy	0.75	https://coverartarchive.org/release-group/3d81636f-9b39-4ff2-bc22-112fc8d5bad4/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:3d9ab78c-9bdf-402c-aadf-d8e176996919	defedate	cat soup	2017	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/3d9ab78c-9bdf-402c-aadf-d8e176996919/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:3da2caf2-2676-4472-a61e-c422bd279656	Date Night: Chromeo Live!	Chromeo	2021	Electronic	0.8	North America	Canada	0.75	https://coverartarchive.org/release-group/3da2caf2-2676-4472-a61e-c422bd279656/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:3f4b2a75-aacc-4f6c-bcb1-9845cc0e9573	Classics Up to Date, Volume 7	James Last	1999	Classical	0.75	Europe	Germany	0.75	https://coverartarchive.org/release-group/3f4b2a75-aacc-4f6c-bcb1-9845cc0e9573/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4015371a-d253-4986-8505-7b0c88762f58	Up To Date	The Paper Orchestra	2008	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/4015371a-d253-4986-8505-7b0c88762f58/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4054695c-818f-467c-b071-247c983a548b	A Date With Dinka	Dinka	2014	Electronic	0.8	Unknown	Lucerne	0.75	https://coverartarchive.org/release-group/4054695c-818f-467c-b071-247c983a548b/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:408b2795-f0b7-4811-82ad-0e9ce629bb0f	RnR Playdate (live)	Mission Man	2014	Hip Hop	0.5	Unknown	Cincinnati	0.75	https://coverartarchive.org/release-group/408b2795-f0b7-4811-82ad-0e9ce629bb0f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:41a07d64-36a7-4559-87e3-136763b605eb	Miss Shy and Miss Rarity's Secret Dates	Mane In Green	2018	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/41a07d64-36a7-4559-87e3-136763b605eb/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:421b55b5-df85-4983-bc4a-b7dee866a87c	Update / 3 Sides	Young Fresh Fellows	1985	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/421b55b5-df85-4983-bc4a-b7dee866a87c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4262b0e3-ec70-4d71-81b9-b92e1825ed02	Grand 12-Inches 3: Updates & Upgrades	Ben Liebrand	2014	Other	0.5	Europe	Netherlands	0.75	https://coverartarchive.org/release-group/4262b0e3-ec70-4d71-81b9-b92e1825ed02/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4286864d-c888-4b39-960f-26705b8ba577	A Date With You	Grape St.	2012	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/4286864d-c888-4b39-960f-26705b8ba577/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:42bbcd19-04b3-4716-a5cb-44bc5720954d	Rascal Does Not Dream of a Longer Date	Valley Swerve	2021	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/42bbcd19-04b3-4716-a5cb-44bc5720954d/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:56b91648-8934-4174-a48f-f567713fa6bb	The Date Tape	Cookin’ Soul	2010	Hip Hop	0.5	Europe	Spain	0.75	https://coverartarchive.org/release-group/56b91648-8934-4174-a48f-f567713fa6bb/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:43253b62-bbb1-3bf6-8d31-bca4bf768955	Steady Date	Mitch Woods & His Rocket 88’s	1993	Blues	0.35	North America	United States	0.75	https://coverartarchive.org/release-group/43253b62-bbb1-3bf6-8d31-bca4bf768955/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4351acd3-e1ea-3436-97ed-ac7458a60517	Rodatempo	Teófilo Chantre	2000	Latin	0.62	Unknown	Cape Verde	0.75	https://coverartarchive.org/release-group/4351acd3-e1ea-3436-97ed-ac7458a60517/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:44f1cf3e-afea-467f-b449-bb11a502bddf	Classics Up to Date, Volume 8	James Last	1998	Classical	0.75	Europe	Germany	0.75	https://coverartarchive.org/release-group/44f1cf3e-afea-467f-b449-bb11a502bddf/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:44ffa7cb-a531-4665-a774-b4e01fbc75e5	Huayayay / Quédate un poco más	Grupo Fantasma	1986	Latin	0.62	South America	Peru	0.75	https://coverartarchive.org/release-group/44ffa7cb-a531-4665-a774-b4e01fbc75e5/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:456fc7ed-02fd-43e6-a7fa-8dfb5ebaae26	Dance Date	Wayne King And His Orchestra	1966	Pop	0.65	North America	United States	0.75	https://coverartarchive.org/release-group/456fc7ed-02fd-43e6-a7fa-8dfb5ebaae26/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:45af49e2-53d4-43ec-a222-e259b7d9e094	Don't Need Love	Lucky Date	2015	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/45af49e2-53d4-43ec-a222-e259b7d9e094/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:463dfe9f-32ff-4aca-bf71-03c174eb5f00	Just Move	Lucky Date	2014	Other	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/463dfe9f-32ff-4aca-bf71-03c174eb5f00/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:46c53924-0326-47ad-bc54-802d10161c63	The Beat 72 Lost Date	Alvin Curran	2020	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/46c53924-0326-47ad-bc54-802d10161c63/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:46d402fc-44f4-40ea-af53-2c5f1fb299ad	Dance Air Force Date 1960	Duke Ellington	1960	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/46d402fc-44f4-40ea-af53-2c5f1fb299ad/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:479e8f78-1795-4f04-9dd2-6133dfc571d2	No Date Tapes	Harry Bertoia	2021	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/479e8f78-1795-4f04-9dd2-6133dfc571d2/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4983bf42-fbc0-4de3-a4b3-90d05f8ae7f6	Great Skate Date EP	Justine Electra	2013	Pop	0.65	Unknown	Berlin	0.75	https://coverartarchive.org/release-group/4983bf42-fbc0-4de3-a4b3-90d05f8ae7f6/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4b284bb0-aa61-402d-beb6-b5a6b0bb1f2b	A Date With Death	The Panic Beats	2014	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/4b284bb0-aa61-402d-beb6-b5a6b0bb1f2b/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4c2d5375-c793-39a6-b538-500cc0007794	A Date With The Smithereens	The Smithereens	1994	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/4c2d5375-c793-39a6-b538-500cc0007794/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4c9aa070-fb61-4876-97b1-f5503a529402	Double Date	Goat	2018	Rock	0.3	Europe	Sweden	0.75	https://coverartarchive.org/release-group/4c9aa070-fb61-4876-97b1-f5503a529402/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4cf1b44e-342f-4629-b47d-a02660e4a24d	The Date	Avril	2002	Electronic	0.8	Unknown	Paris	0.75	https://coverartarchive.org/release-group/4cf1b44e-342f-4629-b47d-a02660e4a24d/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4d04504f-cf8e-3de6-97d3-acb41df26e70	Dirt Track Date	Southern Culture on the Skids	1995	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/4d04504f-cf8e-3de6-97d3-acb41df26e70/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4d0acd0d-323c-4cfb-9fb4-e12d8b6caa2e	Movie Date	Percy Faith and His Orchestra	1967	Pop	0.65	North America	United States	0.75	https://coverartarchive.org/release-group/4d0acd0d-323c-4cfb-9fb4-e12d8b6caa2e/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4d31526b-655d-38c7-acc5-48559055a4dd	A Date With Elvis	Elvis Presley	1959	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/4d31526b-655d-38c7-acc5-48559055a4dd/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4d39121f-89e7-4efc-ad5a-d15400c7614d	Easy Update's Easy Listening Lolume One	Ian Hinck	2016	Electronic	0.8	Unknown	Los Angeles	0.75	https://coverartarchive.org/release-group/4d39121f-89e7-4efc-ad5a-d15400c7614d/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4e320938-edcd-460a-b274-f23978760080	A Date With James Last	James Last	1966	Pop	0.65	Europe	Germany	0.75	https://coverartarchive.org/release-group/4e320938-edcd-460a-b274-f23978760080/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4e845f22-2072-478b-b828-e5348ab999df	Mitridate, rè di Ponto	Wolfgang Amadeus Mozart	2021	Classical	0.75	North America	Austria	0.75	https://coverartarchive.org/release-group/4e845f22-2072-478b-b828-e5348ab999df/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:4ea3b91c-c436-4834-846b-264250fb1ec5	Hakodate	Shingo Nakamura	2012	Electronic	0.8	Asia	Japan	0.75	https://coverartarchive.org/release-group/4ea3b91c-c436-4834-846b-264250fb1ec5/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:50660f29-203e-4029-ba3f-86a2aab57a6a	A Jazz Date With Chris Connor	Chris Connor	1958	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/50660f29-203e-4029-ba3f-86a2aab57a6a/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:510f2c45-30dc-445e-b689-3d60d8cfda43	First Date (Single)	Immer	2022	Rock	0.3	Europe	France	0.75	https://coverartarchive.org/release-group/510f2c45-30dc-445e-b689-3d60d8cfda43/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:51de776d-ec65-3ebf-ad87-48f45aace05d	Last Date	Floyd Cramer	1960	Pop	0.65	North America	United States	0.75	https://coverartarchive.org/release-group/51de776d-ec65-3ebf-ad87-48f45aace05d/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:544bb227-39bc-437b-b6d5-44ee828c6567	Sweet as Broken Dates: Lost Somali Tapes from the Horn of Africa	Various Artists	2017	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/544bb227-39bc-437b-b6d5-44ee828c6567/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:5455f17a-81d6-4f02-81e6-ae1e09e3e3b2	Pony Town Market Update	Wandering Artist	2021	Classical	0.75	Europe	Italy	0.75	https://coverartarchive.org/release-group/5455f17a-81d6-4f02-81e6-ae1e09e3e3b2/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:5507ba9c-f29b-440e-b1c5-39e99fde6f19	Blue Egyptian faience cat figurine dated to 1981−1802 BC	https://en.wikipedia.org/wiki/Felis_catus	2019	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/5507ba9c-f29b-440e-b1c5-39e99fde6f19/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:55ad37ef-ea77-48b3-9acf-d6ae6c3abd9d	Double Date	FTISLAND	2009	Pop	0.65	Asia	South Korea	0.75	https://coverartarchive.org/release-group/55ad37ef-ea77-48b3-9acf-d6ae6c3abd9d/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:57df7eaf-aded-41d5-b760-c5f4d3897d72	In furore, Laudate pueri e concerti sacri	Vivaldi	2006	Classical	0.75	Europe	Italy	0.75	https://coverartarchive.org/release-group/57df7eaf-aded-41d5-b760-c5f4d3897d72/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:5850a0f4-af0e-4a5b-b857-7bd1530972ce	Validated	Groupie	2018	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/5850a0f4-af0e-4a5b-b857-7bd1530972ce/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:59299526-23e6-3127-80e4-46f071fd3818	We Validate!	MJ Hibbett & The Validators	2006	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/59299526-23e6-3127-80e4-46f071fd3818/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:5a317d21-c117-4d10-ba62-6ed6949e6f98	First Date	Danko Jones	2006	Rock	0.3	North America	Canada	0.75	https://coverartarchive.org/release-group/5a317d21-c117-4d10-ba62-6ed6949e6f98/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:5a7eedd8-5615-4f25-a9e1-f950381f18cf	The Execution Mandate	Death's Eminence	2017	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/5a7eedd8-5615-4f25-a9e1-f950381f18cf/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:5b1e7f8e-6156-4438-badd-1f22c8d85364	A Date With Caterina Valente	Caterina Valente	1957	Pop	0.65	Europe	France	0.75	https://coverartarchive.org/release-group/5b1e7f8e-6156-4438-badd-1f22c8d85364/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:5b50ae88-107c-33f2-99f4-86afd4acb346	Ni prédateur ni proie	Von Magnet	2008	Electronic	0.8	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/5b50ae88-107c-33f2-99f4-86afd4acb346/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:5b8fbbb6-6fb4-4dc3-bd59-09c612252f5a	Imitate, Intimidate	Kaz Mirblouk	2016	Rock	0.3	Unknown	Los Angeles	0.75	https://coverartarchive.org/release-group/5b8fbbb6-6fb4-4dc3-bd59-09c612252f5a/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:5c016ef9-451b-4ad5-a164-87b9f80856fd	Lilas ir Innomine 2009–2020	Lilas ir Innomine	2021	Hip Hop	0.5	North America	Vilnius	0.75	https://coverartarchive.org/release-group/5c016ef9-451b-4ad5-a164-87b9f80856fd/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:5c5b34a2-58cd-43fb-91d3-4587c76783da	date course	lyrical school	2013	Hip Hop	0.5	Asia	Japan	0.75	https://coverartarchive.org/release-group/5c5b34a2-58cd-43fb-91d3-4587c76783da/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:5d75b06e-120a-4ad2-a16a-dcdd1754c329	Sedated	Hozier	2014	Rock	0.3	Europe	Ireland	0.75	https://coverartarchive.org/release-group/5d75b06e-120a-4ad2-a16a-dcdd1754c329/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:5dddd335-60b2-3cba-9aea-dc3db0d7f968	So Sedated, So Secure	Darkest Hour	2001	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/5dddd335-60b2-3cba-9aea-dc3db0d7f968/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:5f810a9b-3104-3d0d-bc11-be58f6efad86	Requiem / Laudate Dominum / Exsultate, jubilate	Mozart	1993	Classical	0.75	North America	Austria	0.75	https://coverartarchive.org/release-group/5f810a9b-3104-3d0d-bc11-be58f6efad86/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:60d100e4-3465-42b8-abd2-529813dc6d30	La Mort N'A Pas De Date Fixe	Honoré Avolonto	1981	Latin	0.62	Unknown	Benin	0.75	https://coverartarchive.org/release-group/60d100e4-3465-42b8-abd2-529813dc6d30/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:6283a7a8-53f5-4b28-8a04-4e3587623e70	ラストデイト	阿部薫	1989	Jazz	0.7	Asia	Japan	0.75	https://coverartarchive.org/release-group/6283a7a8-53f5-4b28-8a04-4e3587623e70/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:62e4ca8e-11a8-401d-a558-396272978b6f	we made løve øn the first date	cøzybøy	2017	Hip Hop	0.5	Unknown	Los Angeles	0.75	https://coverartarchive.org/release-group/62e4ca8e-11a8-401d-a558-396272978b6f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:63433288-fc71-4d8b-9499-3369ed6e58b9	Hakodate Lady	Minoru Fushimi	1983	Electronic	0.8	Asia	Japan	0.75	https://coverartarchive.org/release-group/63433288-fc71-4d8b-9499-3369ed6e58b9/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:636ebdd8-3f28-3be7-ad6e-bfe1a363de7a	Update '99	Subzonic	1999	Hip Hop	0.5	Europe	Switzerland	0.75	https://coverartarchive.org/release-group/636ebdd8-3f28-3be7-ad6e-bfe1a363de7a/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:63acd35f-bb95-4562-803d-b9fe41756987	We Used to Date	Sideluv	2023	Electronic	0.8	Europe	Germany	0.75	https://coverartarchive.org/release-group/63acd35f-bb95-4562-803d-b9fe41756987/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:63d46e6d-2a6e-471a-b503-9454186bb402	Late Date With Ruth Brown	Ruth Brown	1959	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/63d46e6d-2a6e-471a-b503-9454186bb402/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:6400029d-382d-3a1b-8821-b06b2058ed97	Date Rape Nation	Apocalypse Hoboken	1994	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/6400029d-382d-3a1b-8821-b06b2058ed97/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:649506ff-b83c-43ae-925d-fde057304151	Update, Vol. 1	Guanábanas	2016	Latin	0.62	Unknown	Puerto Rico	0.75	https://coverartarchive.org/release-group/649506ff-b83c-43ae-925d-fde057304151/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:65c54ada-4bfb-440c-9d92-fb1f9c5a4fdd	Update 4.0	Lo & Leduc	2018	Pop	0.65	Europe	Switzerland	0.75	https://coverartarchive.org/release-group/65c54ada-4bfb-440c-9d92-fb1f9c5a4fdd/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:663c7306-ff8d-4512-b4c6-21dc0af1f4fb	SoftwareUpdate1.0	BONES	2016	Hip Hop	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/663c7306-ff8d-4512-b4c6-21dc0af1f4fb/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:66790210-0219-41f1-8247-950f5a9badff	#Update	Yandel	2017	Hip Hop	0.5	Unknown	Puerto Rico	0.75	https://coverartarchive.org/release-group/66790210-0219-41f1-8247-950f5a9badff/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:67b09f45-2d16-4492-87ee-3ce8e42d7f33	They’re Only Outdates	Outdates	2010	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/67b09f45-2d16-4492-87ee-3ce8e42d7f33/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:68026dbe-d7b0-4543-9f19-03872abcf8bf	Play Date	Gaijin Smash	2020	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/68026dbe-d7b0-4543-9f19-03872abcf8bf/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:68cd3337-7363-36c1-a1ea-596433d3b69d	Cheap Date	Various Artists	2003	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/68cd3337-7363-36c1-a1ea-596433d3b69d/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:69c58e67-2e14-37c2-a8d9-7c2459e306ae	Bonavista	Kim Stockwood	1996	Rock	0.3	North America	Canada	0.75	https://coverartarchive.org/release-group/69c58e67-2e14-37c2-a8d9-7c2459e306ae/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:6a38d901-7e7a-4d80-85f8-d5e5ac83a14e	Outdated Institution Study Session	Tallahassee Community College	2024	Electronic	0.8	Unknown	Florida	0.75	https://coverartarchive.org/release-group/6a38d901-7e7a-4d80-85f8-d5e5ac83a14e/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:6aeadddb-04ed-4612-96e7-3e7ffba7f2d1	Intelligence / Liquidate	Intel Outside	1996	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/6aeadddb-04ed-4612-96e7-3e7ffba7f2d1/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:6be98ad9-65ae-325a-8440-65a3c9049e22	Consolidated	Consolidated	1989	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/6be98ad9-65ae-325a-8440-65a3c9049e22/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:6c28633f-73b7-3c0a-9433-471c6e61a84d	A Date With John Waters	Various Artists	2007	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/6c28633f-73b7-3c0a-9433-471c6e61a84d/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:6ce58e72-d4ac-3c17-9c9a-5f686c50dadf	Soldaten sind Mörder	Tod und Mordschlag	1996	Rock	0.3	Europe	Germany	0.75	https://coverartarchive.org/release-group/6ce58e72-d4ac-3c17-9c9a-5f686c50dadf/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:6d8e0292-e87b-4f6a-a763-3fb6cdb0f79b	GPS Updated Map	Suncoast Parkway	2021	Electronic	0.8	Unknown	Florida	0.75	https://coverartarchive.org/release-group/6d8e0292-e87b-4f6a-a763-3fb6cdb0f79b/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:6de3e154-0317-4ddd-9624-a39ff99b16a6	Windows (Updates Take) Forever (When It's 2007 and You're Still on XP)	Caliente Mirage	2025	Electronic	0.8	Unknown	Florida	0.75	https://coverartarchive.org/release-group/6de3e154-0317-4ddd-9624-a39ff99b16a6/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:6e058f2a-3424-41ce-a1f0-49806e2afb60	Dirty Date	Wasama Quartet	1983	Jazz	0.7	Europe	Finland	0.75	https://coverartarchive.org/release-group/6e058f2a-3424-41ce-a1f0-49806e2afb60/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:6e157fcc-ee2a-4300-a297-c57d1dc20938	Put a Date on It	Yo Gotti	2019	Pop	0.65	North America	United States	0.75	https://coverartarchive.org/release-group/6e157fcc-ee2a-4300-a297-c57d1dc20938/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:6e6d5030-7bef-418f-bede-0bbdf80ebc38	Play Date	Jeff Liberman	2011	Blues	0.35	North America	United States	0.75	https://coverartarchive.org/release-group/6e6d5030-7bef-418f-bede-0bbdf80ebc38/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:70453f22-d12c-4e59-ac02-88d87bfe7599	Dateless	Dateless	2021	Rock	0.3	Oceania	New Zealand	0.75	https://coverartarchive.org/release-group/70453f22-d12c-4e59-ac02-88d87bfe7599/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:70ad01cb-d2d0-4002-8079-d5bea8a055a8	Date Bait	Nicholas Carras	2019	Jazz	0.7	Unknown	Los Angeles	0.75	https://coverartarchive.org/release-group/70ad01cb-d2d0-4002-8079-d5bea8a055a8/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:71bcafc7-66dc-49c1-b7b1-c4d17f9f3187	Elvis in Alabama: The Last Double Date (Huntsville, September 6, 1976)	Elvis Presley	2015	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/71bcafc7-66dc-49c1-b7b1-c4d17f9f3187/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:71feccd7-b145-4a69-94ae-aec955ea9b81	Trompet kuldsetest seitsmekümnendatest	Jaan Kuman	2011	Jazz	0.7	Unknown	Estonia	0.75	https://coverartarchive.org/release-group/71feccd7-b145-4a69-94ae-aec955ea9b81/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:72428aef-8f26-48d7-b250-866a48fbc521	Sedate	Runar Blesvik	2019	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/72428aef-8f26-48d7-b250-866a48fbc521/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:7276747c-1d2c-419d-8243-d36ae397ef9c	Dance Date	The Double Dozen Orchestra	1983	Jazz	0.7	Unknown	\N	0.75	https://coverartarchive.org/release-group/7276747c-1d2c-419d-8243-d36ae397ef9c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:7287202a-283c-4559-bea2-88f0d45cb6f1	Classics Up to Date, Volume 3	James Last	1974	Jazz	0.7	Europe	Germany	0.75	https://coverartarchive.org/release-group/7287202a-283c-4559-bea2-88f0d45cb6f1/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:731ceccc-3971-3599-96a6-4a1b6116fbb0	Scabdates	The Mars Volta	2005	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/731ceccc-3971-3599-96a6-4a1b6116fbb0/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:73df05ce-e93a-4885-92e2-b5ac82979818	Party In Miami (Miami 2012 Update)	DJ Ortzy	2012	Electronic	0.8	Unknown	Buenos Aires	0.75	https://coverartarchive.org/release-group/73df05ce-e93a-4885-92e2-b5ac82979818/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:75b2b7eb-bfe8-48f5-932c-29e1f53b9a72	First Dates & 808s	LoudMouth Kang	2015	Hip Hop	0.5	Unknown	\N	0.75	https://coverartarchive.org/release-group/75b2b7eb-bfe8-48f5-932c-29e1f53b9a72/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:75c12e06-2148-4097-8a35-c898d4e87b0a	Play Date	Vanessa Perea	2019	Jazz	0.7	Unknown	\N	0.75	https://coverartarchive.org/release-group/75c12e06-2148-4097-8a35-c898d4e87b0a/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:76ad1ad4-c938-4658-97f4-dbc63db60bc6	Classics Up to Date, Volume 4	James Last Orchestra	1976	Pop	0.65	Europe	Germany	0.75	https://coverartarchive.org/release-group/76ad1ad4-c938-4658-97f4-dbc63db60bc6/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:76b1964d-3e49-4016-822b-1445b2515d10	Three Dollar Date + Microscopic Malediction	Bastard Noise	2006	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/76b1964d-3e49-4016-822b-1445b2515d10/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:76eb1d3a-4ebd-4975-aa21-6294a53978fb	Update	Recondite	2017	Electronic	0.8	Unknown	Berlin	0.75	https://coverartarchive.org/release-group/76eb1d3a-4ebd-4975-aa21-6294a53978fb/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:77fdcd59-42a6-498a-8579-40afbdac28f9	Last Date	Sólveig Matthildur	2020	Pop	0.65	Europe	Iceland	0.75	https://coverartarchive.org/release-group/77fdcd59-42a6-498a-8579-40afbdac28f9/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:787b966f-07d2-484b-b284-48fbe982c689	Greasy Exudate	Pathogenesis	2022	Rock	0.3	Unknown	Raleigh	0.75	https://coverartarchive.org/release-group/787b966f-07d2-484b-b284-48fbe982c689/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:78f61a89-345b-476f-a020-dd6d1fc7deec	The Story of My Life / Once-A-Week Date	Marty Robbins	1957	Folk	0.45	North America	United States	0.75	https://coverartarchive.org/release-group/78f61a89-345b-476f-a020-dd6d1fc7deec/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:795d4a98-8108-4421-a753-db05c3e647a8	Up-To-Date	山下洋輔トリオ	1975	Jazz	0.7	Unknown	\N	0.75	https://coverartarchive.org/release-group/795d4a98-8108-4421-a753-db05c3e647a8/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:7c0fadb2-9e09-4825-9799-e9a87aee9e60	First Date	Paul Wertico Trio	2019	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/7c0fadb2-9e09-4825-9799-e9a87aee9e60/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:7c32b750-59fd-424a-b7e1-9794fd2f0d7d	Party Date	Various Artists	2001	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/7c32b750-59fd-424a-b7e1-9794fd2f0d7d/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:7eb3a4eb-d282-4f36-a830-92b43d0336bf	Let It Stay (From the Web Series "Worst First Date")	Lucy Schwartz	2024	Pop	0.65	North America	United States	0.75	https://coverartarchive.org/release-group/7eb3a4eb-d282-4f36-a830-92b43d0336bf/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:7fb1d003-7712-4f41-98c9-f5971295153e	A Date With Della Reese at Mr. Kelly's in Chicago	Della Reese	1958	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/7fb1d003-7712-4f41-98c9-f5971295153e/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:807cb9c0-2c99-4c38-a72d-38e7d30bcbf2	Up to Date	Earl Hines	1988	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/807cb9c0-2c99-4c38-a72d-38e7d30bcbf2/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:80fe9c93-f97e-3bf2-9129-eab6f6a590a9	Digi Warfare / No Said Date	Masta Killa	2004	Hip Hop	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/80fe9c93-f97e-3bf2-9129-eab6f6a590a9/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:828225c4-1c31-442a-ba70-f3b9957177dc	Dance Parade/Your Dance Date	Harry James	2002	Pop	0.65	North America	United States	0.75	https://coverartarchive.org/release-group/828225c4-1c31-442a-ba70-f3b9957177dc/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:82e7a599-3173-466b-8c00-0de72bb8b793	7th Date	Spectrals	2010	Rock	0.3	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/82e7a599-3173-466b-8c00-0de72bb8b793/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:82f1e66f-d4f2-3881-b792-8b7dcdd2364b	Mysterious Date	Hyde Park Corner	2001	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/82f1e66f-d4f2-3881-b792-8b7dcdd2364b/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:83538444-5c77-395a-80af-b53eec888cdb	Prime Candidate for Burnout	Blenderhead	1994	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/83538444-5c77-395a-80af-b53eec888cdb/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8486472f-c1f6-4170-8a2d-8ffddcb21d41	Dream Date	Joshua Van Tassel	2013	Folk	0.45	North America	Canada	0.75	https://coverartarchive.org/release-group/8486472f-c1f6-4170-8a2d-8ffddcb21d41/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:87539a31-fd05-4df9-806c-31296eb65053	Classics Up to Date 6	James Last	1984	Pop	0.65	Europe	Germany	0.75	https://coverartarchive.org/release-group/87539a31-fd05-4df9-806c-31296eb65053/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:87bbaf89-eb3d-4b03-b434-432946f9fafa	A Boston Date	Heikki Sarmanto	2008	Jazz	0.7	Europe	Finland	0.75	https://coverartarchive.org/release-group/87bbaf89-eb3d-4b03-b434-432946f9fafa/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:881bb2f8-e28a-4aa7-9668-bab0c1929e9c	Dance Date With	Hal McIntyre And His Orchestra	1950	Jazz	0.7	Unknown	\N	0.75	https://coverartarchive.org/release-group/881bb2f8-e28a-4aa7-9668-bab0c1929e9c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:883800fd-ba10-4a89-98f1-d8fa7f13c75c	The Grim	Conan’s First Date	2014	Rock	0.3	Unknown	Hungary	0.75	https://coverartarchive.org/release-group/883800fd-ba10-4a89-98f1-d8fa7f13c75c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:885eac24-1887-4fd2-8fb9-ddc0f4e231e4	Bang Up to Date With the Popinjays	Popinjays	1990	Rock	0.3	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/885eac24-1887-4fd2-8fb9-ddc0f4e231e4/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8878e2f9-ad8c-41b5-bac0-3d95cde704bf	first date	wun two	2017	Jazz	0.7	Unknown	Furtwangen im Schwarzwald	0.75	https://coverartarchive.org/release-group/8878e2f9-ad8c-41b5-bac0-3d95cde704bf/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:88938546-dd86-4b14-86da-0924ca07b1c7	Generalissimo + Live Date!	Buddy DeFranco	2007	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/88938546-dd86-4b14-86da-0924ca07b1c7/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:893ede51-248e-30bd-a080-64b9403d8a0d	Date of Expiration	Funker Vogt	2002	Electronic	0.8	Europe	Germany	0.75	https://coverartarchive.org/release-group/893ede51-248e-30bd-a080-64b9403d8a0d/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:897a9ee7-8db2-4937-ab76-426f1abaa413	Vava Vol Eisenlager Half Truths Halbe Wahrheiten Update 2018	Vava Vol	2018	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/897a9ee7-8db2-4937-ab76-426f1abaa413/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:89ab7357-38b6-4a75-8b4e-100ee3f13952	Andate tutti affanculo	The Zen Circus	2009	Rock	0.3	Europe	Italy	0.75	https://coverartarchive.org/release-group/89ab7357-38b6-4a75-8b4e-100ee3f13952/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:89b87b3e-cdb0-46f0-ae5e-14f6f8203439	Expiration Date	Midevil	1997	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/89b87b3e-cdb0-46f0-ae5e-14f6f8203439/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8b3fa2b0-af08-43a0-9d57-1693a7c48829	Ponytown House Update	Wandering Artist	2019	Classical	0.75	Europe	Italy	0.75	https://coverartarchive.org/release-group/8b3fa2b0-af08-43a0-9d57-1693a7c48829/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8b5d6e6d-7e8d-4613-9a27-77cfd381148e	Messa di gloria / Laudate Dominum KV 339	Giacomo Puccini	1992	Classical	0.75	Europe	Italy	0.75	https://coverartarchive.org/release-group/8b5d6e6d-7e8d-4613-9a27-77cfd381148e/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8bab823d-db15-4e0f-b256-1939dba0f029	The Devil is on the Loose	Conan’s First Date	2012	Rock	0.3	Unknown	Hungary	0.75	https://coverartarchive.org/release-group/8bab823d-db15-4e0f-b256-1939dba0f029/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8c715147-d308-42e3-a036-b6c7b4f6e60d	De eerste date	B-Brave	2014	Pop	0.65	Unknown	Amsterdam	0.75	https://coverartarchive.org/release-group/8c715147-d308-42e3-a036-b6c7b4f6e60d/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8cc082aa-6f22-40fd-b12a-4456a0344ec7	Trappuppgång	Date-X	1981	Rock	0.3	Unknown	Eskilstuna	0.75	https://coverartarchive.org/release-group/8cc082aa-6f22-40fd-b12a-4456a0344ec7/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8cf497b9-3329-4683-b2f4-de3cde1205ac	Got a Date	Dionne Warwick	1983	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/8cf497b9-3329-4683-b2f4-de3cde1205ac/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8d4b3952-e827-4483-a49a-15c3ec10b165	Funerals & Court Dates	Starlito	2012	Hip Hop	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/8d4b3952-e827-4483-a49a-15c3ec10b165/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8d68e9d6-0ee9-440e-94d1-85d53e18e49d	At an Earlier Date - Rare Live	Warsaw	2011	Rock	0.3	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/8d68e9d6-0ee9-440e-94d1-85d53e18e49d/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8d8b02ae-851b-4b25-912b-557d7bddd6ab	Date With Destiny	Fresh Breezle	2019	Hip Hop	0.5	Unknown	Mufulira	0.75	https://coverartarchive.org/release-group/8d8b02ae-851b-4b25-912b-557d7bddd6ab/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8d93fd14-0b86-4ecd-8639-59a59d9537a4	A Date With Devils	The Mean Devils	2004	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/8d93fd14-0b86-4ecd-8639-59a59d9537a4/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8d9eda22-459c-4224-a00b-869b05247ed2	Manhattan Update	Warren Bernhardt	2004	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/8d9eda22-459c-4224-a00b-869b05247ed2/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8dfffb8e-b689-4bec-9c9b-efedf4ffb8af	Tate's Date	Buddy Tate and His Band	1960	Jazz	0.7	Unknown	\N	0.75	https://coverartarchive.org/release-group/8dfffb8e-b689-4bec-9c9b-efedf4ffb8af/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8e4f38a4-3f34-4767-a75e-1da47e887ac2	I Wanna Be Sedated	Ramones	1988	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/8e4f38a4-3f34-4767-a75e-1da47e887ac2/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8f20d917-bedd-45d2-8626-1f2317652354	Soldatenlieder	Gateway of the Sun	2014	Rock	0.3	South America	Peru	0.75	https://coverartarchive.org/release-group/8f20d917-bedd-45d2-8626-1f2317652354/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8f4056d9-4b7f-30e2-9346-fcf96134487b	Live Dates: Volume Two	Wishbone Ash	1980	Rock	0.3	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/8f4056d9-4b7f-30e2-9346-fcf96134487b/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8f446260-712c-407f-8721-4b35b4d8797c	Quédate con la copla	Carlos Cano	1987	Latin	0.62	Europe	Spain	0.75	https://coverartarchive.org/release-group/8f446260-712c-407f-8721-4b35b4d8797c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8f6cbd45-a3aa-46e9-bec3-954664117c13	Dangers of Love	Blind Date	2021	Rock	0.3	Unknown	Bergen	0.75	https://coverartarchive.org/release-group/8f6cbd45-a3aa-46e9-bec3-954664117c13/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8f7b61df-dd90-4ab6-acb1-fdc5eb041cba	Late Date (A Tribute to Lars Gullin)	Bernt Rosengren	1994	Jazz	0.7	Europe	Sweden	0.75	https://coverartarchive.org/release-group/8f7b61df-dd90-4ab6-acb1-fdc5eb041cba/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8fb33009-ef0b-48e6-9f3f-f53a6f3758a9	Firebird	Lucky Date	2015	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/8fb33009-ef0b-48e6-9f3f-f53a6f3758a9/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:8fd42f9c-2d3d-4b44-acb2-ca4361b7e06b	First Date	Matija Lazic	2021	Hip Hop	0.5	Unknown	\N	0.75	https://coverartarchive.org/release-group/8fd42f9c-2d3d-4b44-acb2-ca4361b7e06b/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:903b5812-2ea5-4853-906b-981019c222e5	Mitridate	Mozart	1999	Classical	0.75	North America	Austria	0.75	https://coverartarchive.org/release-group/903b5812-2ea5-4853-906b-981019c222e5/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:91f2db15-41d7-49ca-b11f-5f9a80da3ff1	Mysterious Date	Dynamic Rockers	2004	Electronic	0.8	Unknown	Paris	0.75	https://coverartarchive.org/release-group/91f2db15-41d7-49ca-b11f-5f9a80da3ff1/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:92093263-48b6-43ff-b209-e821318656fd	Date at the Payphone	Red 40	1995	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/92093263-48b6-43ff-b209-e821318656fd/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:93c033dd-8940-4532-bc5b-18b03c566ffd	[date%re:draft]	emily’s ipod touch	2019	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/93c033dd-8940-4532-bc5b-18b03c566ffd/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:94d03f11-f756-35eb-bf5a-f096f9a85e18	Dateless Dudes' Club	Hard‐Ons	1992	Rock	0.3	North America	Australia	0.75	https://coverartarchive.org/release-group/94d03f11-f756-35eb-bf5a-f096f9a85e18/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:94debd95-02b8-43c6-8e88-fcb24993f73f	Our Future / The Date of Hate	Sindicato Vertical	2021	Rock	0.3	Europe	Spain	0.75	https://coverartarchive.org/release-group/94debd95-02b8-43c6-8e88-fcb24993f73f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:94ff625c-8e72-438c-88b7-abc674109659	My Dream Date With Boyd Rice	Various Artists	1987	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/94ff625c-8e72-438c-88b7-abc674109659/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9656a962-772d-4dec-887d-204328ec9f2f	Save the Date	LaFrange	2018	Folk	0.45	Unknown	\N	0.75	https://coverartarchive.org/release-group/9656a962-772d-4dec-887d-204328ec9f2f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9663905d-b517-47f1-85d3-4e99ffa95208	ⓛⓐⓢⓣ ⓓⓐⓣⓔ	lucid beach85'	2016	Electronic	0.8	Unknown	Paris	0.75	https://coverartarchive.org/release-group/9663905d-b517-47f1-85d3-4e99ffa95208/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9673cff5-b633-4f38-bf4a-024028a7929a	The Mancunian Candidate	Thunder	2013	Rock	0.3	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/9673cff5-b633-4f38-bf4a-024028a7929a/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:968a971d-231c-4215-b495-c566fceb55fa	Johnny Hoes presenteert: Meisjes en soldaten	Johnny Hoes	1963	Folk	0.45	Europe	Netherlands	0.75	https://coverartarchive.org/release-group/968a971d-231c-4215-b495-c566fceb55fa/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:96d9f4bf-6826-41b2-8961-eb45a0ac9386	Names, Dates and Places	Campsite	2005	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/96d9f4bf-6826-41b2-8961-eb45a0ac9386/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9731a17f-a964-324a-948c-89af274d9a59	A Date With Elvis	The Cramps	1986	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/9731a17f-a964-324a-948c-89af274d9a59/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:973b9608-e0db-3d97-990d-3fff69203914	Hip Date	Tomas Andersson	2005	Electronic	0.8	Europe	Sweden	0.75	https://coverartarchive.org/release-group/973b9608-e0db-3d97-990d-3fff69203914/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9752d2cd-21b4-4ba4-8524-c7c19536c98f	DATE	岡村靖幸	1988	Electronic	0.8	Asia	Japan	0.75	https://coverartarchive.org/release-group/9752d2cd-21b4-4ba4-8524-c7c19536c98f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:977ff3a9-7715-4198-b9be-31c39bfa068c	London Date	Harry Allen Quartet	2016	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/977ff3a9-7715-4198-b9be-31c39bfa068c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9851e696-7241-4896-b24d-bd535d0149d2	Classics Up to Date, Volume 2	James Last	1969	Electronic	0.8	Europe	Germany	0.75	https://coverartarchive.org/release-group/9851e696-7241-4896-b24d-bd535d0149d2/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:987932d6-f310-4ce9-a77c-e6c70e9a508c	Date Digger	The Inseminoids	2016	Rock	0.3	Unknown	Gothenburg	0.75	https://coverartarchive.org/release-group/987932d6-f310-4ce9-a77c-e6c70e9a508c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9927bb27-bbfc-4d4c-8d9f-ffbf246930fe	Ponytown Xmas Update	Wandering Artist	2017	Classical	0.75	Europe	Italy	0.75	https://coverartarchive.org/release-group/9927bb27-bbfc-4d4c-8d9f-ffbf246930fe/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:99517800-d357-403b-a2a3-37f94e281e22	Meisjes en soldaten potpourri van 28 bekende soldatenliedjes	Various Artists	1974	Folk	0.45	Unknown	\N	0.75	https://coverartarchive.org/release-group/99517800-d357-403b-a2a3-37f94e281e22/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9a03eabf-e158-4df6-b101-d6655fa089a4	Disguised to Sedate the Machines	Eats Batteries	2018	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/9a03eabf-e158-4df6-b101-d6655fa089a4/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9a8d84eb-d8db-3a94-a8ec-af109f1c2a0e	It’s Everly Time / A Date With The Everly Brothers	The Everly Brothers	2001	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/9a8d84eb-d8db-3a94-a8ec-af109f1c2a0e/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9b383d8f-83b3-4594-81b2-cdbcd3c50448	Dilapidated Psyche	Incremation	2022	Rock	0.3	Asia	Indonesia	0.75	https://coverartarchive.org/release-group/9b383d8f-83b3-4594-81b2-cdbcd3c50448/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9cbbfc81-a4c9-424d-91da-bd08bd3c767b	De la lume adunate si iarasi la lume date - Unplugged 2007	Anton Pann	2012	Jazz	0.7	Unknown	Romania	0.75	https://coverartarchive.org/release-group/9cbbfc81-a4c9-424d-91da-bd08bd3c767b/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9cdb60e8-13b6-4e4a-8e18-db728cebcbb1	Le Choix dans la date	Vîrus	2011	Hip Hop	0.5	Europe	France	0.75	https://coverartarchive.org/release-group/9cdb60e8-13b6-4e4a-8e18-db728cebcbb1/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9d2bb0d8-c1c5-3b9a-88a1-3c474cb19f40	Too Young to Date	D-Day	1979	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/9d2bb0d8-c1c5-3b9a-88a1-3c474cb19f40/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9d37a5bf-1741-4916-85b7-912df31f2e0f	ANTIHEROoO (Kituneya039 2023 update)	Kituneya039	2023	Electronic	0.8	Unknown	Hokkaido	0.75	https://coverartarchive.org/release-group/9d37a5bf-1741-4916-85b7-912df31f2e0f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9d9dc8f5-6eff-48ad-86c8-8a8336d428d0	Song for the DATE	真野恵里菜	2012	Pop	0.65	Asia	Japan	0.75	https://coverartarchive.org/release-group/9d9dc8f5-6eff-48ad-86c8-8a8336d428d0/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9e2e77c7-b343-3807-bbcd-a3a44929fc00	And That Reminds Me / A Date With Della Reese	Della Reese	1999	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/9e2e77c7-b343-3807-bbcd-a3a44929fc00/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9f2b27d4-6484-31e4-a5fe-79823f37bfea	Live Dates	Wishbone Ash	1973	Rock	0.3	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/9f2b27d4-6484-31e4-a5fe-79823f37bfea/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:9f842597-9e36-43e1-bfb2-e5359e038ac3	I Can’t Stop Loving You (Lost Her on Our Last Date)	Conway Twitty	1972	Folk	0.45	North America	United States	0.75	https://coverartarchive.org/release-group/9f842597-9e36-43e1-bfb2-e5359e038ac3/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:a0408e37-f9a4-3b54-bb7f-d33cdfe43317	Never Kill the Boy on the First Date	Waterdown	2001	Rock	0.3	Europe	Germany	0.75	https://coverartarchive.org/release-group/a0408e37-f9a4-3b54-bb7f-d33cdfe43317/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:a090c799-b1d0-4100-868d-36b339633a62	Our Candidate	The World/Inferno Friendship Society	1996	Rock	0.3	Unknown	Brooklyn	0.75	https://coverartarchive.org/release-group/a090c799-b1d0-4100-868d-36b339633a62/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:a180ffc3-d418-4c38-bfbd-0086b881a496	Consolidate	Folly Tree	2017	Rock	0.3	Unknown	Tel Aviv	0.75	https://coverartarchive.org/release-group/a180ffc3-d418-4c38-bfbd-0086b881a496/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:a685b1da-e11d-48c1-b6b1-d3e2b65ebbf2	Ponytown Halloween Update	Wandering Artist	2018	Classical	0.75	Europe	Italy	0.75	https://coverartarchive.org/release-group/a685b1da-e11d-48c1-b6b1-d3e2b65ebbf2/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:a68d5c27-ab4a-4f71-b5ab-e64e80d35111	Missa S. Emidio / Salve Regina in F minor / Manca la guida al piè / Laudate pueri Dominum	Pergolesi	2010	Classical	0.75	Europe	Italy	0.75	https://coverartarchive.org/release-group/a68d5c27-ab4a-4f71-b5ab-e64e80d35111/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:a723c02e-c3a1-4b1b-a3ae-ace201ecdc30	The days of dreams and tears.	Date of Birth	1987	Electronic	0.8	Asia	Japan	0.75	https://coverartarchive.org/release-group/a723c02e-c3a1-4b1b-a3ae-ace201ecdc30/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:a8470440-ea51-4f4e-b7d7-0fef6d5e4d34	Update Your Brain	The Tuts	2016	Rock	0.3	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/a8470440-ea51-4f4e-b7d7-0fef6d5e4d34/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:a8c64483-880c-3651-898c-42683f7459b7	First Date	Villeneuve	2005	Electronic	0.8	Europe	France	0.75	https://coverartarchive.org/release-group/a8c64483-880c-3651-898c-42683f7459b7/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:a9431795-e4d9-473d-a52e-ea2be1711402	Street Date Tuesday	The Magnolias	1996	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/a9431795-e4d9-473d-a52e-ea2be1711402/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:a9a25380-2868-4ba6-b30c-c8fd6d540dd8	Laudate Dominum	Pēteris Vasks	2017	Classical	0.75	Unknown	Latvia	0.75	https://coverartarchive.org/release-group/a9a25380-2868-4ba6-b30c-c8fd6d540dd8/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:a9a27b2a-fe3d-4e86-a501-119769b39cc8	Blues for the Date	Jazz Orchestra of the Concertgebouw	2010	Jazz	0.7	Europe	Netherlands	0.75	https://coverartarchive.org/release-group/a9a27b2a-fe3d-4e86-a501-119769b39cc8/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:a9b3ed1c-e9be-41a2-b73e-8fb676f7b6f0	The Vanguard Date	Steve Kuhn	2013	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/a9b3ed1c-e9be-41a2-b73e-8fb676f7b6f0/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:aa81b55b-0f7b-4e66-96df-c2da1485b804	The End	Lucky Date	2015	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/aa81b55b-0f7b-4e66-96df-c2da1485b804/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:aa9ff7ed-5157-4cc2-8400-757725be0706	Masquerade	A Date With Disaster	2014	Rock	0.3	Unknown	Stockholms län	0.75	https://coverartarchive.org/release-group/aa9ff7ed-5157-4cc2-8400-757725be0706/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:ab8ae845-f6d8-4312-baf7-053e9831fc36	Baby Please Set a Date	Elmore James Jr. and the Broomdusters	2010	Blues	0.35	North America	United States	0.75	https://coverartarchive.org/release-group/ab8ae845-f6d8-4312-baf7-053e9831fc36/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:ac1e2205-a5e4-3475-90eb-b98fe35e569f	New York Date	Debbie Cameron	1999	Jazz	0.7	Europe	Denmark	0.75	https://coverartarchive.org/release-group/ac1e2205-a5e4-3475-90eb-b98fe35e569f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:ad25d3f1-dd60-4697-b022-976a54e86f2f	Lieder und Gesänge / Soldatenlied / Jugendlieder	Schumann	2022	Classical	0.75	Europe	Germany	0.75	https://coverartarchive.org/release-group/ad25d3f1-dd60-4697-b022-976a54e86f2f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:adf619a4-37a2-45f0-8769-43595ebeae3d	Undateable	Sketch A Peaze	2018	Hip Hop	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/adf619a4-37a2-45f0-8769-43595ebeae3d/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:ae6f86e0-2402-4152-8fad-fc4041344ca0	Playdate	Norah Jones	2020	Pop	0.65	North America	United States	0.75	https://coverartarchive.org/release-group/ae6f86e0-2402-4152-8fad-fc4041344ca0/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:af10e9fe-9083-4de8-8510-b724987fe4b0	I Dated a Witch	Harry and the Houdinis	2019	Rock	0.3	Unknown	Elgin	0.75	https://coverartarchive.org/release-group/af10e9fe-9083-4de8-8510-b724987fe4b0/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:af27f9ca-2435-45d0-a5cd-5a9c39c2e901	Corrupted Update (At Least It Wasn't Delayed)	Love Ranger	2025	Electronic	0.8	Unknown	New Port Richey	0.75	https://coverartarchive.org/release-group/af27f9ca-2435-45d0-a5cd-5a9c39c2e901/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:afa64250-c0ab-4e9d-b110-5cc51709d9ce	Desnúdate (remix)	Lenuel	2018	Latin	0.62	Unknown	\N	0.75	https://coverartarchive.org/release-group/afa64250-c0ab-4e9d-b110-5cc51709d9ce/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:b020c266-b4c3-48c1-a33b-2c103f52972d	I Don't Care If You Updated Your Terms of Service, GameSpot.com (I'm Still Doing Whatever the Fuck I Want on Your Website & That Includes Lewd ASCII of Licensed Characters)	GameFAQs Moderator	2023	Electronic	0.8	Unknown	Florida	0.75	https://coverartarchive.org/release-group/b020c266-b4c3-48c1-a33b-2c103f52972d/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:b08e8e25-edfc-4f57-af19-c5a1830969df	The Outdated EP	The Bottom Line	2011	Rock	0.3	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/b08e8e25-edfc-4f57-af19-c5a1830969df/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:b140bde6-be47-4f2d-aebb-805449bab457	No Expiration Date	Artifacts	2022	Hip Hop	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/b140bde6-be47-4f2d-aebb-805449bab457/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:b25111a8-83b9-486e-ad06-b5485ab9cd60	Outdated	Alex Key	2024	Folk	0.45	Unknown	\N	0.75	https://coverartarchive.org/release-group/b25111a8-83b9-486e-ad06-b5485ab9cd60/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:b34668cd-f123-470d-aa4d-539b726213e2	Update 2.1 EP	Pleasure Model	2020	Electronic	0.8	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/b34668cd-f123-470d-aa4d-539b726213e2/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:b4425839-f71e-4707-be97-08ee2be290ef	Grand Predateur	Grand Prédateur	2010	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/b4425839-f71e-4707-be97-08ee2be290ef/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:b63574b1-4610-385f-850c-8513a8bbbf90	The Wedding Date	Blake Neely	2005	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/b63574b1-4610-385f-850c-8513a8bbbf90/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:b6baf99f-0da7-4fc8-981d-eae6923bb7bd	Intimidated	KAYTRANADA	2021	Electronic	0.8	North America	Canada	0.75	https://coverartarchive.org/release-group/b6baf99f-0da7-4fc8-981d-eae6923bb7bd/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:b8e4e309-4cce-467d-b8ba-01a647e6f2c3	Laudate!	Vivaldi	2016	Classical	0.75	Europe	Italy	0.75	https://coverartarchive.org/release-group/b8e4e309-4cce-467d-b8ba-01a647e6f2c3/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:b97349ab-4f42-4ca4-94f1-920aaa4586d9	1st Date	TonybtM	2020	Hip Hop	0.5	Unknown	\N	0.75	https://coverartarchive.org/release-group/b97349ab-4f42-4ca4-94f1-920aaa4586d9/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:bb744e8c-ac60-3906-9bc0-d3b2d2ab242a	Up Date: Live	Supercharge	1988	Rock	0.3	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/bb744e8c-ac60-3906-9bc0-d3b2d2ab242a/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:bc163c8f-fb97-44d3-a925-d8c95670db57	Out of Date	Mario Schiano	1983	Jazz	0.7	Europe	Italy	0.75	https://coverartarchive.org/release-group/bc163c8f-fb97-44d3-a925-d8c95670db57/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:bdabe59a-3ba8-4d8d-b58b-05aa9554b2b6	Nervous Dater	Nervous Dater	2015	Rock	0.3	Unknown	New York	0.75	https://coverartarchive.org/release-group/bdabe59a-3ba8-4d8d-b58b-05aa9554b2b6/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:be69d87f-2ca0-4e2c-8197-06c3e776ff59	X Predates Y (single)	Being a Tiger	2016	Rock	0.3	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/be69d87f-2ca0-4e2c-8197-06c3e776ff59/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:bf2a6a43-f61c-4ae9-aa86-454781576b2e	Blind Date	Never Really Knew	2017	Rock	0.3	Unknown	New York	0.75	https://coverartarchive.org/release-group/bf2a6a43-f61c-4ae9-aa86-454781576b2e/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:bfa104e3-0dab-496b-a878-287e7195bfcd	Classics Up to Date, Vol. 2	James Last Orchestra	1984	Electronic	0.8	Europe	Germany	0.75	https://coverartarchive.org/release-group/bfa104e3-0dab-496b-a878-287e7195bfcd/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c0a11da5-b916-4f5b-b1c8-ca20b218bf7a	Stay With Me	Date Work	2015	Electronic	0.8	Unknown	Philadelphia	0.75	https://coverartarchive.org/release-group/c0a11da5-b916-4f5b-b1c8-ca20b218bf7a/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c16a20b0-7821-44d1-8dc1-adb5c5bac5e3	blind date	Luxury Elite	2013	Rock	0.3	Unknown	Kentucky	0.75	https://coverartarchive.org/release-group/c16a20b0-7821-44d1-8dc1-adb5c5bac5e3/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c193ec96-6800-4f1e-ab82-144418f3d81c	Delayed Update (At Least It Wasn't Corrupted)	Love Ranger	2025	Electronic	0.8	Unknown	New Port Richey	0.75	https://coverartarchive.org/release-group/c193ec96-6800-4f1e-ab82-144418f3d81c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c1f241c8-7d8b-4a7d-8a4b-548f6f1ecbbd	Date Night	Rita Wilson	2019	Pop	0.65	North America	United States	0.75	https://coverartarchive.org/release-group/c1f241c8-7d8b-4a7d-8a4b-548f6f1ecbbd/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c288a37b-7bc1-3850-951a-76979852a07f	Shopping Bags (She Got From You)	De La Soul	2004	Hip Hop	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/c288a37b-7bc1-3850-951a-76979852a07f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c2d75ad8-0221-35c3-943f-5c373d2e37fa	Date Movie	Various Artists	2006	Other	0.5	Unknown	\N	0.75	https://coverartarchive.org/release-group/c2d75ad8-0221-35c3-943f-5c373d2e37fa/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c3050730-8718-3409-a604-2d2e940d6f58	Date With a Dream	Malene Mortensen	2005	Jazz	0.7	Europe	Denmark	0.75	https://coverartarchive.org/release-group/c3050730-8718-3409-a604-2d2e940d6f58/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c52eb596-024d-37e3-859c-2555731410fd	Updated Software V. 2.5	Insight	2002	Hip Hop	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/c52eb596-024d-37e3-859c-2555731410fd/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c54570eb-0320-44bf-aa58-bb7089c2053f	A Gene Vincent Record Date	Gene Vincent With the Blue Caps	1958	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/c54570eb-0320-44bf-aa58-bb7089c2053f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c55460ef-bad5-4c76-9651-51ffadc2b47b	Perky Macabre / Purulent Exudate	Perky Macabre	2023	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/c55460ef-bad5-4c76-9651-51ffadc2b47b/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c5664ecb-1a1f-38f2-bb0b-3d6977f3bf6c	Sedated in the Eighties, No. 2	Various Artists	1994	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/c5664ecb-1a1f-38f2-bb0b-3d6977f3bf6c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c647e790-3246-492e-b81b-b2ef3c385430	Make A Baby (datewithdeath remix edit) (2015)	DJ Eris Tsubasa	2020	Electronic	0.8	Europe	Poland	0.75	https://coverartarchive.org/release-group/c647e790-3246-492e-b81b-b2ef3c385430/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c75aac24-7aaf-4522-b909-b24db5b8d484	A Date With 88	Various Artists	1988	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/c75aac24-7aaf-4522-b909-b24db5b8d484/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c7c34d44-a678-4381-96d3-e9fd6a852ea2	First Date	Trio Peter Beets	1996	Jazz	0.7	Europe	Netherlands	0.75	https://coverartarchive.org/release-group/c7c34d44-a678-4381-96d3-e9fd6a852ea2/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c7cea0c3-d848-4e15-aa38-170d61355064	Stabat Mater- Laudate Pueri	Giovanni Battista Pergolesi	2012	Classical	0.75	Europe	Italy	0.75	https://coverartarchive.org/release-group/c7cea0c3-d848-4e15-aa38-170d61355064/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c7e37a3f-04e5-44a6-a757-565f1a852c2b	Toca’s Miracle (2012 update) (remixes)	Fragma	2000	Electronic	0.8	Europe	Germany	0.75	https://coverartarchive.org/release-group/c7e37a3f-04e5-44a6-a757-565f1a852c2b/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c81775fe-0d1e-4cac-a5fe-b2d8efd13971	Dare Me / Oxidate	Memtrix	2018	Electronic	0.8	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/c81775fe-0d1e-4cac-a5fe-b2d8efd13971/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:c81ead32-4a97-4f03-92dd-5716d3f911f0	At the Date of This Writing (Vol. 1)	J‐Live	2021	Hip Hop	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/c81ead32-4a97-4f03-92dd-5716d3f911f0/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:ca813ed8-b630-46ac-8cd5-8e9fb3674acc	Date Rape	Sublime	1991	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/ca813ed8-b630-46ac-8cd5-8e9fb3674acc/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:cb1491a1-a186-3e4d-96f7-637ab1cfcecd	To Date	PJ Harvey	2000	Rock	0.3	Europe	England	0.75	https://coverartarchive.org/release-group/cb1491a1-a186-3e4d-96f7-637ab1cfcecd/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:cd6cb637-981e-4f71-96b1-d0c7b2b3dd19	Complete Mozart Edition, Volume 29: Mitridate	Wolfgang Amadeus Mozart	1991	Classical	0.75	North America	Austria	0.75	https://coverartarchive.org/release-group/cd6cb637-981e-4f71-96b1-d0c7b2b3dd19/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:ce6c0369-1daf-4e52-b143-f987a578cab6	Expiration Date	idan altman	2017	Electronic	0.8	Europe	Netherlands	0.75	https://coverartarchive.org/release-group/ce6c0369-1daf-4e52-b143-f987a578cab6/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:cf0544c7-d342-4283-8e9e-af66e3bc225a	We Always Come Back Home	Date My Recovery	2014	Electronic	0.8	Unknown	Tyumen	0.75	https://coverartarchive.org/release-group/cf0544c7-d342-4283-8e9e-af66e3bc225a/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:cf533f4d-7db5-43e7-ab11-f19c41dc937c	Space Date	Adam Beyer	2018	Electronic	0.8	Europe	Sweden	0.75	https://coverartarchive.org/release-group/cf533f4d-7db5-43e7-ab11-f19c41dc937c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:cf66f31e-027f-474c-a233-be9d3c1a3e88	Under The Stars (2012 Update)	Sy	2012	Electronic	0.8	Europe	United Kingdom	0.75	https://coverartarchive.org/release-group/cf66f31e-027f-474c-a233-be9d3c1a3e88/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:cfc95062-39bb-400f-81f1-2e00ed840771	Static / Release Date	Kool Keith	1998	Hip Hop	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/cfc95062-39bb-400f-81f1-2e00ed840771/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d0afa4f3-602c-3a75-a1e9-769e46cd9812	Black Date	The Voluptuous Horror of Karen Black	1998	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/d0afa4f3-602c-3a75-a1e9-769e46cd9812/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d19c9d9f-6c54-4372-8830-9e79074f72f6	Songs to Fall and Forget	Date at Midnight	2016	Rock	0.3	Unknown	Roma	0.75	https://coverartarchive.org/release-group/d19c9d9f-6c54-4372-8830-9e79074f72f6/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d1aee00e-ce2d-4584-8ea1-f83b67caf55a	Remain Sedate	Rorschach	1990	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/d1aee00e-ce2d-4584-8ea1-f83b67caf55a/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d2069b2c-8676-48f8-9b1d-9917cce8e8a4	The Dragon Exists	Conan’s First Date	2015	Rock	0.3	Unknown	Hungary	0.75	https://coverartarchive.org/release-group/d2069b2c-8676-48f8-9b1d-9917cce8e8a4/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d27f0e3e-ab2d-4fae-ba75-e6391214e751	Mayday	Dannic	2015	Other	0.5	Europe	Netherlands	0.75	https://coverartarchive.org/release-group/d27f0e3e-ab2d-4fae-ba75-e6391214e751/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d2bd27db-ae65-49cf-95aa-b93e67083087	Clock Out	Prom Date	2010	Electronic	0.8	Unknown	New Orleans	0.75	https://coverartarchive.org/release-group/d2bd27db-ae65-49cf-95aa-b93e67083087/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d35bc9ba-4c33-426e-8348-baf862009793	Meisjes en soldaten: 28 soldatenliedjes	Various Artists	1977	Folk	0.45	Unknown	\N	0.75	https://coverartarchive.org/release-group/d35bc9ba-4c33-426e-8348-baf862009793/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d35d402f-34fa-3512-9b84-ea86492d3b20	Searchin' For My Rizla 2004 Updates	Ratpack	2004	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/d35d402f-34fa-3512-9b84-ea86492d3b20/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d4723d5b-f72b-4c53-9e1c-7b4be40aa1e0	Veyron (Night version)	Lucky Date	2011	Other	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/d4723d5b-f72b-4c53-9e1c-7b4be40aa1e0/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d4a8b020-ee3b-30be-9013-cac3c7273fc5	Release Date	Waltari	2007	Rock	0.3	Europe	Finland	0.75	https://coverartarchive.org/release-group/d4a8b020-ee3b-30be-9013-cac3c7273fc5/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d5af1a80-6463-4a98-951f-e6257e202fc3	Date-X	Date-X	1981	Rock	0.3	Unknown	Eskilstuna	0.75	https://coverartarchive.org/release-group/d5af1a80-6463-4a98-951f-e6257e202fc3/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d5d84ec5-c85d-428b-ba0f-1d46f2f91c30	Update	Sad	2004	Hip Hop	0.5	Europe	Switzerland	0.75	https://coverartarchive.org/release-group/d5d84ec5-c85d-428b-ba0f-1d46f2f91c30/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d64f189e-cb3e-4356-a0d5-4b3890e68232	SPEED DATE	Haiyti	2021	Hip Hop	0.5	Europe	Germany	0.75	https://coverartarchive.org/release-group/d64f189e-cb3e-4356-a0d5-4b3890e68232/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d71a97db-5ded-40ce-8eec-5673ed849e53	7bit date: robot love	beek	2012	Electronic	0.8	Unknown	California	0.75	https://coverartarchive.org/release-group/d71a97db-5ded-40ce-8eec-5673ed849e53/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d729abf3-677e-4643-ba44-7cbf917afd36	Portraits	Double Date With Death	2023	Rock	0.3	Unknown	Montréal	0.75	https://coverartarchive.org/release-group/d729abf3-677e-4643-ba44-7cbf917afd36/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d855545e-51d1-4c70-bdb2-c6d5890c3e43	Party Dates	The Resignators	2017	Rock	0.3	Unknown	Melbourne	0.75	https://coverartarchive.org/release-group/d855545e-51d1-4c70-bdb2-c6d5890c3e43/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d969e516-6d17-4676-9e30-e761335791f8	A Rockin’ Date With South Louisiana Stars	Various Artists	1970	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/d969e516-6d17-4676-9e30-e761335791f8/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:d9ad01bc-d07b-4d10-991c-81b170958d70	Musical From Chaos	DATE COURSE PENTAGON ROYAL GARDEN	2003	Jazz	0.7	Asia	Japan	0.75	https://coverartarchive.org/release-group/d9ad01bc-d07b-4d10-991c-81b170958d70/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:da6d5d52-765b-479a-bf8b-cbd19ff9f792	Candidate Waltz	Centro-Matic	2011	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/da6d5d52-765b-479a-bf8b-cbd19ff9f792/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:dad7ae2c-6fcc-49bd-85c8-d58f20a6b911	Mind Control	Date of Birth	1990	Rock	0.3	Asia	Japan	0.75	https://coverartarchive.org/release-group/dad7ae2c-6fcc-49bd-85c8-d58f20a6b911/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:db186ac4-fa8d-381e-999f-5261766237ea	A Date With Daylight	The Stranger's Six	2007	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/db186ac4-fa8d-381e-999f-5261766237ea/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:dbdad990-6f82-44ed-b2a8-cf2b3fde73ce	Jailbreak	Conan’s First Date	2011	Rock	0.3	Unknown	Hungary	0.75	https://coverartarchive.org/release-group/dbdad990-6f82-44ed-b2a8-cf2b3fde73ce/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:dbf936cd-c118-4e6f-9121-4676cb2b9d8f	Girl I Wanna Date	DJ Gollum	2020	Electronic	0.8	Europe	Germany	0.75	https://coverartarchive.org/release-group/dbf936cd-c118-4e6f-9121-4676cb2b9d8f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:dc5e4de5-d310-49a4-8ecc-b74cc6bc55e5	Date of Birth	Date of Birth	1992	Electronic	0.8	Asia	Japan	0.75	https://coverartarchive.org/release-group/dc5e4de5-d310-49a4-8ecc-b74cc6bc55e5/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:dca496bb-0972-43ae-b996-8e36ac7338b1	Classics Up to Date	James Last	1966	Classical	0.75	Europe	Germany	0.75	https://coverartarchive.org/release-group/dca496bb-0972-43ae-b996-8e36ac7338b1/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:de3b5200-4bbd-4172-9427-895fd855a9a7	1988‐05‐03: Shoreline Amphitheatre, Mountain View, CA, USA	Bruce Springsteen	1991	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/de3b5200-4bbd-4172-9427-895fd855a9a7/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:de947897-a8b7-432a-a8ca-939af01d40d8	Brinnande liv	Date-X	1982	Rock	0.3	Unknown	Eskilstuna	0.75	https://coverartarchive.org/release-group/de947897-a8b7-432a-a8ca-939af01d40d8/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:decdf494-bab5-474e-b0da-070dc352630e	Sedated	Porridge Radio	2013	Rock	0.3	Unknown	Brighton	0.75	https://coverartarchive.org/release-group/decdf494-bab5-474e-b0da-070dc352630e/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:df81266c-72f2-392c-b7fe-52d28f8e1bc9	Last Date	Emmylou Harris	1982	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/df81266c-72f2-392c-b7fe-52d28f8e1bc9/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:e1723475-f5c5-482c-898e-f5163bbc8b0e	Shopping Date	Strawberry Station	2025	Electronic	0.8	Unknown	Castle Donington	0.75	https://coverartarchive.org/release-group/e1723475-f5c5-482c-898e-f5163bbc8b0e/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:e3346b88-2b75-421a-b348-78460a975bf2	Ponytown Island Update	Wandering Artist	2019	Classical	0.75	Europe	Italy	0.75	https://coverartarchive.org/release-group/e3346b88-2b75-421a-b348-78460a975bf2/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:e41d8be2-8a9f-46d2-a5c8-4b6a17f8d51f	Grand 12-Inches 11 - Updates & Upgrades	Ben Liebrand	2014	Pop	0.65	Europe	Netherlands	0.75	https://coverartarchive.org/release-group/e41d8be2-8a9f-46d2-a5c8-4b6a17f8d51f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:e4f9ee97-e5b1-470d-827e-446042e6bf45	Pony Town Halloween 2022 Update	Wandering Artist	2022	Classical	0.75	Europe	Italy	0.75	https://coverartarchive.org/release-group/e4f9ee97-e5b1-470d-827e-446042e6bf45/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:e56af540-5e4c-44b5-8d1c-5b3bc3518d20	Dance Date	Wayne King And His Orchestra	1965	Pop	0.65	North America	United States	0.75	https://coverartarchive.org/release-group/e56af540-5e4c-44b5-8d1c-5b3bc3518d20/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:e58b358b-0725-481a-9654-f1132eab790c	T. C. Pfeiler & Up to Date Reunion Band	T. C. Pfeiler	2015	Pop	0.65	North America	Austria	0.75	https://coverartarchive.org/release-group/e58b358b-0725-481a-9654-f1132eab790c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:e7457398-caa0-45c6-8787-82a63519c0e1	Laudate Dominum: Sacred Cantatas	Augustin Pfleger	2013	Classical	0.75	Europe	Germany	0.75	https://coverartarchive.org/release-group/e7457398-caa0-45c6-8787-82a63519c0e1/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:e76c9eae-f012-4b8a-a685-06fe6e1fa4bb	Date Bait	Various Artists	1995	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/e76c9eae-f012-4b8a-a685-06fe6e1fa4bb/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:e8e41b48-6a3a-3018-bbc4-35b6aa9fd3b3	Requiem / Laudate Dominum	Mozart	1990	Classical	0.75	North America	Austria	0.75	https://coverartarchive.org/release-group/e8e41b48-6a3a-3018-bbc4-35b6aa9fd3b3/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:e94842f7-4d43-4b0f-8f53-114face985b1	Rare and Unreleased Tracks (Frequently Updatdated)	Anatomy of the Heads	2024	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/e94842f7-4d43-4b0f-8f53-114face985b1/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:eb3a24fb-b303-3b79-bf09-475e74e22d2a	Ô Laudate Dominvs	Glorior Belli	2005	Rock	0.3	Europe	France	0.75	https://coverartarchive.org/release-group/eb3a24fb-b303-3b79-bf09-475e74e22d2a/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:ece9096a-a91b-47f8-9ce7-9e7388b9fa8a	Rock It Baby (Baby We've Got a Date) / The Very First Time	Johnny Nash	1975	Pop	0.65	North America	United States	0.75	https://coverartarchive.org/release-group/ece9096a-a91b-47f8-9ce7-9e7388b9fa8a/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:ed434bcf-6ffa-48b4-84f3-67c383a7a592	The Date	Jimmy Raney	1981	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/ed434bcf-6ffa-48b4-84f3-67c383a7a592/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:ed4b5723-4a64-4097-8966-d06b745d2e68	No More Weak Dates	SassyBlack	2016	Pop	0.65	Unknown	Seattle	0.75	https://coverartarchive.org/release-group/ed4b5723-4a64-4097-8966-d06b745d2e68/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:ed5a4901-fd90-39c5-ad7d-1fd01eca41f0	Liquidate Paris!	Blood Meridian	2007	Rock	0.3	North America	Canada	0.75	https://coverartarchive.org/release-group/ed5a4901-fd90-39c5-ad7d-1fd01eca41f0/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:ee1fccae-a51b-4932-accc-494fb3d07c76	Update	Mal Waldron	1987	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/ee1fccae-a51b-4932-accc-494fb3d07c76/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:ee92f91b-8c14-4678-9c05-0c0bd1ff22f2	Blown Out Morbid Date	Birthward	1995	Rock	0.3	Europe	Greece	0.75	https://coverartarchive.org/release-group/ee92f91b-8c14-4678-9c05-0c0bd1ff22f2/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:efc21905-535d-46fe-8a30-4ff7d61e7934	Grand 12-Inches 19 - Updates	Ben Liebrand	2023	Electronic	0.8	Europe	Netherlands	0.75	https://coverartarchive.org/release-group/efc21905-535d-46fe-8a30-4ff7d61e7934/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:f0682c55-0a1a-4e5f-b9f4-6beef557c08c	China (The Mandate of Heaven)	Various Artists	2001	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/f0682c55-0a1a-4e5f-b9f4-6beef557c08c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:f1e83648-5e86-4f27-9649-ec65ba5436fe	Ponytown Snowy Beach Update	Wandering Artist	2020	Classical	0.75	Europe	Italy	0.75	https://coverartarchive.org/release-group/f1e83648-5e86-4f27-9649-ec65ba5436fe/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:f1fff10e-ee2d-4943-8b22-cfa88ed57e0c	At the Date of This Writing (Vol. 2)	J‐Live	2019	Other	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/f1fff10e-ee2d-4943-8b22-cfa88ed57e0c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:f23f022a-5e10-3604-a7c0-fc8260c712e4	Last Date	Eric Dolphy	1965	Jazz	0.7	North America	United States	0.75	https://coverartarchive.org/release-group/f23f022a-5e10-3604-a7c0-fc8260c712e4/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:f3784032-171f-3025-b538-d1f2c3a78b6e	Steady Date With Tommy Sands	Tommy Sands	1997	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/f3784032-171f-3025-b538-d1f2c3a78b6e/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:f3f60015-cb18-3bc1-93c2-2ffbad48aab1	Tumedate tunnete kütkeis	Tharaphita	2001	Rock	0.3	Unknown	Estonia	0.75	https://coverartarchive.org/release-group/f3f60015-cb18-3bc1-93c2-2ffbad48aab1/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:f4378c8f-2e80-4d2e-a252-39b7fa7f4dc6	Iraungitze Datei	Hartz	2018	Rock	0.3	Unknown	Legazpi	0.75	https://coverartarchive.org/release-group/f4378c8f-2e80-4d2e-a252-39b7fa7f4dc6/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:f45b2d2b-da2b-369a-bc80-d90410558597	The Best of Classics Up to Date	James Last	1998	Pop	0.65	Europe	Germany	0.75	https://coverartarchive.org/release-group/f45b2d2b-da2b-369a-bc80-d90410558597/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:f4faba5b-6c0c-4a16-85d3-2f2abb81d8f4	Quédate aquí	Proyecto Vida	2019	Latin	0.62	Unknown	\N	0.75	https://coverartarchive.org/release-group/f4faba5b-6c0c-4a16-85d3-2f2abb81d8f4/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:f527cc36-838d-3845-998f-3b70f80c7615	Blind Date With Violence	The Scourger	2006	Rock	0.3	Europe	Finland	0.75	https://coverartarchive.org/release-group/f527cc36-838d-3845-998f-3b70f80c7615/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:f5762f7e-e0ae-4631-8ada-bd0312855090	Delay	Moby	2014	Electronic	0.8	North America	United States	0.75	https://coverartarchive.org/release-group/f5762f7e-e0ae-4631-8ada-bd0312855090/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:f628c558-36e1-49ca-88c9-824d38537d8c	ValiDate: Original Soundtrack, Volume 1	Various Artists	2012	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/f628c558-36e1-49ca-88c9-824d38537d8c/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:f6ae4bc7-947a-4b36-92b1-300c64d5e781	Double Date	The Falling Leaves	1967	Rock	0.3	Africa	South Africa	0.75	https://coverartarchive.org/release-group/f6ae4bc7-947a-4b36-92b1-300c64d5e781/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:f6da1d74-0cbd-4c81-816f-3c675201edfd	Boys (That I Dated in High School)	The Prettiots	2015	Rock	0.3	Unknown	New York	0.75	https://coverartarchive.org/release-group/f6da1d74-0cbd-4c81-816f-3c675201edfd/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:f7f642dd-f776-3f85-8b51-fefe34ea4996	Never Dated	Milk	1994	Hip Hop	0.5	North America	United States	0.75	https://coverartarchive.org/release-group/f7f642dd-f776-3f85-8b51-fefe34ea4996/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:faafc495-69f3-4f9e-b57a-ca5d1ed81074	Datenight Does Dallas	Datenight	2017	Rock	0.3	Unknown	Nashville	0.75	https://coverartarchive.org/release-group/faafc495-69f3-4f9e-b57a-ca5d1ed81074/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:fc7d6122-7930-4d8e-bd7a-9a55f611eb71	Update	The Meeting	1995	Jazz	0.7	Unknown	\N	0.75	https://coverartarchive.org/release-group/fc7d6122-7930-4d8e-bd7a-9a55f611eb71/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:fcd8cdb5-20e1-39b1-b180-12abac358441	First Date	blink‐182	2001	Rock	0.3	North America	United States	0.75	https://coverartarchive.org/release-group/fcd8cdb5-20e1-39b1-b180-12abac358441/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:fd68f651-f7a2-4e41-a060-f190ded421a7	Up To Date	Didier Egea	1987	Electronic	0.8	Unknown	\N	0.75	https://coverartarchive.org/release-group/fd68f651-f7a2-4e41-a060-f190ded421a7/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:fd6bf731-7ada-41a8-bd81-e25a85b55401	Easy Update's Easy Listening Lolume 3	Ian Hinck	2017	Electronic	0.8	Unknown	Los Angeles	0.75	https://coverartarchive.org/release-group/fd6bf731-7ada-41a8-bd81-e25a85b55401/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:fdc60655-e7ce-4f59-98e0-3c170586994b	DATE NIGHT	ll nøthing ll	2018	Electronic	0.8	North America	Houston	0.75	https://coverartarchive.org/release-group/fdc60655-e7ce-4f59-98e0-3c170586994b/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:fdfdda87-3781-40d4-90f5-de03f37fc74e	Fidatevi	Ministri	2018	Rock	0.3	Europe	Italy	0.75	https://coverartarchive.org/release-group/fdfdda87-3781-40d4-90f5-de03f37fc74e/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:fe59a36d-55b4-4537-adfb-48de24ac032f	The Manchurian Candidate: Music From the Motion Picture	Various Artists	2004	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/fe59a36d-55b4-4537-adfb-48de24ac032f/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:fed118eb-53d7-49b3-872a-84984e62b7fd	Solo Quedate	Facel	2019	Hip Hop	0.5	North America	Mexico	0.75	https://coverartarchive.org/release-group/fed118eb-53d7-49b3-872a-84984e62b7fd/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:ff0dffe3-2e3c-4af0-bd03-b7999c66eb2a	Win a Date With...	The Young Hasselhoffs	1998	Rock	0.3	Unknown	\N	0.75	https://coverartarchive.org/release-group/ff0dffe3-2e3c-4af0-bd03-b7999c66eb2a/front-500	2026-01-19 15:56:34.730555+00
musicbrainz:rg:fff4896a-a613-4388-acf4-d6263f6b4ff4	A Date With Mr. Marstio	Harri Marstio	1984	Rock	0.3	Europe	Finland	0.75	https://coverartarchive.org/release-group/fff4896a-a613-4388-acf4-d6263f6b4ff4/front-500	2026-01-19 15:56:34.730555+00
\.


--
-- Data for Name: dev_users; Type: TABLE DATA; Schema: public; Owner: sonic
--

COPY public.dev_users (id, created_at, updated_at) FROM stdin;
9e541cea-42f3-45aa-a1cc-97f0cac4d982	2026-01-19 16:16:12.282654+00	2026-01-19 16:16:12.282654+00
\.


--
-- Data for Name: user_events; Type: TABLE DATA; Schema: public; Owner: sonic
--

COPY public.user_events (id, user_id, event_type, entity_type, entity_id, payload, created_at) FROM stdin;
\.


--
-- Data for Name: user_likes; Type: TABLE DATA; Schema: public; Owner: sonic
--

COPY public.user_likes (id, user_id, entity_type, entity_id, liked_at) FROM stdin;
\.


--
-- Data for Name: user_ratings; Type: TABLE DATA; Schema: public; Owner: sonic
--

COPY public.user_ratings (id, user_id, album_id, rating, note, listened_at, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: sonic
--

COPY public.users (id, google_sub, email, name, created_at) FROM stdin;
\.


--
-- Name: ai_research_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sonic
--

SELECT pg_catalog.setval('public.ai_research_id_seq', 1, false);


--
-- Name: album_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sonic
--

SELECT pg_catalog.setval('public.album_reviews_id_seq', 1, false);


--
-- Name: user_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sonic
--

SELECT pg_catalog.setval('public.user_events_id_seq', 1, false);


--
-- Name: user_likes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sonic
--

SELECT pg_catalog.setval('public.user_likes_id_seq', 1, false);


--
-- Name: user_ratings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sonic
--

SELECT pg_catalog.setval('public.user_ratings_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sonic
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: user_ratings _user_album_uc; Type: CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.user_ratings
    ADD CONSTRAINT _user_album_uc UNIQUE (user_id, album_id);


--
-- Name: user_likes _user_entity_like_uc; Type: CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.user_likes
    ADD CONSTRAINT _user_entity_like_uc UNIQUE (user_id, entity_type, entity_id);


--
-- Name: ai_research ai_research_pkey; Type: CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.ai_research
    ADD CONSTRAINT ai_research_pkey PRIMARY KEY (id);


--
-- Name: album_details album_details_pkey; Type: CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.album_details
    ADD CONSTRAINT album_details_pkey PRIMARY KEY (album_id);


--
-- Name: album_reviews album_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.album_reviews
    ADD CONSTRAINT album_reviews_pkey PRIMARY KEY (id);


--
-- Name: albums albums_pkey; Type: CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.albums
    ADD CONSTRAINT albums_pkey PRIMARY KEY (id);


--
-- Name: dev_users dev_users_pkey; Type: CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.dev_users
    ADD CONSTRAINT dev_users_pkey PRIMARY KEY (id);


--
-- Name: user_events user_events_pkey; Type: CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.user_events
    ADD CONSTRAINT user_events_pkey PRIMARY KEY (id);


--
-- Name: user_likes user_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.user_likes
    ADD CONSTRAINT user_likes_pkey PRIMARY KEY (id);


--
-- Name: user_ratings user_ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.user_ratings
    ADD CONSTRAINT user_ratings_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_event_type; Type: INDEX; Schema: public; Owner: sonic
--

CREATE INDEX idx_event_type ON public.user_events USING btree (event_type);


--
-- Name: idx_user_created_at; Type: INDEX; Schema: public; Owner: sonic
--

CREATE INDEX idx_user_created_at ON public.user_events USING btree (user_id, created_at);


--
-- Name: idx_user_entity_type; Type: INDEX; Schema: public; Owner: sonic
--

CREATE INDEX idx_user_entity_type ON public.user_likes USING btree (user_id, entity_type);


--
-- Name: ix_ai_research_cache_key; Type: INDEX; Schema: public; Owner: sonic
--

CREATE UNIQUE INDEX ix_ai_research_cache_key ON public.ai_research USING btree (cache_key);


--
-- Name: ix_ai_research_id; Type: INDEX; Schema: public; Owner: sonic
--

CREATE INDEX ix_ai_research_id ON public.ai_research USING btree (id);


--
-- Name: ix_album_reviews_id; Type: INDEX; Schema: public; Owner: sonic
--

CREATE INDEX ix_album_reviews_id ON public.album_reviews USING btree (id);


--
-- Name: ix_albums_artist_name; Type: INDEX; Schema: public; Owner: sonic
--

CREATE INDEX ix_albums_artist_name ON public.albums USING btree (artist_name);


--
-- Name: ix_albums_genre_vibe; Type: INDEX; Schema: public; Owner: sonic
--

CREATE INDEX ix_albums_genre_vibe ON public.albums USING btree (genre_vibe);


--
-- Name: ix_albums_region_bucket; Type: INDEX; Schema: public; Owner: sonic
--

CREATE INDEX ix_albums_region_bucket ON public.albums USING btree (region_bucket);


--
-- Name: ix_albums_title; Type: INDEX; Schema: public; Owner: sonic
--

CREATE INDEX ix_albums_title ON public.albums USING btree (title);


--
-- Name: ix_albums_year; Type: INDEX; Schema: public; Owner: sonic
--

CREATE INDEX ix_albums_year ON public.albums USING btree (year);


--
-- Name: ix_user_ratings_id; Type: INDEX; Schema: public; Owner: sonic
--

CREATE INDEX ix_user_ratings_id ON public.user_ratings USING btree (id);


--
-- Name: ix_users_google_sub; Type: INDEX; Schema: public; Owner: sonic
--

CREATE UNIQUE INDEX ix_users_google_sub ON public.users USING btree (google_sub);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: sonic
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ai_research ai_research_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.ai_research
    ADD CONSTRAINT ai_research_album_id_fkey FOREIGN KEY (album_id) REFERENCES public.albums(id);


--
-- Name: album_details album_details_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.album_details
    ADD CONSTRAINT album_details_album_id_fkey FOREIGN KEY (album_id) REFERENCES public.albums(id);


--
-- Name: album_reviews album_reviews_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.album_reviews
    ADD CONSTRAINT album_reviews_album_id_fkey FOREIGN KEY (album_id) REFERENCES public.albums(id);


--
-- Name: user_events user_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.user_events
    ADD CONSTRAINT user_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.dev_users(id);


--
-- Name: user_likes user_likes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.user_likes
    ADD CONSTRAINT user_likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.dev_users(id);


--
-- Name: user_ratings user_ratings_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.user_ratings
    ADD CONSTRAINT user_ratings_album_id_fkey FOREIGN KEY (album_id) REFERENCES public.albums(id);


--
-- Name: user_ratings user_ratings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sonic
--

ALTER TABLE ONLY public.user_ratings
    ADD CONSTRAINT user_ratings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 4EivWQGPNejwu34r7nrTjW1Ot6uayqqffdgoklC46tY2UJNvaojvCCmajg0OIsO

